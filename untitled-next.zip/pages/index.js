import React from 'react'
import Head from 'next/head'

import { useTranslations } from 'next-intl'

const Frame1920wlight = (props) => {
  return (
    <>
      <div className="frame1920wlight-container100">
        <Head>
          <title>exported project</title>
          <meta property="og:title" content="exported project" />
          <link
            rel="canonical"
            href="https://untitled-vjvsif.teleporthq.app/"
          />
        </Head>
        <div className="frame1920wlight-frame1920wlight">
          <div className="frame1920wlight-frame1">
            <div className="frame1920wlight-group3">
              <div className="frame1920wlight-banner">
                <div className="frame1920wlight-background10">
                  <div className="frame1920wlight-container101">
                    <div className="frame1920wlight-margin10">
                      <span className="frame1920wlight-text100 www.bohmenergy.nlOutfitLight">
                        Info@bohmenergy.nl
                      </span>
                    </div>
                    <div className="frame1920wlight-flag"></div>
                    <div className="frame1920wlight-linkmargin10">
                      <div className="frame1920wlight-component210">
                        <span className="frame1920wlight-text101 www.bohmenergy.nlOutfitLight">
                          (+31) 85-7606981
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="frame1920wlight-margin11">
                  <div className="frame1920wlight-background11">
                    <div className="frame1920wlight-linkhome">
                      <div className="frame1920wlight-logo1">
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="SVG6578a5b54fa1fa278cef6591footerlogosvgfill1666"
                          className="frame1920wlight-svg6578a5b54fa1fa278cef6591footerlogosvgfill1"
                        />
                      </div>
                    </div>
                    <div className="frame1920wlight-navigationmargin">
                      <div className="frame1920wlight-navigation">
                        <div className="frame1920wlight-component61">
                          <span className="frame1920wlight-text102 www.bohmenergy.nlOutfitLight2">
                            Thuisbatterij
                          </span>
                        </div>
                        <div className="frame1920wlight-component62">
                          <span className="frame1920wlight-text103 www.bohmenergy.nlOutfitLight2">
                            Zonnepanelen
                          </span>
                        </div>
                        <div className="frame1920wlight-component63">
                          <span className="frame1920wlight-text104 www.bohmenergy.nlOutfitLight2">
                            Over ons
                          </span>
                        </div>
                        <div className="frame1920wlight-component64">
                          <span className="frame1920wlight-text105 www.bohmenergy.nlOutfitLight2">
                            Blog
                          </span>
                        </div>
                        <div className="frame1920wlight-component65">
                          <span className="frame1920wlight-text106 www.bohmenergy.nlOutfitLight2">
                            Contact
                          </span>
                        </div>
                        <div className="frame1920wlight-margin12">
                          <div className="frame1920wlight-container102">
                            <div className="frame1920wlight-component11">
                              <div className="frame1920wlight-container103">
                                <span className="frame1920wlight-text107 www.bohmenergy.nlOutfitLight7">
                                  Contact
                                </span>
                              </div>
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="BackgroundI166"
                                className="frame1920wlight-background12"
                              />
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="BackgroundI166"
                                className="frame1920wlight-background13"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="frame1920wlight-group2">
                <div className="frame1920wlight-container104">
                  <div className="frame1920wlight-margin13">
                    <div className="frame1920wlight-container105">
                      <span className="frame1920wlight-text108 www.bohmenergy.nlOutfitLight7">
                        Let&apos;s talk savings
                      </span>
                    </div>
                  </div>
                  <div className="frame1920wlight-heading3margin1">
                    <div className="frame1920wlight-heading31">
                      <span className="frame1920wlight-text109 www.bohmenergy.nlSemanticHeading31">
                        <span className="frame1920wlight-text110">
                          Vraag je offerte aan voor
                        </span>
                        <br></br>
                        <span className="frame1920wlight-text112">
                          energiebesparing met onze LFP-
                        </span>
                        <br></br>
                        <span className="frame1920wlight-text114">
                          batterijtechnologie
                          <span
                            dangerouslySetInnerHTML={{
                              __html: ' ',
                            }}
                          />
                        </span>
                        <span className="frame1920wlight-text115">
                          (LiFeP04)
                        </span>
                        <span className="frame1920wlight-text116"> voor</span>
                        <br></br>
                        <span className="frame1920wlight-text118">
                          thuisbatterijen en krijg controle over je
                        </span>
                        <br></br>
                        <span>energieverbruik</span>
                      </span>
                    </div>
                  </div>
                  <div className="frame1920wlight-component12">
                    <div className="frame1920wlight-container106">
                      <span className="frame1920wlight-text121 www.bohmenergy.nlOutfitLight7">
                        Contact
                      </span>
                    </div>
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="BackgroundI165"
                      className="frame1920wlight-background14"
                    />
                    <img
                      src="https://play.teleporthq.io/static/svg/default-img.svg"
                      alt="BackgroundI165"
                      className="frame1920wlight-background15"
                    />
                  </div>
                </div>
                <div className="frame1920wlight-container107">
                  <div className="frame1920wlight-frame68b56635f3faf1bcad506866-website20onderaanpng"></div>
                </div>
                <div className="frame1920wlight-group1">
                  <div className="frame1920wlight-section1">
                    <div className="frame1920wlight-container108">
                      <div className="frame1920wlight-heading1margin">
                        <div className="frame1920wlight-heading1">
                          <span className="frame1920wlight-text122 www.bohmenergy.nlSemanticHeading1">
                            <span className="frame1920wlight-text123">
                              Bespaar nu geld met
                            </span>
                            <br></br>
                            <span className="frame1920wlight-text125">
                              een slimme
                            </span>
                            <br></br>
                            <span>thuisbatterij.</span>
                          </span>
                        </div>
                      </div>
                      <div className="frame1920wlight-margin14">
                        <span className="frame1920wlight-text128 www.bohmenergy.nlOutfitLight8">
                          <span className="frame1920wlight-text129">
                            Gemiddeld besparen huishoudens
                            <span
                              dangerouslySetInnerHTML={{
                                __html: ' ',
                              }}
                            />
                          </span>
                          <span className="frame1920wlight-text130">
                            €1200 per jaar
                          </span>
                          <span className="frame1920wlight-text131">
                            {' '}
                            met een 10
                          </span>
                          <br></br>
                          <span className="frame1920wlight-text133">
                            kWh thuisbatterij van Bohm Energy. Vraag nu
                            <span
                              dangerouslySetInnerHTML={{
                                __html: ' ',
                              }}
                            />
                          </span>
                          <span className="frame1920wlight-text134">
                            vrijblijvend
                          </span>
                          <span> jouw</span>
                          <br></br>
                          <span>energiebespaarrapport aan.</span>
                        </span>
                      </div>
                      <div className="frame1920wlight-margin15">
                        <div className="frame1920wlight-container109">
                          <div className="frame1920wlight-component13">
                            <div className="frame1920wlight-container110">
                              <span className="frame1920wlight-text138 www.bohmenergy.nlOutfitLight7">
                                Contact
                              </span>
                            </div>
                            <img
                              src="https://play.teleporthq.io/static/svg/default-img.svg"
                              alt="BackgroundI137"
                              className="frame1920wlight-background16"
                            />
                            <img
                              src="https://play.teleporthq.io/static/svg/default-img.svg"
                              alt="BackgroundI137"
                              className="frame1920wlight-background17"
                            />
                          </div>
                          <div className="frame1920wlight-container111">
                            <span className="frame1920wlight-text139 www.bohmenergy.nlOutfitLight2">
                              of
                            </span>
                          </div>
                          <div className="frame1920wlight-container112">
                            <div className="frame1920wlight-container113">
                              <span className="frame1920wlight-text140 www.bohmenergy.nlOutfitLight2">
                                Bel ons
                              </span>
                            </div>
                            <div className="frame1920wlight-component211">
                              <span className="frame1920wlight-text141 www.bohmenergy.nlOutfitLight2">
                                (+31) 85-7606981
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="frame1920wlight-container114">
                        <div className="frame1920wlight-container115">
                          <div className="frame1920wlight-img1"></div>
                          <div className="frame1920wlight-margin16">
                            <div className="frame1920wlight-paragraph1">
                              <span className="frame1920wlight-text142 www.bohmenergy.nlOutfitLight5">
                                Vertrouwd door
                              </span>
                              <span className="frame1920wlight-text143 www.bohmenergy.nlOutfitLight5">
                                400 Klanten
                              </span>
                            </div>
                          </div>
                        </div>
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="VerticalDivider1377"
                          className="frame1920wlight-vertical-divider"
                        />
                        <div className="frame1920wlight-container116">
                          <div className="frame1920wlight-trophy"></div>
                          <div className="frame1920wlight-margin17">
                            <div className="frame1920wlight-paragraph2">
                              <span className="frame1920wlight-text144 www.bohmenergy.nlOutfitLight5">
                                Slimste thuisbatterij
                              </span>
                              <span className="frame1920wlight-text145 www.bohmenergy.nlOutfitLight5">
                                van Nederland
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="frame1920wlight-container117">
                      <div className="frame1920wlight-component310">
                        <div className="frame1920wlight-clippathgroup1">
                          <div className="frame1920wlight-framelottieelement2">
                            <img
                              src="https://play.teleporthq.io/static/svg/default-img.svg"
                              alt="VectorI137"
                              className="frame1920wlight-vector100"
                            />
                          </div>
                          <div className="frame1920wlight-group100">
                            <div className="frame1920wlight-group101">
                              <div className="frame1920wlight-group102">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector101"
                                />
                              </div>
                              <div className="frame1920wlight-group103">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector102"
                                />
                              </div>
                              <div className="frame1920wlight-group104">
                                <img
                                  src="/vectori137-b4hf.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector103"
                                />
                              </div>
                              <div className="frame1920wlight-group105">
                                <img
                                  src="/vectori137-bhnf.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector104"
                                />
                              </div>
                              <div className="frame1920wlight-group106">
                                <img
                                  src="/vectori137-7uy4.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector105"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group107">
                              <div className="frame1920wlight-group108">
                                <img
                                  src="/vectori137-itix.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector106"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group109">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="RectangleI137"
                                className="frame1920wlight-rectangle1"
                              />
                            </div>
                            <div className="frame1920wlight-group110">
                              <div className="frame1920wlight-group111">
                                <img
                                  src="/vectori137-yh2p.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector107"
                                />
                              </div>
                              <div className="frame1920wlight-group112">
                                <img
                                  src="/vectori137-uurf.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector108"
                                />
                              </div>
                              <div className="frame1920wlight-group113">
                                <img
                                  src="/vectori137-q7gk.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector109"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group114">
                              <div className="frame1920wlight-group115">
                                <img
                                  src="/vectori137-dfp.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector110"
                                />
                              </div>
                              <div className="frame1920wlight-group116">
                                <img
                                  src="/vectori137-vq0j.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector111"
                                />
                              </div>
                              <div className="frame1920wlight-group117">
                                <img
                                  src="/vectori137-n1.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector112"
                                />
                              </div>
                              <div className="frame1920wlight-group118">
                                <img
                                  src="/vectori137-o0ih.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector113"
                                />
                              </div>
                              <div className="frame1920wlight-group119">
                                <img
                                  src="/vectori137-vuy.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector114"
                                />
                              </div>
                              <div className="frame1920wlight-group120">
                                <img
                                  src="/vectori137-kuha.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector115"
                                />
                              </div>
                              <div className="frame1920wlight-group121">
                                <img
                                  src="/vectori137-8s0q.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector116"
                                />
                              </div>
                              <div className="frame1920wlight-group122">
                                <img
                                  src="/vectori137-nwr.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector117"
                                />
                              </div>
                              <div className="frame1920wlight-group123">
                                <img
                                  src="/vectori137-nn4.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector118"
                                />
                              </div>
                              <div className="frame1920wlight-group124">
                                <img
                                  src="/vectori137-d33m.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector119"
                                />
                              </div>
                              <div className="frame1920wlight-group125">
                                <img
                                  src="/vectori137-kjzn.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector120"
                                />
                              </div>
                              <div className="frame1920wlight-group126">
                                <img
                                  src="/vectori137-nqc8.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector121"
                                />
                              </div>
                              <div className="frame1920wlight-group127">
                                <img
                                  src="/vectori137-u80h.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector122"
                                />
                              </div>
                              <div className="frame1920wlight-group128">
                                <img
                                  src="/vectori137-zc6g.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector123"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group129">
                              <div className="frame1920wlight-group130">
                                <img
                                  src="/vectori137-bt1.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector124"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group131">
                              <div className="frame1920wlight-group132">
                                <img
                                  src="/vectori137-544k.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector125"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group133">
                              <div className="frame1920wlight-group134">
                                <img
                                  src="/vectori137-di2.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector126"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group135">
                              <div className="frame1920wlight-group136">
                                <img
                                  src="/vectori137-czmb.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector127"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group137">
                              <div className="frame1920wlight-group138">
                                <img
                                  src="/vectori137-xb5d.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector128"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group139">
                              <div className="frame1920wlight-group140">
                                <img
                                  src="/vectori137-n1k7.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector129"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group141">
                              <div className="frame1920wlight-group142">
                                <img
                                  src="/vectori137-vlge.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector130"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group143">
                              <div className="frame1920wlight-group144">
                                <img
                                  src="/vectori137-rn9v.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector131"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group145">
                              <div className="frame1920wlight-group146">
                                <img
                                  src="/vectori137-ffj6.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector132"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group147">
                              <div className="frame1920wlight-group148">
                                <img
                                  src="/vectori137-npv4.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector133"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group149">
                              <div className="frame1920wlight-group150">
                                <img
                                  src="/vectori137-u369.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector134"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group151">
                              <div className="frame1920wlight-group152">
                                <img
                                  src="/vectori137-sbj.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector135"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group153">
                              <div className="frame1920wlight-group154">
                                <img
                                  src="/vectori137-3hws.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector136"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group155">
                              <div className="frame1920wlight-group156">
                                <img
                                  src="/vectori137-h0zq.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector137"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group157">
                              <div className="frame1920wlight-group158">
                                <img
                                  src="/vectori137-7zl.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector138"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group159">
                              <div className="frame1920wlight-group160">
                                <img
                                  src="/vectori137-838.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector139"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group161">
                              <div className="frame1920wlight-group162">
                                <img
                                  src="/vectori137-62sz.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector140"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group163">
                              <div className="frame1920wlight-group164">
                                <img
                                  src="/vectori137-m71q.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector141"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group165">
                              <div className="frame1920wlight-group166">
                                <img
                                  src="/vectori137-55xr.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector142"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group167">
                              <div className="frame1920wlight-group168">
                                <img
                                  src="/vectori137-9jch.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector143"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group169">
                              <div className="frame1920wlight-group170">
                                <img
                                  src="/vectori137-m8of.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector144"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group171">
                              <div className="frame1920wlight-group172">
                                <img
                                  src="/vectori137-jq2.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector145"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group173">
                              <div className="frame1920wlight-group174"></div>
                            </div>
                            <div className="frame1920wlight-group175">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="RectangleI137"
                                className="frame1920wlight-rectangle2"
                              />
                            </div>
                            <div className="frame1920wlight-group176">
                              <div className="frame1920wlight-group177">
                                <img
                                  src="/vectori137-ogg.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector146"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group178">
                              <div className="frame1920wlight-group179">
                                <img
                                  src="/vectori137-e3v.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector147"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group180">
                              <div className="frame1920wlight-group181">
                                <img
                                  src="/vectori137-1ipe.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector148"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group182">
                              <div className="frame1920wlight-group183">
                                <img
                                  src="/vectori137-3fnx.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector149"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group184">
                              <div className="frame1920wlight-group185">
                                <img
                                  src="/vectori137-xye9.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector150"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group186">
                              <div className="frame1920wlight-group187">
                                <img
                                  src="/vectori137-9axm.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector151"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group188">
                              <div className="frame1920wlight-group189">
                                <img
                                  src="/vectori137-une5.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector152"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group190">
                              <div className="frame1920wlight-group191">
                                <img
                                  src="/vectori137-20i7.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector153"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group192">
                              <div className="frame1920wlight-group193">
                                <img
                                  src="/vectori137-9mz9.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector154"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group194">
                              <div className="frame1920wlight-group195">
                                <img
                                  src="/vectori137-dup.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector155"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group196">
                              <div className="frame1920wlight-group197">
                                <img
                                  src="/vectori137-mdvc.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector156"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group198">
                              <div className="frame1920wlight-group199">
                                <img
                                  src="/vectori137-dei.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector157"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group200">
                              <div className="frame1920wlight-group201">
                                <img
                                  src="/vectori137-zmef.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector158"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group202">
                              <div className="frame1920wlight-group203">
                                <img
                                  src="/vectori137-0jro.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector159"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group204">
                              <div className="frame1920wlight-group205">
                                <img
                                  src="/vectori137-6rma.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector160"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group206">
                              <div className="frame1920wlight-group207">
                                <img
                                  src="/vectori137-nxhm.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector161"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group208">
                              <div className="frame1920wlight-group209">
                                <img
                                  src="/vectori137-aqt.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector162"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group210">
                              <div className="frame1920wlight-group211">
                                <img
                                  src="/vectori137-sbfb.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector163"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group212">
                              <div className="frame1920wlight-group213">
                                <img
                                  src="/vectori137-jkc9.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector164"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group214">
                              <div className="frame1920wlight-group215">
                                <img
                                  src="/vectori137-vjds.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector165"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group216">
                              <div className="frame1920wlight-group217">
                                <img
                                  src="/vectori137-wf1h.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector166"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group218">
                              <div className="frame1920wlight-group219">
                                <img
                                  src="/vectori137-gdf.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector167"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group220">
                              <div className="frame1920wlight-group221">
                                <img
                                  src="/vectori137-kzx.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector168"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group222">
                              <div className="frame1920wlight-group223">
                                <img
                                  src="/vectori137-plqk.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector169"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group224">
                              <div className="frame1920wlight-group225">
                                <img
                                  src="/vectori137-p5ad.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector170"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group226">
                              <div className="frame1920wlight-group227">
                                <img
                                  src="/vectori137-tve.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector171"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group228">
                              <div className="frame1920wlight-group229">
                                <img
                                  src="/vectori137-m6p7.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector172"
                                />
                              </div>
                              <div className="frame1920wlight-group230">
                                <img
                                  src="/vectori137-zqhs.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector173"
                                />
                              </div>
                              <div className="frame1920wlight-group231">
                                <img
                                  src="/vectori137-hjua.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector174"
                                />
                              </div>
                              <div className="frame1920wlight-group232">
                                <img
                                  src="/vectori137-iuj.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector175"
                                />
                              </div>
                              <div className="frame1920wlight-group233">
                                <img
                                  src="/vectori137-wpo.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector176"
                                />
                              </div>
                              <div className="frame1920wlight-group234">
                                <img
                                  src="/vectori137-rqid.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector177"
                                />
                              </div>
                              <div className="frame1920wlight-group235">
                                <img
                                  src="/vectori137-40tr.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector178"
                                />
                              </div>
                              <div className="frame1920wlight-group236">
                                <img
                                  src="/vectori137-xdh.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector179"
                                />
                              </div>
                              <div className="frame1920wlight-group237">
                                <img
                                  src="/vectori137-4i3n.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector180"
                                />
                              </div>
                              <div className="frame1920wlight-group238">
                                <img
                                  src="/vectori137-fpo.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector181"
                                />
                              </div>
                              <div className="frame1920wlight-group239">
                                <img
                                  src="/vectori137-nyfg.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector182"
                                />
                              </div>
                              <div className="frame1920wlight-group240">
                                <img
                                  src="/vectori137-yai.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector183"
                                />
                              </div>
                              <div className="frame1920wlight-group241">
                                <img
                                  src="/vectori137-hl6.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector184"
                                />
                              </div>
                              <div className="frame1920wlight-group242">
                                <img
                                  src="/vectori137-shgd.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector185"
                                />
                              </div>
                              <div className="frame1920wlight-group243">
                                <img
                                  src="/vectori137-0gdn.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector186"
                                />
                              </div>
                              <div className="frame1920wlight-group244">
                                <img
                                  src="/vectori137-w0c3.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector187"
                                />
                              </div>
                              <div className="frame1920wlight-group245">
                                <img
                                  src="/vectori137-vc6i.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector188"
                                />
                              </div>
                              <div className="frame1920wlight-group246">
                                <img
                                  src="/vectori137-xjuq.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector189"
                                />
                              </div>
                              <div className="frame1920wlight-group247">
                                <img
                                  src="/vectori137-nnx.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector190"
                                />
                              </div>
                              <div className="frame1920wlight-group248">
                                <img
                                  src="/vectori137-hqc5.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector191"
                                />
                              </div>
                              <div className="frame1920wlight-group249">
                                <img
                                  src="/vectori137-5uli.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector192"
                                />
                              </div>
                              <div className="frame1920wlight-group250">
                                <img
                                  src="/vectori137-0lfg.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector193"
                                />
                              </div>
                              <div className="frame1920wlight-group251">
                                <img
                                  src="/vectori137-39o.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector194"
                                />
                              </div>
                              <div className="frame1920wlight-group252">
                                <img
                                  src="/vectori137-kfda.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector195"
                                />
                              </div>
                              <div className="frame1920wlight-group253">
                                <img
                                  src="/vectori137-hptq.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector196"
                                />
                              </div>
                              <div className="frame1920wlight-group254">
                                <img
                                  src="/vectori137-gwql.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector197"
                                />
                              </div>
                              <div className="frame1920wlight-group255">
                                <img
                                  src="/vectori137-cv6f.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector198"
                                />
                              </div>
                              <div className="frame1920wlight-group256">
                                <img
                                  src="/vectori137-lfgq.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector199"
                                />
                              </div>
                              <div className="frame1920wlight-group257">
                                <img
                                  src="/vectori137-q4u.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector200"
                                />
                              </div>
                              <div className="frame1920wlight-group258">
                                <img
                                  src="/vectori137-zuiw.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector201"
                                />
                              </div>
                              <div className="frame1920wlight-group259">
                                <img
                                  src="/vectori137-djtm.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector202"
                                />
                              </div>
                              <div className="frame1920wlight-group260">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector203"
                                />
                              </div>
                              <div className="frame1920wlight-group261">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector204"
                                />
                              </div>
                              <div className="frame1920wlight-group262">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector205"
                                />
                              </div>
                              <div className="frame1920wlight-group263">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector206"
                                />
                              </div>
                              <div className="frame1920wlight-group264">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector207"
                                />
                              </div>
                              <div className="frame1920wlight-group265">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector208"
                                />
                              </div>
                              <div className="frame1920wlight-group266">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector209"
                                />
                              </div>
                              <div className="frame1920wlight-group267">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector210"
                                />
                              </div>
                              <div className="frame1920wlight-group268">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector211"
                                />
                              </div>
                              <div className="frame1920wlight-group269">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector212"
                                />
                              </div>
                              <div className="frame1920wlight-group270">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector213"
                                />
                              </div>
                              <div className="frame1920wlight-group271">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector214"
                                />
                              </div>
                              <div className="frame1920wlight-group272">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector215"
                                />
                              </div>
                              <div className="frame1920wlight-group273">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector216"
                                />
                              </div>
                              <div className="frame1920wlight-group274">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector217"
                                />
                              </div>
                              <div className="frame1920wlight-group275">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector218"
                                />
                              </div>
                              <div className="frame1920wlight-group276">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector219"
                                />
                              </div>
                              <div className="frame1920wlight-group277">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector220"
                                />
                              </div>
                              <div className="frame1920wlight-group278">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector221"
                                />
                              </div>
                              <div className="frame1920wlight-group279">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector222"
                                />
                              </div>
                              <div className="frame1920wlight-group280">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector223"
                                />
                              </div>
                              <div className="frame1920wlight-group281">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector224"
                                />
                              </div>
                              <div className="frame1920wlight-group282">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector225"
                                />
                              </div>
                              <div className="frame1920wlight-group283">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector226"
                                />
                              </div>
                              <div className="frame1920wlight-group284">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector227"
                                />
                              </div>
                              <div className="frame1920wlight-group285">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector228"
                                />
                              </div>
                              <div className="frame1920wlight-group286">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector229"
                                />
                              </div>
                              <div className="frame1920wlight-group287">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector230"
                                />
                              </div>
                              <div className="frame1920wlight-group288">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector231"
                                />
                              </div>
                              <div className="frame1920wlight-group289">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector232"
                                />
                              </div>
                              <div className="frame1920wlight-group290">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector233"
                                />
                              </div>
                              <div className="frame1920wlight-group291">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector234"
                                />
                              </div>
                              <div className="frame1920wlight-group292">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector235"
                                />
                              </div>
                              <div className="frame1920wlight-group293">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector236"
                                />
                              </div>
                              <div className="frame1920wlight-group294">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector237"
                                />
                              </div>
                              <div className="frame1920wlight-group295">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector238"
                                />
                              </div>
                              <div className="frame1920wlight-group296">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector239"
                                />
                              </div>
                              <div className="frame1920wlight-group297">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector240"
                                />
                              </div>
                              <div className="frame1920wlight-group298">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector241"
                                />
                              </div>
                              <div className="frame1920wlight-group299">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector242"
                                />
                              </div>
                              <div className="frame1920wlight-group300">
                                <img
                                  src="/vectori137-khsd.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector243"
                                />
                              </div>
                              <div className="frame1920wlight-group301">
                                <img
                                  src="/vectori137-jv07.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector244"
                                />
                              </div>
                              <div className="frame1920wlight-group302">
                                <img
                                  src="/vectori137-w1ms.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector245"
                                />
                              </div>
                              <div className="frame1920wlight-group303">
                                <img
                                  src="/vectori137-2e4s.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector246"
                                />
                              </div>
                              <div className="frame1920wlight-group304">
                                <img
                                  src="/vectori137-obxm.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector247"
                                />
                              </div>
                              <div className="frame1920wlight-group305">
                                <img
                                  src="/vectori137-ldi5.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector248"
                                />
                              </div>
                              <div className="frame1920wlight-group306">
                                <img
                                  src="/vectori137-hgsq.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector249"
                                />
                              </div>
                              <div className="frame1920wlight-group307">
                                <img
                                  src="/vectori137-ypeh.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector250"
                                />
                              </div>
                              <div className="frame1920wlight-group308">
                                <img
                                  src="/vectori137-q9w3.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector251"
                                />
                              </div>
                              <div className="frame1920wlight-group309">
                                <img
                                  src="/vectori137-xhsl.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector252"
                                />
                              </div>
                              <div className="frame1920wlight-group310">
                                <img
                                  src="/vectori137-o5er.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector253"
                                />
                              </div>
                              <div className="frame1920wlight-group311">
                                <img
                                  src="/vectori137-v0ch.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector254"
                                />
                              </div>
                              <div className="frame1920wlight-group312">
                                <img
                                  src="/vectori137-lwzj.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector255"
                                />
                              </div>
                              <div className="frame1920wlight-group313">
                                <img
                                  src="/vectori137-30ld.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector256"
                                />
                              </div>
                              <div className="frame1920wlight-group314">
                                <img
                                  src="/vectori137-hm9s.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector257"
                                />
                              </div>
                              <div className="frame1920wlight-group315">
                                <img
                                  src="/vectori137-v985.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector258"
                                />
                              </div>
                              <div className="frame1920wlight-group316">
                                <img
                                  src="/vectori137-g9yq.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector259"
                                />
                              </div>
                              <div className="frame1920wlight-group317">
                                <img
                                  src="/vectori137-cx5t.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector260"
                                />
                              </div>
                              <div className="frame1920wlight-group318">
                                <img
                                  src="/vectori137-zq1o.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector261"
                                />
                              </div>
                              <div className="frame1920wlight-group319">
                                <img
                                  src="/vectori137-qlhh.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector262"
                                />
                              </div>
                              <div className="frame1920wlight-group320">
                                <img
                                  src="/vectori137-ke7r.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector263"
                                />
                              </div>
                              <div className="frame1920wlight-group321">
                                <img
                                  src="/vectori137-17n.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector264"
                                />
                              </div>
                              <div className="frame1920wlight-group322">
                                <img
                                  src="/vectori137-z4ft.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector265"
                                />
                              </div>
                              <div className="frame1920wlight-group323">
                                <img
                                  src="/vectori137-kw4h.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector266"
                                />
                              </div>
                              <div className="frame1920wlight-group324">
                                <img
                                  src="/vectori137-a6sv.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector267"
                                />
                              </div>
                              <div className="frame1920wlight-group325">
                                <img
                                  src="/vectori137-zc0jh.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector268"
                                />
                              </div>
                              <div className="frame1920wlight-group326">
                                <img
                                  src="/vectori137-cvq.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector269"
                                />
                              </div>
                              <div className="frame1920wlight-group327">
                                <img
                                  src="/vectori137-zcnx.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector270"
                                />
                              </div>
                              <div className="frame1920wlight-group328">
                                <img
                                  src="/vectori137-bqg.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector271"
                                />
                              </div>
                              <div className="frame1920wlight-group329">
                                <img
                                  src="/vectori137-f2c.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector272"
                                />
                              </div>
                              <div className="frame1920wlight-group330">
                                <img
                                  src="/vectori137-oucr.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector273"
                                />
                              </div>
                              <div className="frame1920wlight-group331">
                                <img
                                  src="/vectori137-n72.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector274"
                                />
                              </div>
                              <div className="frame1920wlight-group332">
                                <img
                                  src="/vectori137-ambj.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector275"
                                />
                              </div>
                              <div className="frame1920wlight-group333">
                                <img
                                  src="/vectori137-ksho.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector276"
                                />
                              </div>
                              <div className="frame1920wlight-group334">
                                <img
                                  src="/vectori137-k008.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector277"
                                />
                              </div>
                              <div className="frame1920wlight-group335">
                                <img
                                  src="/vectori137-8jj.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector278"
                                />
                              </div>
                              <div className="frame1920wlight-group336">
                                <img
                                  src="/vectori137-i0ho.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector279"
                                />
                              </div>
                              <div className="frame1920wlight-group337">
                                <img
                                  src="/vectori137-d4aw.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector280"
                                />
                              </div>
                              <div className="frame1920wlight-group338">
                                <img
                                  src="/vectori137-tg6t.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector281"
                                />
                              </div>
                              <div className="frame1920wlight-group339">
                                <img
                                  src="/vectori137-x64y.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector282"
                                />
                              </div>
                              <div className="frame1920wlight-group340">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector283"
                                />
                              </div>
                              <div className="frame1920wlight-group341">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector284"
                                />
                              </div>
                              <div className="frame1920wlight-group342">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector285"
                                />
                              </div>
                              <div className="frame1920wlight-group343">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector286"
                                />
                              </div>
                              <div className="frame1920wlight-group344">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector287"
                                />
                              </div>
                              <div className="frame1920wlight-group345">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector288"
                                />
                              </div>
                              <div className="frame1920wlight-group346">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector289"
                                />
                              </div>
                              <div className="frame1920wlight-group347">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector290"
                                />
                              </div>
                              <div className="frame1920wlight-group348">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector291"
                                />
                              </div>
                              <div className="frame1920wlight-group349">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector292"
                                />
                              </div>
                              <div className="frame1920wlight-group350">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector293"
                                />
                              </div>
                              <div className="frame1920wlight-group351">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector294"
                                />
                              </div>
                              <div className="frame1920wlight-group352">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector295"
                                />
                              </div>
                              <div className="frame1920wlight-group353">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector296"
                                />
                              </div>
                              <div className="frame1920wlight-group354">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector297"
                                />
                              </div>
                              <div className="frame1920wlight-group355">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector298"
                                />
                              </div>
                              <div className="frame1920wlight-group356">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector299"
                                />
                              </div>
                              <div className="frame1920wlight-group357">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector300"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group358">
                              <div className="frame1920wlight-group359">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector301"
                                />
                              </div>
                              <div className="frame1920wlight-group360">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector302"
                                />
                              </div>
                              <div className="frame1920wlight-group361">
                                <img
                                  src="/vectori137-2xmp.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector303"
                                />
                              </div>
                              <div className="frame1920wlight-group362">
                                <img
                                  src="/vectori137-rvv.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector304"
                                />
                              </div>
                              <div className="frame1920wlight-group363">
                                <img
                                  src="/vectori137-xsx.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector305"
                                />
                              </div>
                              <div className="frame1920wlight-group364">
                                <img
                                  src="/vectori137-zzj7.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector306"
                                />
                              </div>
                              <div className="frame1920wlight-group365">
                                <img
                                  src="/vectori137-6l4wi.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector307"
                                />
                              </div>
                              <div className="frame1920wlight-group366">
                                <img
                                  src="/vectori137-txm.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector308"
                                />
                              </div>
                              <div className="frame1920wlight-group367">
                                <img
                                  src="/vectori137-gqva.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector309"
                                />
                              </div>
                              <div className="frame1920wlight-group368">
                                <img
                                  src="/vectori137-nnyn.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector310"
                                />
                              </div>
                              <div className="frame1920wlight-group369">
                                <img
                                  src="/vectori137-6zx.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector311"
                                />
                              </div>
                              <div className="frame1920wlight-group370">
                                <img
                                  src="/vectori137-zo1o.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector312"
                                />
                              </div>
                              <div className="frame1920wlight-group371">
                                <img
                                  src="/vectori137-5mpq.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector313"
                                />
                              </div>
                              <div className="frame1920wlight-group372">
                                <img
                                  src="/vectori137-rj3.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector314"
                                />
                              </div>
                              <div className="frame1920wlight-group373">
                                <img
                                  src="/vectori137-duxi.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector315"
                                />
                              </div>
                              <div className="frame1920wlight-group374">
                                <img
                                  src="/vectori137-l6mc.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector316"
                                />
                              </div>
                              <div className="frame1920wlight-group375">
                                <img
                                  src="/vectori137-kem.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector317"
                                />
                              </div>
                              <div className="frame1920wlight-group376">
                                <img
                                  src="/vectori137-9lxp.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector318"
                                />
                              </div>
                              <div className="frame1920wlight-group377">
                                <img
                                  src="/vectori137-3kma.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector319"
                                />
                              </div>
                              <div className="frame1920wlight-group378">
                                <img
                                  src="/vectori137-utgi.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector320"
                                />
                              </div>
                              <div className="frame1920wlight-group379">
                                <img
                                  src="/vectori137-cizc.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector321"
                                />
                              </div>
                              <div className="frame1920wlight-group380">
                                <img
                                  src="/vectori137-1a1v.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector322"
                                />
                              </div>
                              <div className="frame1920wlight-group381">
                                <img
                                  src="/vectori137-nazr.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector323"
                                />
                              </div>
                              <div className="frame1920wlight-group382">
                                <img
                                  src="/vectori137-qabl.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector324"
                                />
                              </div>
                              <div className="frame1920wlight-group383">
                                <img
                                  src="/vectori137-6x0b.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector325"
                                />
                              </div>
                              <div className="frame1920wlight-group384">
                                <img
                                  src="/vectori137-voy.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector326"
                                />
                              </div>
                              <div className="frame1920wlight-group385">
                                <img
                                  src="/vectori137-drth.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector327"
                                />
                              </div>
                              <div className="frame1920wlight-group386">
                                <img
                                  src="/vectori137-29hz.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector328"
                                />
                              </div>
                              <div className="frame1920wlight-group387">
                                <img
                                  src="/vectori137-ifm.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector329"
                                />
                              </div>
                              <div className="frame1920wlight-group388">
                                <img
                                  src="/vectori137-xmq5.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector330"
                                />
                              </div>
                              <div className="frame1920wlight-group389">
                                <img
                                  src="/vectori137-ndph.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector331"
                                />
                              </div>
                              <div className="frame1920wlight-group390">
                                <img
                                  src="/vectori137-eyw.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector332"
                                />
                              </div>
                              <div className="frame1920wlight-group391">
                                <img
                                  src="/vectori137-27dj.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector333"
                                />
                              </div>
                              <div className="frame1920wlight-group392">
                                <img
                                  src="/vectori137-5tbc.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector334"
                                />
                              </div>
                              <div className="frame1920wlight-group393">
                                <img
                                  src="/vectori137-7gwv.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector335"
                                />
                              </div>
                              <div className="frame1920wlight-group394">
                                <img
                                  src="/vectori137-hb43.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector336"
                                />
                              </div>
                              <div className="frame1920wlight-group395">
                                <img
                                  src="/vectori137-q73a.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector337"
                                />
                              </div>
                              <div className="frame1920wlight-group396">
                                <img
                                  src="/vectori137-vf9o.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector338"
                                />
                              </div>
                              <div className="frame1920wlight-group397">
                                <img
                                  src="/vectori137-lpis.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector339"
                                />
                              </div>
                              <div className="frame1920wlight-group398">
                                <img
                                  src="/vectori137-a9lh.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector340"
                                />
                              </div>
                              <div className="frame1920wlight-group399">
                                <img
                                  src="/vectori137-kqx.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector341"
                                />
                              </div>
                              <div className="frame1920wlight-group400">
                                <img
                                  src="/vectori137-jc2.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector342"
                                />
                              </div>
                              <div className="frame1920wlight-group401">
                                <img
                                  src="/vectori137-o21h.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector343"
                                />
                              </div>
                              <div className="frame1920wlight-group402">
                                <img
                                  src="/vectori137-c8tc.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector344"
                                />
                              </div>
                              <div className="frame1920wlight-group403">
                                <img
                                  src="/vectori137-qgcq.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector345"
                                />
                              </div>
                              <div className="frame1920wlight-group404">
                                <img
                                  src="/vectori137-q6eu.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector346"
                                />
                              </div>
                              <div className="frame1920wlight-group405">
                                <img
                                  src="/vectori137-ivx.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector347"
                                />
                              </div>
                              <div className="frame1920wlight-group406">
                                <img
                                  src="/vectori137-ncp.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector348"
                                />
                              </div>
                              <div className="frame1920wlight-group407">
                                <img
                                  src="/vectori137-zyc.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector349"
                                />
                              </div>
                              <div className="frame1920wlight-group408">
                                <img
                                  src="/vectori137-w8yk.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector350"
                                />
                              </div>
                              <div className="frame1920wlight-group409">
                                <img
                                  src="/vectori137-zf5g.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector351"
                                />
                              </div>
                              <div className="frame1920wlight-group410">
                                <img
                                  src="/vectori137-2t0r.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector352"
                                />
                              </div>
                              <div className="frame1920wlight-group411">
                                <img
                                  src="/vectori137-v7qu.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector353"
                                />
                              </div>
                              <div className="frame1920wlight-group412">
                                <img
                                  src="/vectori137-zxp.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector354"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group413">
                              <div className="frame1920wlight-group414">
                                <img
                                  src="/vectori137-8yev.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector355"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group415">
                              <div className="frame1920wlight-group416">
                                <img
                                  src="/vectori137-v004.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector356"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group417">
                              <div className="frame1920wlight-group418">
                                <img
                                  src="/vectori137-fdhh.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector357"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group419">
                              <div className="frame1920wlight-group420">
                                <img
                                  src="/vectori137-l7gv.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector358"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group421">
                              <div className="frame1920wlight-group422">
                                <img
                                  src="/vectori137-fp58.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector359"
                                />
                              </div>
                              <div className="frame1920wlight-group423">
                                <img
                                  src="/vectori137-tz5a.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector360"
                                />
                              </div>
                              <div className="frame1920wlight-group424">
                                <img
                                  src="/vectori137-ra5.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector361"
                                />
                              </div>
                              <div className="frame1920wlight-group425">
                                <img
                                  src="/vectori137-0qnf.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector362"
                                />
                              </div>
                              <div className="frame1920wlight-group426">
                                <img
                                  src="/vectori137-nrhr.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector363"
                                />
                              </div>
                              <div className="frame1920wlight-group427">
                                <img
                                  src="/vectori137-gx6c.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector364"
                                />
                              </div>
                              <div className="frame1920wlight-group428">
                                <img
                                  src="/vectori137-k1r59.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector365"
                                />
                              </div>
                              <div className="frame1920wlight-group429">
                                <img
                                  src="/vectori137-6gun.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector366"
                                />
                              </div>
                              <div className="frame1920wlight-group430">
                                <img
                                  src="/vectori137-4e16.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector367"
                                />
                              </div>
                              <div className="frame1920wlight-group431">
                                <img
                                  src="/vectori137-ewet.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector368"
                                />
                              </div>
                              <div className="frame1920wlight-group432">
                                <img
                                  src="/vectori137-wzd5.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector369"
                                />
                              </div>
                              <div className="frame1920wlight-group433">
                                <img
                                  src="/vectori137-s91q.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector370"
                                />
                              </div>
                              <div className="frame1920wlight-group434">
                                <img
                                  src="/vectori137-21jch.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector371"
                                />
                              </div>
                              <div className="frame1920wlight-group435">
                                <img
                                  src="/vectori137-ssis.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector372"
                                />
                              </div>
                              <div className="frame1920wlight-group436">
                                <img
                                  src="/vectori137-8wpc.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector373"
                                />
                              </div>
                              <div className="frame1920wlight-group437">
                                <img
                                  src="/vectori137-aqf5.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector374"
                                />
                              </div>
                              <div className="frame1920wlight-group438">
                                <img
                                  src="/vectori137-uks6.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector375"
                                />
                              </div>
                              <div className="frame1920wlight-group439">
                                <img
                                  src="/vectori137-8xgj.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector376"
                                />
                              </div>
                              <div className="frame1920wlight-group440">
                                <img
                                  src="/vectori137-qlhf.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector377"
                                />
                              </div>
                              <div className="frame1920wlight-group441">
                                <img
                                  src="/vectori137-c5a.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector378"
                                />
                              </div>
                              <div className="frame1920wlight-group442">
                                <img
                                  src="/vectori137-h7ur.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector379"
                                />
                              </div>
                              <div className="frame1920wlight-group443">
                                <img
                                  src="/vectori137-vdfo.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector380"
                                />
                              </div>
                              <div className="frame1920wlight-group444">
                                <img
                                  src="/vectori137-4u1.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector381"
                                />
                              </div>
                              <div className="frame1920wlight-group445">
                                <img
                                  src="/vectori137-dek.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector382"
                                />
                              </div>
                              <div className="frame1920wlight-group446">
                                <img
                                  src="/vectori137-6mp.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector383"
                                />
                              </div>
                              <div className="frame1920wlight-group447">
                                <img
                                  src="/vectori137-n0ym.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector384"
                                />
                              </div>
                              <div className="frame1920wlight-group448">
                                <img
                                  src="/vectori137-ioi8.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector385"
                                />
                              </div>
                              <div className="frame1920wlight-group449">
                                <img
                                  src="/vectori137-8k8h7.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector386"
                                />
                              </div>
                              <div className="frame1920wlight-group450">
                                <img
                                  src="/vectori137-qh78.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector387"
                                />
                              </div>
                              <div className="frame1920wlight-group451">
                                <img
                                  src="/vectori137-7tdo.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector388"
                                />
                              </div>
                              <div className="frame1920wlight-group452">
                                <img
                                  src="/vectori137-hv5v.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector389"
                                />
                              </div>
                              <div className="frame1920wlight-group453">
                                <img
                                  src="/vectori137-c2gv.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector390"
                                />
                              </div>
                              <div className="frame1920wlight-group454">
                                <img
                                  src="/vectori137-xv2.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector391"
                                />
                              </div>
                              <div className="frame1920wlight-group455">
                                <img
                                  src="/vectori137-c41l.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector392"
                                />
                              </div>
                              <div className="frame1920wlight-group456">
                                <img
                                  src="/vectori137-pn8.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector393"
                                />
                              </div>
                              <div className="frame1920wlight-group457">
                                <img
                                  src="/vectori137-8k6.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector394"
                                />
                              </div>
                              <div className="frame1920wlight-group458">
                                <img
                                  src="/vectori137-3qcd.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector395"
                                />
                              </div>
                              <div className="frame1920wlight-group459">
                                <img
                                  src="/vectori137-cb78.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector396"
                                />
                              </div>
                              <div className="frame1920wlight-group460">
                                <img
                                  src="/vectori137-uyxe.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector397"
                                />
                              </div>
                              <div className="frame1920wlight-group461">
                                <img
                                  src="/vectori137-70e.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector398"
                                />
                              </div>
                              <div className="frame1920wlight-group462">
                                <img
                                  src="/vectori137-bfr.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector399"
                                />
                              </div>
                              <div className="frame1920wlight-group463">
                                <img
                                  src="/vectori137-5bp8.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector400"
                                />
                              </div>
                              <div className="frame1920wlight-group464">
                                <img
                                  src="/vectori137-nl3q.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector401"
                                />
                              </div>
                              <div className="frame1920wlight-group465">
                                <img
                                  src="/vectori137-35s9.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector402"
                                />
                              </div>
                              <div className="frame1920wlight-group466">
                                <img
                                  src="/vectori137-xpi.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector403"
                                />
                              </div>
                              <div className="frame1920wlight-group467">
                                <img
                                  src="/vectori137-9v9o.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector404"
                                />
                              </div>
                              <div className="frame1920wlight-group468">
                                <img
                                  src="/vectori137-lmr.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector405"
                                />
                              </div>
                              <div className="frame1920wlight-group469">
                                <img
                                  src="/vectori137-jfzba.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector406"
                                />
                              </div>
                              <div className="frame1920wlight-group470">
                                <img
                                  src="/vectori137-36q4.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector407"
                                />
                              </div>
                              <div className="frame1920wlight-group471">
                                <img
                                  src="/vectori137-hu9b.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector408"
                                />
                              </div>
                              <div className="frame1920wlight-group472">
                                <img
                                  src="/vectori137-16o.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector409"
                                />
                              </div>
                              <div className="frame1920wlight-group473">
                                <img
                                  src="/vectori137-hyc.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector410"
                                />
                              </div>
                              <div className="frame1920wlight-group474">
                                <img
                                  src="/vectori137-ijz.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector411"
                                />
                              </div>
                              <div className="frame1920wlight-group475">
                                <img
                                  src="/vectori137-5rqr.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector412"
                                />
                              </div>
                              <div className="frame1920wlight-group476">
                                <img
                                  src="/vectori137-3whz.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector413"
                                />
                              </div>
                              <div className="frame1920wlight-group477">
                                <img
                                  src="/vectori137-vzga.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector414"
                                />
                              </div>
                              <div className="frame1920wlight-group478">
                                <img
                                  src="/vectori137-s5ns.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector415"
                                />
                              </div>
                              <div className="frame1920wlight-group479">
                                <img
                                  src="/vectori137-a6kd.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector416"
                                />
                              </div>
                              <div className="frame1920wlight-group480">
                                <img
                                  src="/vectori137-lba7.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector417"
                                />
                              </div>
                              <div className="frame1920wlight-group481">
                                <img
                                  src="/vectori137-4nkl.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector418"
                                />
                              </div>
                              <div className="frame1920wlight-group482">
                                <img
                                  src="/vectori137-pdkn.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector419"
                                />
                              </div>
                              <div className="frame1920wlight-group483">
                                <img
                                  src="/vectori137-nn3lj.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector420"
                                />
                              </div>
                              <div className="frame1920wlight-group484">
                                <img
                                  src="/vectori137-e08b.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector421"
                                />
                              </div>
                              <div className="frame1920wlight-group485">
                                <img
                                  src="/vectori137-bpxs.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector422"
                                />
                              </div>
                              <div className="frame1920wlight-group486">
                                <img
                                  src="/vectori137-ndx.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector423"
                                />
                              </div>
                              <div className="frame1920wlight-group487">
                                <img
                                  src="/vectori137-fsf8.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector424"
                                />
                              </div>
                              <div className="frame1920wlight-group488">
                                <img
                                  src="/vectori137-w1o.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector425"
                                />
                              </div>
                              <div className="frame1920wlight-group489">
                                <img
                                  src="/vectori137-syiq.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector426"
                                />
                              </div>
                              <div className="frame1920wlight-group490">
                                <img
                                  src="/vectori137-rzkm.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector427"
                                />
                              </div>
                              <div className="frame1920wlight-group491">
                                <img
                                  src="/vectori137-ez8m.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector428"
                                />
                              </div>
                              <div className="frame1920wlight-group492">
                                <img
                                  src="/vectori137-vq04.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector429"
                                />
                              </div>
                              <div className="frame1920wlight-group493">
                                <img
                                  src="/vectori137-r3w.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector430"
                                />
                              </div>
                              <div className="frame1920wlight-group494">
                                <img
                                  src="/vectori137-d40h.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector431"
                                />
                              </div>
                              <div className="frame1920wlight-group495">
                                <img
                                  src="/vectori137-a33e.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector432"
                                />
                              </div>
                              <div className="frame1920wlight-group496">
                                <img
                                  src="/vectori137-dks.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector433"
                                />
                              </div>
                              <div className="frame1920wlight-group497">
                                <img
                                  src="/vectori137-qbv.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector434"
                                />
                              </div>
                              <div className="frame1920wlight-group498">
                                <img
                                  src="/vectori137-2lz.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector435"
                                />
                              </div>
                              <div className="frame1920wlight-group499">
                                <img
                                  src="/vectori137-afcv.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector436"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-maskgroup">
                              <div className="frame1920wlight-group500">
                                <div className="frame1920wlight-framelottieelement211"></div>
                              </div>
                              <div className="frame1920wlight-group501">
                                <div className="frame1920wlight-clippathgroup2">
                                  <div className="frame1920wlight-framelottieelement217"></div>
                                  <div className="frame1920wlight-group502">
                                    <div className="frame1920wlight-group503">
                                      <div className="frame1920wlight-group504"></div>
                                      <div className="frame1920wlight-group505"></div>
                                      <div className="frame1920wlight-group506"></div>
                                      <div className="frame1920wlight-group507"></div>
                                      <div className="frame1920wlight-group508"></div>
                                    </div>
                                    <div className="frame1920wlight-group509">
                                      <div className="frame1920wlight-group510"></div>
                                    </div>
                                    <div className="frame1920wlight-group511">
                                      <img
                                        src="/rectanglei137-3gn4-1200h.png"
                                        alt="RectangleI137"
                                        className="frame1920wlight-rectangle3"
                                      />
                                    </div>
                                    <div className="frame1920wlight-group512">
                                      <div className="frame1920wlight-group513"></div>
                                      <div className="frame1920wlight-group514"></div>
                                      <div className="frame1920wlight-group515"></div>
                                    </div>
                                    <div className="frame1920wlight-group516">
                                      <div className="frame1920wlight-group517"></div>
                                      <div className="frame1920wlight-group518"></div>
                                      <div className="frame1920wlight-group519"></div>
                                      <div className="frame1920wlight-group520"></div>
                                      <div className="frame1920wlight-group521"></div>
                                      <div className="frame1920wlight-group522"></div>
                                      <div className="frame1920wlight-group523"></div>
                                      <div className="frame1920wlight-group524"></div>
                                      <div className="frame1920wlight-group525"></div>
                                      <div className="frame1920wlight-group526"></div>
                                      <div className="frame1920wlight-group527"></div>
                                      <div className="frame1920wlight-group528"></div>
                                      <div className="frame1920wlight-group529"></div>
                                      <div className="frame1920wlight-group530"></div>
                                    </div>
                                    <div className="frame1920wlight-group531">
                                      <div className="frame1920wlight-group532"></div>
                                    </div>
                                    <div className="frame1920wlight-group533">
                                      <div className="frame1920wlight-group534"></div>
                                    </div>
                                    <div className="frame1920wlight-group535">
                                      <div className="frame1920wlight-group536"></div>
                                    </div>
                                    <div className="frame1920wlight-group537">
                                      <div className="frame1920wlight-group538"></div>
                                    </div>
                                    <div className="frame1920wlight-group539">
                                      <div className="frame1920wlight-group540"></div>
                                    </div>
                                    <div className="frame1920wlight-group541">
                                      <div className="frame1920wlight-group542"></div>
                                    </div>
                                    <div className="frame1920wlight-group543">
                                      <div className="frame1920wlight-group544"></div>
                                    </div>
                                    <div className="frame1920wlight-group545">
                                      <div className="frame1920wlight-group546"></div>
                                    </div>
                                    <div className="frame1920wlight-group547">
                                      <div className="frame1920wlight-group548"></div>
                                    </div>
                                    <div className="frame1920wlight-group549">
                                      <div className="frame1920wlight-group550"></div>
                                    </div>
                                    <div className="frame1920wlight-group551">
                                      <div className="frame1920wlight-group552"></div>
                                    </div>
                                    <div className="frame1920wlight-group553">
                                      <div className="frame1920wlight-group554"></div>
                                    </div>
                                    <div className="frame1920wlight-group555">
                                      <div className="frame1920wlight-group556"></div>
                                    </div>
                                    <div className="frame1920wlight-group557">
                                      <div className="frame1920wlight-group558"></div>
                                    </div>
                                    <div className="frame1920wlight-group559">
                                      <div className="frame1920wlight-group560"></div>
                                    </div>
                                    <div className="frame1920wlight-group561">
                                      <div className="frame1920wlight-group562"></div>
                                    </div>
                                    <div className="frame1920wlight-group563">
                                      <div className="frame1920wlight-group564"></div>
                                    </div>
                                    <div className="frame1920wlight-group565">
                                      <div className="frame1920wlight-group566"></div>
                                    </div>
                                    <div className="frame1920wlight-group567">
                                      <div className="frame1920wlight-group568"></div>
                                    </div>
                                    <div className="frame1920wlight-group569">
                                      <div className="frame1920wlight-group570"></div>
                                    </div>
                                    <div className="frame1920wlight-group571">
                                      <div className="frame1920wlight-group572"></div>
                                    </div>
                                    <div className="frame1920wlight-group573">
                                      <div className="frame1920wlight-group574"></div>
                                    </div>
                                    <div className="frame1920wlight-group575">
                                      <div className="frame1920wlight-group576"></div>
                                    </div>
                                    <div className="frame1920wlight-group577">
                                      <img
                                        src="/rectanglei137-r5br-1200h.png"
                                        alt="RectangleI137"
                                        className="frame1920wlight-rectangle4"
                                      />
                                    </div>
                                    <div className="frame1920wlight-group578">
                                      <div className="frame1920wlight-group579"></div>
                                    </div>
                                    <div className="frame1920wlight-group580">
                                      <div className="frame1920wlight-group581"></div>
                                    </div>
                                    <div className="frame1920wlight-group582">
                                      <div className="frame1920wlight-group583"></div>
                                    </div>
                                    <div className="frame1920wlight-group584">
                                      <div className="frame1920wlight-group585"></div>
                                    </div>
                                    <div className="frame1920wlight-group586">
                                      <div className="frame1920wlight-group587"></div>
                                    </div>
                                    <div className="frame1920wlight-group588">
                                      <div className="frame1920wlight-group589"></div>
                                    </div>
                                    <div className="frame1920wlight-group590">
                                      <div className="frame1920wlight-group591"></div>
                                    </div>
                                    <div className="frame1920wlight-group592">
                                      <div className="frame1920wlight-group593"></div>
                                    </div>
                                    <div className="frame1920wlight-group594">
                                      <div className="frame1920wlight-group595"></div>
                                    </div>
                                    <div className="frame1920wlight-group596">
                                      <div className="frame1920wlight-group597"></div>
                                    </div>
                                    <div className="frame1920wlight-group598">
                                      <div className="frame1920wlight-group599"></div>
                                    </div>
                                    <div className="frame1920wlight-group600">
                                      <div className="frame1920wlight-group601"></div>
                                    </div>
                                    <div className="frame1920wlight-group602">
                                      <div className="frame1920wlight-group603"></div>
                                    </div>
                                    <div className="frame1920wlight-group604">
                                      <div className="frame1920wlight-group605"></div>
                                    </div>
                                    <div className="frame1920wlight-group606">
                                      <div className="frame1920wlight-group607"></div>
                                    </div>
                                    <div className="frame1920wlight-group608">
                                      <div className="frame1920wlight-group609"></div>
                                    </div>
                                    <div className="frame1920wlight-group610">
                                      <div className="frame1920wlight-group611"></div>
                                    </div>
                                    <div className="frame1920wlight-group612">
                                      <div className="frame1920wlight-group613"></div>
                                    </div>
                                    <div className="frame1920wlight-group614">
                                      <div className="frame1920wlight-group615"></div>
                                    </div>
                                    <div className="frame1920wlight-group616">
                                      <div className="frame1920wlight-group617"></div>
                                    </div>
                                    <div className="frame1920wlight-group618">
                                      <div className="frame1920wlight-group619"></div>
                                    </div>
                                    <div className="frame1920wlight-group620">
                                      <div className="frame1920wlight-group621"></div>
                                    </div>
                                    <div className="frame1920wlight-group622">
                                      <div className="frame1920wlight-group623"></div>
                                    </div>
                                    <div className="frame1920wlight-group624">
                                      <div className="frame1920wlight-group625"></div>
                                    </div>
                                    <div className="frame1920wlight-group626">
                                      <div className="frame1920wlight-group627"></div>
                                    </div>
                                    <div className="frame1920wlight-group628">
                                      <div className="frame1920wlight-group629"></div>
                                    </div>
                                    <div className="frame1920wlight-group630">
                                      <div className="frame1920wlight-group631"></div>
                                      <div className="frame1920wlight-group632"></div>
                                      <div className="frame1920wlight-group633"></div>
                                      <div className="frame1920wlight-group634"></div>
                                      <div className="frame1920wlight-group635"></div>
                                      <div className="frame1920wlight-group636"></div>
                                      <div className="frame1920wlight-group637"></div>
                                      <div className="frame1920wlight-group638"></div>
                                      <div className="frame1920wlight-group639"></div>
                                      <div className="frame1920wlight-group640"></div>
                                      <div className="frame1920wlight-group641"></div>
                                      <div className="frame1920wlight-group642"></div>
                                      <div className="frame1920wlight-group643"></div>
                                      <div className="frame1920wlight-group644"></div>
                                      <div className="frame1920wlight-group645"></div>
                                      <div className="frame1920wlight-group646"></div>
                                      <div className="frame1920wlight-group647"></div>
                                      <div className="frame1920wlight-group648"></div>
                                      <div className="frame1920wlight-group649"></div>
                                      <div className="frame1920wlight-group650"></div>
                                      <div className="frame1920wlight-group651"></div>
                                      <div className="frame1920wlight-group652"></div>
                                      <div className="frame1920wlight-group653"></div>
                                      <div className="frame1920wlight-group654"></div>
                                      <div className="frame1920wlight-group655"></div>
                                      <div className="frame1920wlight-group656"></div>
                                      <div className="frame1920wlight-group657"></div>
                                      <div className="frame1920wlight-group658"></div>
                                      <div className="frame1920wlight-group659"></div>
                                      <div className="frame1920wlight-group660"></div>
                                      <div className="frame1920wlight-group661"></div>
                                      <div className="frame1920wlight-group662"></div>
                                      <div className="frame1920wlight-group663"></div>
                                      <div className="frame1920wlight-group664"></div>
                                      <div className="frame1920wlight-group665"></div>
                                      <div className="frame1920wlight-group666"></div>
                                      <div className="frame1920wlight-group667"></div>
                                      <div className="frame1920wlight-group668"></div>
                                      <div className="frame1920wlight-group669"></div>
                                      <div className="frame1920wlight-group670"></div>
                                      <div className="frame1920wlight-group671"></div>
                                      <div className="frame1920wlight-group672"></div>
                                      <div className="frame1920wlight-group673"></div>
                                      <div className="frame1920wlight-group674"></div>
                                      <div className="frame1920wlight-group675"></div>
                                      <div className="frame1920wlight-group676"></div>
                                      <div className="frame1920wlight-group677"></div>
                                      <div className="frame1920wlight-group678"></div>
                                      <div className="frame1920wlight-group679"></div>
                                      <div className="frame1920wlight-group680"></div>
                                      <div className="frame1920wlight-group681"></div>
                                      <div className="frame1920wlight-group682"></div>
                                      <div className="frame1920wlight-group683"></div>
                                      <div className="frame1920wlight-group684"></div>
                                      <div className="frame1920wlight-group685"></div>
                                      <div className="frame1920wlight-group686"></div>
                                      <div className="frame1920wlight-group687"></div>
                                      <div className="frame1920wlight-group688"></div>
                                      <div className="frame1920wlight-group689"></div>
                                      <div className="frame1920wlight-group690"></div>
                                      <div className="frame1920wlight-group691"></div>
                                      <div className="frame1920wlight-group692"></div>
                                      <div className="frame1920wlight-group693"></div>
                                      <div className="frame1920wlight-group694"></div>
                                      <div className="frame1920wlight-group695"></div>
                                      <div className="frame1920wlight-group696"></div>
                                      <div className="frame1920wlight-group697"></div>
                                      <div className="frame1920wlight-group698"></div>
                                      <div className="frame1920wlight-group699"></div>
                                      <div className="frame1920wlight-group700"></div>
                                      <div className="frame1920wlight-group701"></div>
                                      <div className="frame1920wlight-group702"></div>
                                      <div className="frame1920wlight-group703"></div>
                                      <div className="frame1920wlight-group704"></div>
                                      <div className="frame1920wlight-group705"></div>
                                      <div className="frame1920wlight-group706"></div>
                                      <div className="frame1920wlight-group707"></div>
                                      <div className="frame1920wlight-group708"></div>
                                      <div className="frame1920wlight-group709"></div>
                                      <div className="frame1920wlight-group710"></div>
                                      <div className="frame1920wlight-group711"></div>
                                      <div className="frame1920wlight-group712"></div>
                                      <div className="frame1920wlight-group713"></div>
                                      <div className="frame1920wlight-group714"></div>
                                      <div className="frame1920wlight-group715"></div>
                                      <div className="frame1920wlight-group716"></div>
                                      <div className="frame1920wlight-group717"></div>
                                      <div className="frame1920wlight-group718"></div>
                                      <div className="frame1920wlight-group719"></div>
                                      <div className="frame1920wlight-group720"></div>
                                      <div className="frame1920wlight-group721"></div>
                                      <div className="frame1920wlight-group722"></div>
                                      <div className="frame1920wlight-group723"></div>
                                      <div className="frame1920wlight-group724"></div>
                                      <div className="frame1920wlight-group725"></div>
                                      <div className="frame1920wlight-group726"></div>
                                      <div className="frame1920wlight-group727"></div>
                                      <div className="frame1920wlight-group728"></div>
                                      <div className="frame1920wlight-group729"></div>
                                      <div className="frame1920wlight-group730"></div>
                                      <div className="frame1920wlight-group731"></div>
                                      <div className="frame1920wlight-group732"></div>
                                      <div className="frame1920wlight-group733"></div>
                                      <div className="frame1920wlight-group734"></div>
                                      <div className="frame1920wlight-group735"></div>
                                      <div className="frame1920wlight-group736"></div>
                                      <div className="frame1920wlight-group737"></div>
                                      <div className="frame1920wlight-group738"></div>
                                      <div className="frame1920wlight-group739"></div>
                                      <div className="frame1920wlight-group740"></div>
                                      <div className="frame1920wlight-group741"></div>
                                      <div className="frame1920wlight-group742"></div>
                                      <div className="frame1920wlight-group743"></div>
                                      <div className="frame1920wlight-group744"></div>
                                      <div className="frame1920wlight-group745"></div>
                                      <div className="frame1920wlight-group746"></div>
                                      <div className="frame1920wlight-group747"></div>
                                      <div className="frame1920wlight-group748"></div>
                                      <div className="frame1920wlight-group749"></div>
                                      <div className="frame1920wlight-group750"></div>
                                      <div className="frame1920wlight-group751"></div>
                                      <div className="frame1920wlight-group752"></div>
                                      <div className="frame1920wlight-group753"></div>
                                      <div className="frame1920wlight-group754"></div>
                                      <div className="frame1920wlight-group755"></div>
                                      <div className="frame1920wlight-group756"></div>
                                      <div className="frame1920wlight-group757"></div>
                                      <div className="frame1920wlight-group758"></div>
                                      <div className="frame1920wlight-group759"></div>
                                    </div>
                                    <div className="frame1920wlight-group760">
                                      <div className="frame1920wlight-group761"></div>
                                      <div className="frame1920wlight-group762"></div>
                                      <div className="frame1920wlight-group763"></div>
                                      <div className="frame1920wlight-group764"></div>
                                      <div className="frame1920wlight-group765"></div>
                                      <div className="frame1920wlight-group766"></div>
                                      <div className="frame1920wlight-group767"></div>
                                      <div className="frame1920wlight-group768"></div>
                                      <div className="frame1920wlight-group769"></div>
                                      <div className="frame1920wlight-group770"></div>
                                      <div className="frame1920wlight-group771"></div>
                                      <div className="frame1920wlight-group772"></div>
                                      <div className="frame1920wlight-group773"></div>
                                      <div className="frame1920wlight-group774"></div>
                                      <div className="frame1920wlight-group775"></div>
                                      <div className="frame1920wlight-group776"></div>
                                      <div className="frame1920wlight-group777"></div>
                                      <div className="frame1920wlight-group778"></div>
                                      <div className="frame1920wlight-group779"></div>
                                      <div className="frame1920wlight-group780"></div>
                                      <div className="frame1920wlight-group781"></div>
                                      <div className="frame1920wlight-group782"></div>
                                      <div className="frame1920wlight-group783"></div>
                                      <div className="frame1920wlight-group784"></div>
                                      <div className="frame1920wlight-group785"></div>
                                      <div className="frame1920wlight-group786"></div>
                                      <div className="frame1920wlight-group787"></div>
                                      <div className="frame1920wlight-group788"></div>
                                      <div className="frame1920wlight-group789"></div>
                                      <div className="frame1920wlight-group790"></div>
                                      <div className="frame1920wlight-group791"></div>
                                      <div className="frame1920wlight-group792"></div>
                                      <div className="frame1920wlight-group793"></div>
                                      <div className="frame1920wlight-group794"></div>
                                      <div className="frame1920wlight-group795"></div>
                                      <div className="frame1920wlight-group796"></div>
                                      <div className="frame1920wlight-group797"></div>
                                      <div className="frame1920wlight-group798"></div>
                                      <div className="frame1920wlight-group799"></div>
                                      <div className="frame1920wlight-group800"></div>
                                      <div className="frame1920wlight-group801"></div>
                                      <div className="frame1920wlight-group802"></div>
                                      <div className="frame1920wlight-group803"></div>
                                      <div className="frame1920wlight-group804"></div>
                                      <div className="frame1920wlight-group805"></div>
                                      <div className="frame1920wlight-group806"></div>
                                      <div className="frame1920wlight-group807"></div>
                                      <div className="frame1920wlight-group808"></div>
                                      <div className="frame1920wlight-group809"></div>
                                      <div className="frame1920wlight-group810"></div>
                                      <div className="frame1920wlight-group811"></div>
                                      <div className="frame1920wlight-group812"></div>
                                      <div className="frame1920wlight-group813"></div>
                                      <div className="frame1920wlight-group814"></div>
                                    </div>
                                    <div className="frame1920wlight-group815">
                                      <div className="frame1920wlight-group816"></div>
                                    </div>
                                    <div className="frame1920wlight-group817">
                                      <div className="frame1920wlight-group818"></div>
                                    </div>
                                    <div className="frame1920wlight-group819">
                                      <div className="frame1920wlight-group820"></div>
                                    </div>
                                    <div className="frame1920wlight-group821">
                                      <div className="frame1920wlight-group822"></div>
                                    </div>
                                    <div className="frame1920wlight-group823">
                                      <div className="frame1920wlight-group824"></div>
                                      <div className="frame1920wlight-group825"></div>
                                      <div className="frame1920wlight-group826"></div>
                                      <div className="frame1920wlight-group827"></div>
                                      <div className="frame1920wlight-group828"></div>
                                      <div className="frame1920wlight-group829"></div>
                                      <div className="frame1920wlight-group830"></div>
                                      <div className="frame1920wlight-group831"></div>
                                      <div className="frame1920wlight-group832"></div>
                                      <div className="frame1920wlight-group833"></div>
                                      <div className="frame1920wlight-group834"></div>
                                      <div className="frame1920wlight-group835"></div>
                                      <div className="frame1920wlight-group836"></div>
                                      <div className="frame1920wlight-group837"></div>
                                      <div className="frame1920wlight-group838"></div>
                                      <div className="frame1920wlight-group839"></div>
                                      <div className="frame1920wlight-group840"></div>
                                      <div className="frame1920wlight-group841"></div>
                                      <div className="frame1920wlight-group842"></div>
                                      <div className="frame1920wlight-group843"></div>
                                      <div className="frame1920wlight-group844"></div>
                                      <div className="frame1920wlight-group845"></div>
                                      <div className="frame1920wlight-group846"></div>
                                      <div className="frame1920wlight-group847"></div>
                                      <div className="frame1920wlight-group848"></div>
                                      <div className="frame1920wlight-group849"></div>
                                      <div className="frame1920wlight-group850"></div>
                                      <div className="frame1920wlight-group851"></div>
                                      <div className="frame1920wlight-group852"></div>
                                      <div className="frame1920wlight-group853"></div>
                                      <div className="frame1920wlight-group854"></div>
                                      <div className="frame1920wlight-group855"></div>
                                      <div className="frame1920wlight-group856"></div>
                                      <div className="frame1920wlight-group857"></div>
                                      <div className="frame1920wlight-group858"></div>
                                      <div className="frame1920wlight-group859"></div>
                                      <div className="frame1920wlight-group860"></div>
                                      <div className="frame1920wlight-group861"></div>
                                      <div className="frame1920wlight-group862"></div>
                                      <div className="frame1920wlight-group863"></div>
                                      <div className="frame1920wlight-group864"></div>
                                      <div className="frame1920wlight-group865"></div>
                                      <div className="frame1920wlight-group866"></div>
                                      <div className="frame1920wlight-group867"></div>
                                      <div className="frame1920wlight-group868"></div>
                                      <div className="frame1920wlight-group869"></div>
                                      <div className="frame1920wlight-group870"></div>
                                      <div className="frame1920wlight-group871"></div>
                                      <div className="frame1920wlight-group872"></div>
                                      <div className="frame1920wlight-group873"></div>
                                      <div className="frame1920wlight-group874"></div>
                                      <div className="frame1920wlight-group875"></div>
                                      <div className="frame1920wlight-group876"></div>
                                      <div className="frame1920wlight-group877"></div>
                                      <div className="frame1920wlight-group878"></div>
                                      <div className="frame1920wlight-group879"></div>
                                      <div className="frame1920wlight-group880"></div>
                                      <div className="frame1920wlight-group881"></div>
                                      <div className="frame1920wlight-group882"></div>
                                      <div className="frame1920wlight-group883"></div>
                                      <div className="frame1920wlight-group884"></div>
                                      <div className="frame1920wlight-group885"></div>
                                      <div className="frame1920wlight-group886"></div>
                                      <div className="frame1920wlight-group887"></div>
                                      <div className="frame1920wlight-group888"></div>
                                      <div className="frame1920wlight-group889"></div>
                                      <div className="frame1920wlight-group890"></div>
                                      <div className="frame1920wlight-group891"></div>
                                      <div className="frame1920wlight-group892"></div>
                                      <div className="frame1920wlight-group893"></div>
                                      <div className="frame1920wlight-group894"></div>
                                      <div className="frame1920wlight-group895"></div>
                                      <div className="frame1920wlight-group896"></div>
                                      <div className="frame1920wlight-group897"></div>
                                      <div className="frame1920wlight-group898"></div>
                                      <div className="frame1920wlight-group899"></div>
                                      <div className="frame1920wlight-group900"></div>
                                      <div className="frame1920wlight-group901"></div>
                                    </div>
                                    <div className="frame1920wlight-group902">
                                      <div className="frame1920wlight-group903"></div>
                                    </div>
                                    <div className="frame1920wlight-group904">
                                      <div className="frame1920wlight-group905"></div>
                                    </div>
                                    <div className="frame1920wlight-group906">
                                      <div className="frame1920wlight-group907"></div>
                                    </div>
                                    <div className="frame1920wlight-group908">
                                      <div className="frame1920wlight-group909"></div>
                                    </div>
                                    <div className="frame1920wlight-group910">
                                      <div className="frame1920wlight-group911"></div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="frame1920wlight-group912">
                              <div className="frame1920wlight-group913"></div>
                            </div>
                            <div className="frame1920wlight-group914">
                              <div className="frame1920wlight-group915">
                                <img
                                  src="/vectori137-pjhd.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector437"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group916">
                              <div className="frame1920wlight-group917">
                                <img
                                  src="/vectori137-gf0x.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector438"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group918">
                              <div className="frame1920wlight-group919">
                                <img
                                  src="/vectori137-len.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector439"
                                />
                              </div>
                            </div>
                            <div className="frame1920wlight-group920">
                              <div className="frame1920wlight-group921">
                                <img
                                  src="/vectori137-pv38.svg"
                                  alt="VectorI137"
                                  className="frame1920wlight-vector440"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="frame1920wlight-section2">
                    <div className="frame1920wlight-heading21">
                      <span className="frame1920wlight-text146 www.bohmenergy.nlSemanticHeading22">
                        <span className="frame1920wlight-text147">
                          Waarom heb ik een
                          <span
                            dangerouslySetInnerHTML={{
                              __html: ' ',
                            }}
                          />
                        </span>
                        <span className="frame1920wlight-text148">
                          thuisbatterij
                        </span>
                        <span> nodig?</span>
                      </span>
                    </div>
                    <div className="frame1920wlight-container118">
                      <div className="frame1920wlight-container119">
                        <span className="frame1920wlight-text150 www.bohmenergy.nlOutfitLight6">
                          <span>
                            Bohm Energy staat klaar voor iedereen die de
                            controle over zijn energie terug wilt. Onze slimme
                            thuisbatterij beschermt je tegen de
                          </span>
                          <br></br>
                          <span>
                            afbouw van de salderingsregeling, maakt zonnepanelen
                            nog rendabeler, en handelt energie op een compleet
                            autonome wijze om
                          </span>
                          <br></br>
                          <span>
                            je ten alle tijden geld te besparen. Meer weten over
                            hoe onze slimme thuisbatterij energie inkoopt en
                            verkoopt? Lees dan verder
                          </span>
                          <br></br>
                          <span>hieronder.</span>
                        </span>
                      </div>
                      <div className="frame1920wlight-component14">
                        <div className="frame1920wlight-container120">
                          <span className="frame1920wlight-text158 www.bohmenergy.nlOutfitLight7">
                            Ontdek het product
                          </span>
                        </div>
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="BackgroundI153"
                          className="frame1920wlight-background18"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="BackgroundI153"
                          className="frame1920wlight-background19"
                        />
                      </div>
                    </div>
                    <div className="frame1920wlight-list1">
                      <div className="frame1920wlight-component41">
                        <div className="frame1920wlight-dots1">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef6596dotssvgfillI153"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef6596dotssvgfill1"
                          />
                        </div>
                        <div className="frame1920wlight-margin18">
                          <div className="frame1920wlight-background20">
                            <div className="frame1920wlight-container121">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="Component3I153"
                                className="frame1920wlight-component311"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-imgmargin10">
                          <div className="frame1920wlight-frame6578a5b54fa1fa278cef668csavemoneyjpg"></div>
                        </div>
                        <div className="frame1920wlight-imgmargin11">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef65b0savemoneysvgI153"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef65b0savemoneysvg"
                          />
                        </div>
                        <div className="frame1920wlight-heading3margin2">
                          <span className="frame1920wlight-text159 www.bohmenergy.nlSemanticHeading33">
                            Bespaar op kosten
                          </span>
                        </div>
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="BackgroundI153"
                          className="frame1920wlight-background21"
                        />
                        <div className="frame1920wlight-container122">
                          <div className="frame1920wlight-margin19">
                            <div className="frame1920wlight-container123">
                              <span className="frame1920wlight-text160 www.bohmenergy.nlOutfitLight4">
                                <span>
                                  Ervaar hoe Bohm Energy jouw energiegebruik
                                  transformeert.
                                </span>
                                <br></br>
                                <span>
                                  Onze apparaten werken samen met jouw
                                  zonnepanelen,
                                </span>
                                <br></br>
                                <span>
                                  waardoor je zelfconsumptie van elektriciteit
                                  van ±30% naar ±80%
                                </span>
                                <br></br>
                                <span>
                                  kan stijgen. Dit betekent een stabieler en
                                  efficiënter
                                </span>
                                <br></br>
                                <span>
                                  elektriciteitsnet voor jouw huis. Onze
                                  systemen passen zich snel
                                </span>
                                <br></br>
                                <span>
                                  aan marktveranderingen aan, waardoor jij
                                  energie voordelig
                                </span>
                                <br></br>
                                <span>
                                  kunt inkopen en verkopen voor maximale
                                  besparingen. Dit doen
                                </span>
                                <br></br>
                                <span>
                                  wij door middel van een dynamisch
                                  energiecontract. Hierbij
                                </span>
                                <br></br>
                                <span>
                                  geniet je altijd van de allerbeste prijs en
                                  hoef je nooit meer over
                                </span>
                                <br></br>
                                <span>
                                  te stappen van energiecontract. Bohm Energy,
                                  waar innovatie en
                                </span>
                                <br></br>
                                <span>
                                  efficiëntie leiden tot een duurzame en
                                  voordelige toekomst.
                                </span>
                              </span>
                            </div>
                          </div>
                          <div className="frame1920wlight-margin20">
                            <div className="frame1920wlight-container124">
                              <div className="frame1920wlight-heading32">
                                <span className="frame1920wlight-text182 www.bohmenergy.nlSemanticHeading33">
                                  Bespaar op kosten
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="frame1920wlight-component42">
                        <div className="frame1920wlight-dots2">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef6596dotssvgfillI155"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef6596dotssvgfill2"
                          />
                        </div>
                        <div className="frame1920wlight-margin21">
                          <div className="frame1920wlight-background22">
                            <div className="frame1920wlight-container125">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="Component3I155"
                                className="frame1920wlight-component312"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-imgmargin12">
                          <div className="frame1920wlight-frame6578a5b54fa1fa278cef668eprioritijpg"></div>
                        </div>
                        <div className="frame1920wlight-imgmargin13">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef65faprioritiiconsvgI155"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef65faprioritiiconsvg"
                          />
                        </div>
                        <div className="frame1920wlight-heading3margin3">
                          <span className="frame1920wlight-text183 www.bohmenergy.nlSemanticHeading33">
                            Duurzaamheid
                          </span>
                        </div>
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="BackgroundI155"
                          className="frame1920wlight-background23"
                        />
                        <div className="frame1920wlight-container126">
                          <div className="frame1920wlight-margin22">
                            <div className="frame1920wlight-container127">
                              <span className="frame1920wlight-text184 www.bohmenergy.nlOutfitLight4">
                                <span>
                                  Upgrade uw zonne-energiesysteem met onze
                                  geavanceerde
                                </span>
                                <br></br>
                                <span>
                                  batterijen. Door de zelfconsumptie te verhogen
                                  van ongeveer
                                </span>
                                <br></br>
                                <span>
                                  30% naar maar liefst 80%, minimaliseer je
                                  afhankelijkheid van
                                </span>
                                <br></br>
                                <span>
                                  het net, en maximaliseer je het gebruik van
                                  groene stroom. Onze
                                </span>
                                <br></br>
                                <span>
                                  toewijding aan duurzaamheid en veiligheid
                                  wordt weerspiegeld in
                                </span>
                                <br></br>
                                <span>
                                  het gebruik van LFP (LiFePO4) technologie.
                                  Deze kobaltvrije
                                </span>
                                <br></br>
                                <span>
                                  batterijen zijn niet alleen veiliger, maar ook
                                  beter voor mens en
                                </span>
                                <br></br>
                                <span>
                                  milieu. Sluit je aan bij de groene revolutie –
                                  kies voor
                                </span>
                                <br></br>
                                <span>
                                  duurzaamheid en efficiëntie met onze
                                  geavanceerde
                                </span>
                                <br></br>
                                <span>batterijtechnologie.</span>
                              </span>
                            </div>
                          </div>
                          <div className="frame1920wlight-margin23">
                            <div className="frame1920wlight-container128">
                              <div className="frame1920wlight-heading33">
                                <span className="frame1920wlight-text204 www.bohmenergy.nlSemanticHeading33">
                                  Duurzaamheid
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="frame1920wlight-component43">
                        <div className="frame1920wlight-dots3">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef6596dotssvgfillI157"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef6596dotssvgfill3"
                          />
                        </div>
                        <div className="frame1920wlight-margin24">
                          <div className="frame1920wlight-background24">
                            <div className="frame1920wlight-container129">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="Component3I157"
                                className="frame1920wlight-component313"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-imgmargin14">
                          <div className="frame1920wlight-frame6578a5b54fa1fa278cef668dquickjpg"></div>
                        </div>
                        <div className="frame1920wlight-imgmargin15">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef65c8quickiconsvgI157"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef65c8quickiconsvg"
                          />
                        </div>
                        <div className="frame1920wlight-heading3margin4">
                          <span className="frame1920wlight-text205 www.bohmenergy.nlSemanticHeading33">
                            Snel &amp; veilig installatieproces
                          </span>
                        </div>
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="BackgroundI157"
                          className="frame1920wlight-background25"
                        />
                        <div className="frame1920wlight-container130">
                          <div className="frame1920wlight-margin25">
                            <div className="frame1920wlight-container131">
                              <span className="frame1920wlight-text206 www.bohmenergy.nlOutfitLight4">
                                <span>
                                  Wij begrijpen het belang van veiligheid en
                                  kwaliteit in elk aspect
                                </span>
                                <br></br>
                                <span>
                                  van onze dienstverlening. Daarom worden al
                                  onze installaties en
                                </span>
                                <br></br>
                                <span>
                                  programmeringen uitgevoerd door professioneel
                                  getrainde
                                </span>
                                <br></br>
                                <span>
                                  monteurs. Ons team van experts garandeert niet
                                  alleen een
                                </span>
                                <br></br>
                                <span>
                                  veilige aansluiting, maar zorgt ook dat jouw
                                  thuisbatterij zo lang
                                </span>
                                <br></br>
                                <span>
                                  mogelijk optimaal presteert. Als kers op de
                                  taart, zorgen wij ook
                                </span>
                                <br></br>
                                <span>
                                  nog voor een snelle installatietijd van
                                  gemiddeld 2 uur! Vertrouw
                                </span>
                                <br></br>
                                <span>
                                  op ons voor de veiligste en meest betrouwbare
                                  oplossingen op
                                </span>
                                <br></br>
                                <span>de markt.</span>
                              </span>
                            </div>
                          </div>
                          <div className="frame1920wlight-margin26">
                            <div className="frame1920wlight-container132">
                              <div className="frame1920wlight-heading34">
                                <span className="frame1920wlight-text224 www.bohmenergy.nlSemanticHeading33">
                                  Snel &amp; veilig installatieproces
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="frame1920wlight-component44">
                        <div className="frame1920wlight-dots4">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef6596dotssvgfillI158"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef6596dotssvgfill4"
                          />
                        </div>
                        <div className="frame1920wlight-margin27">
                          <div className="frame1920wlight-background26">
                            <div className="frame1920wlight-container133">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="Component3I158"
                                className="frame1920wlight-component314"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-imgmargin16">
                          <div className="frame1920wlight-frame6578a5b54fa1fa278cef668fsuitablejpg"></div>
                        </div>
                        <div className="frame1920wlight-imgmargin17">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef6613suitableiconsvgI158"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef6613suitableiconsvg"
                          />
                        </div>
                        <div className="frame1920wlight-heading3margin5">
                          <span className="frame1920wlight-text225 www.bohmenergy.nlSemanticHeading33">
                            Ook zonder zonnepanelen rendabel
                          </span>
                        </div>
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="BackgroundI158"
                          className="frame1920wlight-background27"
                        />
                        <div className="frame1920wlight-container134">
                          <div className="frame1920wlight-margin28">
                            <div className="frame1920wlight-container135">
                              <span className="frame1920wlight-text226 www.bohmenergy.nlOutfitLight4">
                                <span>
                                  Geen zonnepanelen? Geen probleem! De Bohm
                                  Energy
                                </span>
                                <br></br>
                                <span>
                                  thuisbatterij biedt de oplossing. Ook zonder
                                  zonnepanelen haal je
                                </span>
                                <br></br>
                                <span>
                                  het maximale uit je energievoorziening met
                                  onze slimme
                                </span>
                                <br></br>
                                <span>
                                  thuisbatterij. In combinatie met een dynamisch
                                  energiecontract
                                </span>
                                <br></br>
                                <span>
                                  koopt de batterij goedkoop energie in wanneer
                                  de prijzen laag
                                </span>
                                <br></br>
                                <span>
                                  zijn. Je gebruikt wat je nodig hebt, en
                                  verkoopt de rest terug aan
                                </span>
                                <br></br>
                                <span>
                                  het net voor een hogere prijs. Dit systeem
                                  zorgt direct voor
                                </span>
                                <br></br>
                                <span>
                                  lagere stroomkosten, en je volgt alles
                                  eenvoudig via onze
                                </span>
                                <br></br>
                                <span>
                                  gebruiksvriendelijke app. Maak je huis
                                  energie-efficiënt met de
                                </span>
                                <br></br>
                                <span>
                                  Bohm Energy thuisbatterij – voor maximale
                                  besparing.
                                </span>
                              </span>
                            </div>
                          </div>
                          <div className="frame1920wlight-margin29">
                            <div className="frame1920wlight-container136">
                              <div className="frame1920wlight-heading35">
                                <span className="frame1920wlight-text246 www.bohmenergy.nlSemanticHeading33">
                                  Ook zonder zonnepanelen rendabel
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="frame1920wlight-header">
                    <div className="frame1920wlight-container137">
                      <div className="frame1920wlight-heading2margin1">
                        <div className="frame1920wlight-heading22">
                          <span className="frame1920wlight-text247 www.bohmenergy.nlSemanticHeading21">
                            <span className="frame1920wlight-text248">
                              Vraag nu de btw terug op jouw
                            </span>
                            <br></br>
                            <span className="frame1920wlight-text250">
                              thuisbatterij van
                              <span
                                dangerouslySetInnerHTML={{
                                  __html: ' ',
                                }}
                              />
                            </span>
                            <span>Bohm Energy</span>
                          </span>
                        </div>
                      </div>
                      <div className="frame1920wlight-margin30">
                        <div className="frame1920wlight-container138">
                          <span className="frame1920wlight-text252 www.bohmenergy.nlOutfitLight7">
                            <span className="frame1920wlight-text253">
                              Het is vanaf nu mogelijk om de btw op jou aanschaf
                              van een
                            </span>
                            <br></br>
                            <span className="frame1920wlight-text255">
                              thuisbatterij terug te vragen. In samenwerking met
                              <span
                                dangerouslySetInnerHTML={{
                                  __html: ' ',
                                }}
                              />
                            </span>
                            <span className="frame1920wlight-text256">
                              De Centrale
                            </span>
                            <br></br>
                            <span>verzorgen wij dit voor al onze klanten.</span>
                          </span>
                        </div>
                      </div>
                      <div className="frame1920wlight-frame65a7c9b1a11c27f5d9d7012cd3a55b7c89954fba9ee1a"></div>
                      <div className="frame1920wlight-component15">
                        <div className="frame1920wlight-container139">
                          <span className="frame1920wlight-text259 www.bohmenergy.nlOutfitLight7">
                            Contact
                          </span>
                        </div>
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="BackgroundI160"
                          className="frame1920wlight-background28"
                        />
                        <img
                          src="https://play.teleporthq.io/static/svg/default-img.svg"
                          alt="BackgroundI160"
                          className="frame1920wlight-background29"
                        />
                      </div>
                    </div>
                    <div className="frame1920wlight-container140">
                      <div className="frame1920wlight-frame68344e1e7547a210b1268d7e-jan-tafelpng"></div>
                    </div>
                  </div>
                  <div className="frame1920wlight-section3">
                    <div className="frame1920wlight-container141">
                      <div className="frame1920wlight-heading23">
                        <span className="frame1920wlight-text260 www.bohmenergy.nlSemanticHeading22">
                          <span className="frame1920wlight-text261">
                            Wat maakt dat Bohm Energy de
                            <span
                              dangerouslySetInnerHTML={{
                                __html: ' ',
                              }}
                            />
                          </span>
                          <span className="frame1920wlight-text262">
                            best presterende thuisbatterij
                          </span>
                          <br></br>
                          <span>heeft?</span>
                        </span>
                      </div>
                      <div className="frame1920wlight-container142">
                        <span className="frame1920wlight-text265 www.bohmenergy.nlOutfitLight7">
                          Ontdek hoe de innovatieve thuisbatterijen van Bohm
                          Energy duurzame energieopslag revolutioneren
                        </span>
                      </div>
                    </div>
                    <div className="frame1920wlight-list2">
                      <div className="frame1920wlight-listitem10">
                        <div className="frame1920wlight-container143">
                          <div className="frame1920wlight-container144">
                            <div className="frame1920wlight-imgmargin18">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="SVG6578a5b54fa1fa278cef6680perform1svg1608"
                                className="frame1920wlight-svg6578a5b54fa1fa278cef6680perform1svg"
                              />
                            </div>
                            <span className="frame1920wlight-text266 www.bohmenergy.nlOutfitRegular1">
                              Uitzonderlijke levensduur - 10.000 laadcycli
                            </span>
                            <div className="frame1920wlight-background30">
                              <div className="frame1920wlight-container145">
                                <img
                                  src="/component31609-nihs.svg"
                                  alt="Component31609"
                                  className="frame1920wlight-component315"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-container146">
                            <div className="frame1920wlight-container147"></div>
                            <div className="frame1920wlight-container148"></div>
                          </div>
                        </div>
                      </div>
                      <div className="frame1920wlight-listitem11">
                        <div className="frame1920wlight-container149">
                          <div className="frame1920wlight-container150">
                            <div className="frame1920wlight-imgmargin19">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="SVG6578a5b54fa1fa278cef6681perform2svg1610"
                                className="frame1920wlight-svg6578a5b54fa1fa278cef6681perform2svg"
                              />
                            </div>
                            <span className="frame1920wlight-text267 www.bohmenergy.nlOutfitRegular1">
                              De beste Garantie - 10 jaar productgarantie
                            </span>
                            <div className="frame1920wlight-background31">
                              <div className="frame1920wlight-container151">
                                <img
                                  src="/component31611-mbgr.svg"
                                  alt="Component31611"
                                  className="frame1920wlight-component316"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-container152">
                            <div className="frame1920wlight-container153"></div>
                            <div className="frame1920wlight-container154"></div>
                          </div>
                        </div>
                      </div>
                      <div className="frame1920wlight-listitem12">
                        <div className="frame1920wlight-container155">
                          <div className="frame1920wlight-container156">
                            <div className="frame1920wlight-imgmargin20">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="SVG6578a5b54fa1fa278cef6682perform3svg1612"
                                className="frame1920wlight-svg6578a5b54fa1fa278cef6682perform3svg"
                              />
                            </div>
                            <span className="frame1920wlight-text268 www.bohmenergy.nlOutfitRegular1">
                              Ongekende kracht - Binnen 1 uur opgeladen
                            </span>
                            <div className="frame1920wlight-background32">
                              <div className="frame1920wlight-container157">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="Component31613"
                                  className="frame1920wlight-component317"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-container158">
                            <div className="frame1920wlight-container159"></div>
                            <div className="frame1920wlight-container160"></div>
                          </div>
                        </div>
                      </div>
                      <div className="frame1920wlight-listitem13">
                        <div className="frame1920wlight-container161">
                          <div className="frame1920wlight-container162">
                            <div className="frame1920wlight-imgmargin21">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="SVG6578a5b54fa1fa278cef6683perform4svg1614"
                                className="frame1920wlight-svg6578a5b54fa1fa278cef6683perform4svg"
                              />
                            </div>
                            <span className="frame1920wlight-text269 www.bohmenergy.nlOutfitRegular1">
                              Topkwaliteit Service - 7 dagen per week bereikbaar
                            </span>
                            <div className="frame1920wlight-background33">
                              <div className="frame1920wlight-container163">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="Component31615"
                                  className="frame1920wlight-component318"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-container164">
                            <div className="frame1920wlight-container165"></div>
                            <div className="frame1920wlight-container166"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="frame1920wlight-section4">
                    <div className="frame1920wlight-margin31">
                      <div className="frame1920wlight-horizontal-border1">
                        <div className="frame1920wlight-container167">
                          <span className="frame1920wlight-text270 www.bohmenergy.nlSemanticHeading2">
                            Over Bohm Energy
                          </span>
                        </div>
                        <div className="frame1920wlight-container168">
                          <div className="frame1920wlight-margin32">
                            <div className="frame1920wlight-container169">
                              <span className="frame1920wlight-text271 www.bohmenergy.nlOutfitLight7">
                                <span className="frame1920wlight-text272">
                                  Met Bohm Energy is installatie snel, eenvoudig
                                  en veilig. Ons vakkundig team garandeert
                                </span>
                                <br></br>
                                <span className="frame1920wlight-text274">
                                  professionele installatie en programmering -
                                  en zorgt voor langdurige duurzaamheid. Onze
                                </span>
                                <br></br>
                                <span className="frame1920wlight-text276">
                                  LFP (LiFeP04)
                                </span>
                                <span className="frame1920wlight-text277">
                                  {' '}
                                  batterijtechnologie geeft prioriteit aan
                                  veiligheid, biedt verbeterde
                                </span>
                                <br></br>
                                <span className="frame1920wlight-text279">
                                  bescherming en minimaliseert potentiële
                                  gevaren. Onze
                                  <span
                                    dangerouslySetInnerHTML={{
                                      __html: ' ',
                                    }}
                                  />
                                </span>
                                <span className="frame1920wlight-text280">
                                  thuisbatterij
                                </span>
                                <span className="frame1920wlight-text281">
                                  {' '}
                                  is ook ontworpen om
                                </span>
                                <br></br>
                                <span className="frame1920wlight-text283">
                                  compatibel te zijn met
                                  <span
                                    dangerouslySetInnerHTML={{
                                      __html: ' ',
                                    }}
                                  />
                                </span>
                                <span className="frame1920wlight-text284">
                                  elke PV-omvormer
                                </span>
                                <span className="frame1920wlight-text285">
                                  {' '}
                                  voor flexibiliteit en gebruiksgemak. Tot slot
                                  maken
                                </span>
                                <br></br>
                                <span className="frame1920wlight-text287">
                                  wij de overstap naar een
                                  <span
                                    dangerouslySetInnerHTML={{
                                      __html: ' ',
                                    }}
                                  />
                                </span>
                                <span className="frame1920wlight-text288">
                                  dynamisch energiecontract
                                </span>
                                <span> gemakkelijk en snel.</span>
                              </span>
                            </div>
                          </div>
                          <div className="frame1920wlight-component16">
                            <div className="frame1920wlight-container170">
                              <span className="frame1920wlight-text290 www.bohmenergy.nlOutfitLight7">
                                Contact
                              </span>
                            </div>
                            <img
                              src="https://play.teleporthq.io/static/svg/default-img.svg"
                              alt="BackgroundI161"
                              className="frame1920wlight-background34"
                            />
                            <img
                              src="https://play.teleporthq.io/static/svg/default-img.svg"
                              alt="BackgroundI161"
                              className="frame1920wlight-background35"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="frame1920wlight-container171">
                      <div className="frame1920wlight-container172">
                        <div className="frame1920wlight-icon1">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef6589abouticon1svgfill1618"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef6589abouticon1svgfill"
                          />
                        </div>
                        <span className="frame1920wlight-text291 www.bohmenergy.nlSemanticHeading32">
                          #1
                        </span>
                        <span className="frame1920wlight-text292 www.bohmenergy.nlSemanticLink">
                          <span>Installateur van thuisbatterijen in</span>
                          <br></br>
                          <span>Nederland</span>
                        </span>
                      </div>
                      <div className="frame1920wlight-container173">
                        <div className="frame1920wlight-icon2">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef6588abouticon2svgfill1619"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef6588abouticon2svgfill"
                          />
                        </div>
                        <span className="frame1920wlight-text296 www.bohmenergy.nlSemanticHeading32">
                          8000kW
                        </span>
                        <span className="frame1920wlight-text297 www.bohmenergy.nlSemanticLink">
                          Aan opslag geïnstalleerd
                        </span>
                      </div>
                      <div className="frame1920wlight-container174">
                        <div className="frame1920wlight-icon3">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef658cabouticon3svgfill1620"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef658cabouticon3svgfill"
                          />
                        </div>
                        <span className="frame1920wlight-text298 www.bohmenergy.nlSemanticHeading32">
                          8+
                        </span>
                        <span className="frame1920wlight-text299 www.bohmenergy.nlSemanticLink">
                          <span>Jaar aan ervaring in de</span>
                          <br></br>
                          <span>duurzaamheidbranche</span>
                        </span>
                      </div>
                      <div className="frame1920wlight-container175">
                        <div className="frame1920wlight-icon4">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef658babouticon4svgfill1621"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef658babouticon4svgfill"
                          />
                        </div>
                        <span className="frame1920wlight-text303 www.bohmenergy.nlSemanticLink">
                          Weken super snelle levertijd
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="frame1920wlight-section68b5675cfb4f82f39162bb31hero2png"></div>
                  <div className="frame1920wlight-section5">
                    <div className="frame1920wlight-container176">
                      <div className="frame1920wlight-heading24">
                        <span className="frame1920wlight-text304 www.bohmenergy.nlSemanticHeading2">
                          Lees wat anderen van Bohm Energy vinden
                        </span>
                      </div>
                      <div className="frame1920wlight-container177">
                        <div className="frame1920wlight-container178">
                          <div className="frame1920wlight-margin33">
                            <div className="frame1920wlight-container179">
                              <div className="frame1920wlight-container180">
                                <div className="frame1920wlight-container181">
                                  <img
                                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                                    alt="Component31622"
                                    className="frame1920wlight-component319"
                                  />
                                </div>
                              </div>
                              <div className="frame1920wlight-container182">
                                <div className="frame1920wlight-container183">
                                  <img
                                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                                    alt="Component31623"
                                    className="frame1920wlight-component320"
                                  />
                                </div>
                              </div>
                              <div className="frame1920wlight-container184">
                                <div className="frame1920wlight-container185">
                                  <img
                                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                                    alt="Component31623"
                                    className="frame1920wlight-component321"
                                  />
                                </div>
                              </div>
                              <div className="frame1920wlight-container186">
                                <div className="frame1920wlight-container187">
                                  <img
                                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                                    alt="Component31624"
                                    className="frame1920wlight-component322"
                                  />
                                </div>
                              </div>
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="Rectangle1624"
                                className="frame1920wlight-rectangle5"
                              />
                            </div>
                          </div>
                          <div className="frame1920wlight-container188">
                            <span className="frame1920wlight-text305 www.bohmenergy.nlSemanticLink">
                              <span>
                                &quot;Wij zijn ontzettend blij met de
                                thuisbatterij van Bohmenergy.
                              </span>
                              <br></br>
                              <span>
                                Kundige en nette adviseur vanaf het eerste
                                telefoongesprek tot en met moment van plaatsing.
                              </span>
                              <br></br>
                              <span>Kortom, top service!&quot;</span>
                            </span>
                          </div>
                          <div className="frame1920wlight-margin34">
                            <div className="frame1920wlight-container189">
                              <div className="frame1920wlight-margin35">
                                <div className="frame1920wlight-img2">
                                  <img
                                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                                    alt="SVG6578a5b54fa1fa278cef658ffaviconsvgfill1625"
                                    className="frame1920wlight-svg6578a5b54fa1fa278cef658ffaviconsvgfill1"
                                  />
                                </div>
                              </div>
                              <div className="frame1920wlight-container190">
                                <div className="frame1920wlight-container191">
                                  <span className="frame1920wlight-text311 www.bohmenergy.nlSemanticLink1">
                                    Jessica Simons
                                  </span>
                                </div>
                                <div className="frame1920wlight-container192">
                                  <span className="frame1920wlight-text312 www.bohmenergy.nlSemanticLink">
                                    Bilthoven
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-container193">
                          <div className="frame1920wlight-margin36">
                            <div className="frame1920wlight-container194">
                              <div className="frame1920wlight-container195">
                                <div className="frame1920wlight-container196">
                                  <img
                                    src="https://play.teleporthq.io/static/svg/default-img.svg"
                                    alt="Component31626"
                                    className="frame1920wlight-component323"
                                  />
                                </div>
                              </div>
                              <div className="frame1920wlight-container197">
                                <div className="frame1920wlight-container198">
                                  <img
                                    src="/component31627-xle.svg"
                                    alt="Component31627"
                                    className="frame1920wlight-component324"
                                  />
                                </div>
                              </div>
                              <div className="frame1920wlight-container199">
                                <div className="frame1920wlight-container200">
                                  <img
                                    src="/component31627-8e0i.svg"
                                    alt="Component31627"
                                    className="frame1920wlight-component325"
                                  />
                                </div>
                              </div>
                              <div className="frame1920wlight-container201">
                                <div className="frame1920wlight-container202">
                                  <img
                                    src="/component31627-gcth.svg"
                                    alt="Component31627"
                                    className="frame1920wlight-component326"
                                  />
                                </div>
                              </div>
                              <div className="frame1920wlight-container203">
                                <div className="frame1920wlight-container204">
                                  <img
                                    src="/component31628-iixi.svg"
                                    alt="Component31628"
                                    className="frame1920wlight-component327"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-container205">
                            <span className="frame1920wlight-text313 www.bohmenergy.nlSemanticLink">
                              <span>
                                Ik ben enorm tevreden met mijn
                                thuisbatterijsysteem geïnstalleerd door Bohm
                                Energy. Het team
                              </span>
                              <br></br>
                              <span>
                                was professioneel en deskundig, en ze hebben een
                                systeem geleverd dat perfect past bij mijn
                              </span>
                              <br></br>
                              <span>
                                behoeften. De installatie verliep soepel en het
                                systeem werd met een mooie app opgeleverd. Ik
                              </span>
                              <br></br>
                              <span>
                                zie nu al een aanzienlijke vermindering in mijn
                                energierekening!
                              </span>
                            </span>
                          </div>
                          <div className="frame1920wlight-margin37">
                            <div className="frame1920wlight-container206">
                              <div className="frame1920wlight-margin38">
                                <div className="frame1920wlight-img3">
                                  <img
                                    src="/svg6578a5b54fa1fa278cef658ffaviconsvgfill1629-v1g.svg"
                                    alt="SVG6578a5b54fa1fa278cef658ffaviconsvgfill1629"
                                    className="frame1920wlight-svg6578a5b54fa1fa278cef658ffaviconsvgfill2"
                                  />
                                </div>
                              </div>
                              <div className="frame1920wlight-container207">
                                <div className="frame1920wlight-container208">
                                  <span className="frame1920wlight-text321 www.bohmenergy.nlSemanticLink1">
                                    Bram Jansen
                                  </span>
                                </div>
                                <div className="frame1920wlight-container209">
                                  <span className="frame1920wlight-text322 www.bohmenergy.nlSemanticLink">
                                    Vianen
                                  </span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="frame1920wlight-section6">
                    <div className="frame1920wlight-container210">
                      <div className="frame1920wlight-container211">
                        <div className="frame1920wlight-heading2margin2">
                          <div className="frame1920wlight-heading25">
                            <span className="frame1920wlight-text323 www.bohmenergy.nlSemanticHeading2">
                              Veelgestelde vragen
                            </span>
                          </div>
                        </div>
                        <div className="frame1920wlight-container212">
                          <span className="frame1920wlight-text324 www.bohmenergy.nlOutfitLight6">
                            <span>
                              Heb je nog vragen over Bohm Energy en onze
                              duurzame
                            </span>
                            <br></br>
                            <span>
                              energieoplossingen? Wij hebben de antwoorden.
                              Bekijk de meest
                            </span>
                            <br></br>
                            <span>
                              gestelde vragen en ontdek hoe onze producten het
                              energieverbruik van
                            </span>
                            <br></br>
                            <span>jouw huis kunnen optimaliseren</span>
                          </span>
                        </div>
                      </div>
                      <div className="frame1920wlight-container213">
                        <div className="frame1920wlight-margin39">
                          <div className="frame1920wlight-container214">
                            <span className="frame1920wlight-text332 www.bohmenergy.nlSemanticLink">
                              <span>
                                Als je niet vindt wat je zoekt, aarzel dan niet
                                om contact op te nemen met ons
                              </span>
                              <br></br>
                              <span>
                                deskundige team voor persoonlijke hulp
                              </span>
                            </span>
                          </div>
                        </div>
                        <div className="frame1920wlight-linkmargin11">
                          <div className="frame1920wlight-component212">
                            <span className="frame1920wlight-text336 www.bohmenergy.nlOutfitRegular">
                              (+31)85-7606981
                            </span>
                          </div>
                        </div>
                        <div className="frame1920wlight-linkmargin12">
                          <div className="frame1920wlight-component213">
                            <span className="frame1920wlight-text337 www.bohmenergy.nlOutfitRegular">
                              info@bohmenergy.nl
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="frame1920wlight-container215">
                      <div className="frame1920wlight-list3">
                        <div className="frame1920wlight-listitem14">
                          <div className="frame1920wlight-container216">
                            <div className="frame1920wlight-container217">
                              <span className="frame1920wlight-text338 www.bohmenergy.nlOutfitRegular">
                                Waar kan ik de thuisbatterij het beste plaatsen?
                              </span>
                            </div>
                            <div className="frame1920wlight-background36">
                              <div className="frame1920wlight-container218">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="Component31632"
                                  className="frame1920wlight-component328"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-horizontal-border2">
                            <div className="frame1920wlight-container219">
                              <span className="frame1920wlight-text339 www.bohmenergy.nlOutfitLight3">
                                Onze thuisbatterij is 54 cm breed, 59 cm hoog en
                                24 cm diep, per batterij. Dit
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-listitem15">
                          <div className="frame1920wlight-container220">
                            <div className="frame1920wlight-container221">
                              <span className="frame1920wlight-text340 www.bohmenergy.nlOutfitRegular">
                                Ik heb geen zonnepanelen, kan ik ook besparen?
                              </span>
                            </div>
                            <div className="frame1920wlight-background37">
                              <div className="frame1920wlight-container222">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="Component31634"
                                  className="frame1920wlight-component329"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-horizontal-border3">
                            <div className="frame1920wlight-container223">
                              <span className="frame1920wlight-text341 www.bohmenergy.nlOutfitLight3">
                                Ook zonder zonnepanelen kan je besparen met een
                                thuisbatterij. De batterij
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-listitem16">
                          <div className="frame1920wlight-container224">
                            <div className="frame1920wlight-container225">
                              <span className="frame1920wlight-text342 www.bohmenergy.nlOutfitRegular">
                                Wat is een dynamisch energiecontract?
                              </span>
                            </div>
                            <div className="frame1920wlight-background38">
                              <div className="frame1920wlight-container226">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="Component31635"
                                  className="frame1920wlight-component330"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-horizontal-border4">
                            <div className="frame1920wlight-container227">
                              <span className="frame1920wlight-text343 www.bohmenergy.nlOutfitLight3">
                                Een dynamisch energiecontract is een contract
                                waarbij de stroomprijs per uur
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-listitem17">
                          <div className="frame1920wlight-container228">
                            <div className="frame1920wlight-container229">
                              <span className="frame1920wlight-text344 www.bohmenergy.nlOutfitRegular">
                                Hoe installeer ik de batterij?
                              </span>
                            </div>
                            <div className="frame1920wlight-background39">
                              <div className="frame1920wlight-container230">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="Component31636"
                                  className="frame1920wlight-component331"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-horizontal-border5">
                            <div className="frame1920wlight-container231">
                              <span className="frame1920wlight-text345 www.bohmenergy.nlOutfitLight3">
                                Installatie is onderdeel van onze service. We
                                geven prioriteit aan de veiligheid
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-listitem18">
                          <div className="frame1920wlight-container232">
                            <div className="frame1920wlight-container233">
                              <span className="frame1920wlight-text346 www.bohmenergy.nlOutfitRegular">
                                Kan ik meerdere thuisbatterijen aansluiten?
                              </span>
                            </div>
                            <div className="frame1920wlight-background40">
                              <div className="frame1920wlight-container234">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="Component31637"
                                  className="frame1920wlight-component332"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-horizontal-border6">
                            <div className="frame1920wlight-container235">
                              <span className="frame1920wlight-text347 www.bohmenergy.nlOutfitLight3">
                                Ja, het is mogelijk om meerdere thuisbatterijen
                                aan te sluiten. Dit kan tot 8
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-listitem19">
                          <div className="frame1920wlight-container236">
                            <div className="frame1920wlight-container237">
                              <span className="frame1920wlight-text348 www.bohmenergy.nlOutfitRegular">
                                Hoeveel geld kan ik besparen?
                              </span>
                            </div>
                            <div className="frame1920wlight-background41">
                              <div className="frame1920wlight-container238">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="Component31639"
                                  className="frame1920wlight-component333"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-horizontal-border7">
                            <div className="frame1920wlight-container239">
                              <span className="frame1920wlight-text349 www.bohmenergy.nlOutfitLight3">
                                Dit hangt af van een aantal factoren. De
                                opslagcapaciteit van jouw
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-listitem20">
                          <div className="frame1920wlight-container240">
                            <div className="frame1920wlight-container241">
                              <span className="frame1920wlight-text350 www.bohmenergy.nlOutfitRegular">
                                Is een thuisbatterij veilig?
                              </span>
                            </div>
                            <div className="frame1920wlight-background42">
                              <div className="frame1920wlight-container242">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="Component31640"
                                  className="frame1920wlight-component334"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-horizontal-border8">
                            <div className="frame1920wlight-container243">
                              <span className="frame1920wlight-text351 www.bohmenergy.nlOutfitLight3">
                                LFP-batterijen behoren tot de veiligste soort
                                lithium-ion batterijen, met een
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="frame1920wlight-section7">
                    <div className="frame1920wlight-container244">
                      <div className="frame1920wlight-container245">
                        <div className="frame1920wlight-heading26">
                          <span className="frame1920wlight-text352 www.bohmenergy.nlSemanticHeading2">
                            Inzichten &amp; Nieuws
                          </span>
                        </div>
                        <div className="frame1920wlight-link1">
                          <span className="frame1920wlight-text353 www.bohmenergy.nlSemanticLink2">
                            Bekijk de nieuwste artikelen over de laatste
                            ontwikkelingen in techniek &amp; dynamische energie
                          </span>
                          <div className="frame1920wlight-imgarrowmargin">
                            <div className="frame1920wlight-arrow1">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="SVG6578a5b54fa1fa278cef6595arrowsvgfill1642"
                                className="frame1920wlight-svg6578a5b54fa1fa278cef6595arrowsvgfill"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="frame1920wlight-container246">
                        <div className="frame1920wlight-list4">
                          <div className="frame1920wlight-group16margin">
                            <div className="frame1920wlight-component51">
                              <div className="frame1920wlight-link2">
                                <div className="frame1920wlight-frame68b55fa3dd267b9137d47455-blog20-energyzerojpg"></div>
                                <div className="frame1920wlight-container247">
                                  <div className="frame1920wlight-container248">
                                    <div className="frame1920wlight-border1">
                                      <span className="frame1920wlight-text354 www.bohmenergy.nlSemanticLink1">
                                        News
                                      </span>
                                    </div>
                                    <div className="frame1920wlight-background43">
                                      <div className="frame1920wlight-arrow2">
                                        <img
                                          src="/svg6578a5b54fa1fa278cef6594arrowwhitesvgfilli164-e9nu.svg"
                                          alt="SVG6578a5b54fa1fa278cef6594arrowwhitesvgfillI164"
                                          className="frame1920wlight-svg6578a5b54fa1fa278cef6594arrowwhitesvgfill1"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div className="frame1920wlight-heading36">
                                    <span className="frame1920wlight-text355 www.bohmenergy.nlSemanticHeading3">
                                      <span>EnergyZero schakelt over op</span>
                                      <br></br>
                                      <span>kwartierprijzen per 2026</span>
                                    </span>
                                  </div>
                                  <div className="frame1920wlight-container249">
                                    <div className="frame1920wlight-margin40">
                                      <div className="frame1920wlight-container250"></div>
                                    </div>
                                    <div className="frame1920wlight-container251">
                                      <span className="frame1920wlight-text359 www.bohmenergy.nlSemanticLink">
                                        min read
                                      </span>
                                    </div>
                                    <div className="frame1920wlight-margin41">
                                      <div className="frame1920wlight-container252">
                                        <span className="frame1920wlight-text360 www.bohmenergy.nlSemanticLink">
                                          September 2025
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-group26margin">
                            <div className="frame1920wlight-component52">
                              <div className="frame1920wlight-link3">
                                <div className="frame1920wlight-frame688c8042c3acc2154186af34-post5-webpng"></div>
                                <div className="frame1920wlight-container253">
                                  <div className="frame1920wlight-container254">
                                    <div className="frame1920wlight-border2">
                                      <span className="frame1920wlight-text361 www.bohmenergy.nlSemanticLink1">
                                        Blog
                                      </span>
                                    </div>
                                    <div className="frame1920wlight-background44">
                                      <div className="frame1920wlight-arrow3">
                                        <img
                                          src="/svg6578a5b54fa1fa278cef6594arrowwhitesvgfilli164-25g.svg"
                                          alt="SVG6578a5b54fa1fa278cef6594arrowwhitesvgfillI164"
                                          className="frame1920wlight-svg6578a5b54fa1fa278cef6594arrowwhitesvgfill2"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div className="frame1920wlight-heading37">
                                    <span className="frame1920wlight-text362 www.bohmenergy.nlSemanticHeading3">
                                      <span>
                                        🔋 Waarom steeds meer Nederlanders
                                      </span>
                                      <br></br>
                                      <span>
                                        deze zomer een thuisbatterij laten
                                      </span>
                                      <br></br>
                                      <span>installeren</span>
                                    </span>
                                  </div>
                                  <div className="frame1920wlight-container255">
                                    <div className="frame1920wlight-margin42">
                                      <div className="frame1920wlight-container256"></div>
                                    </div>
                                    <div className="frame1920wlight-container257">
                                      <span className="frame1920wlight-text368 www.bohmenergy.nlSemanticLink">
                                        min read
                                      </span>
                                    </div>
                                    <div className="frame1920wlight-margin43">
                                      <div className="frame1920wlight-container258">
                                        <span className="frame1920wlight-text369 www.bohmenergy.nlSemanticLink">
                                          August 2025
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-group36margin">
                            <div className="frame1920wlight-component53">
                              <div className="frame1920wlight-link4">
                                <div className="frame1920wlight-frame684959d8f6912a16fea52114-blog20-onbalanshandele"></div>
                                <div className="frame1920wlight-container259">
                                  <div className="frame1920wlight-container260">
                                    <div className="frame1920wlight-border3">
                                      <span className="frame1920wlight-text370 www.bohmenergy.nlSemanticLink1">
                                        Blog
                                      </span>
                                    </div>
                                    <div className="frame1920wlight-background45">
                                      <div className="frame1920wlight-arrow4">
                                        <img
                                          src="/svg6578a5b54fa1fa278cef6594arrowwhitesvgfilli164-i7im.svg"
                                          alt="SVG6578a5b54fa1fa278cef6594arrowwhitesvgfillI164"
                                          className="frame1920wlight-svg6578a5b54fa1fa278cef6594arrowwhitesvgfill3"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                  <div className="frame1920wlight-heading38">
                                    <span className="frame1920wlight-text371 www.bohmenergy.nlSemanticHeading3">
                                      <span>🏠 Zelfconsumptie Plus vs.</span>
                                      <br></br>
                                      <span>Onbalanshandelen: Haal het</span>
                                      <br></br>
                                      <span>maximale uit je thuisbatterij</span>
                                    </span>
                                  </div>
                                  <div className="frame1920wlight-container261">
                                    <div className="frame1920wlight-margin44">
                                      <div className="frame1920wlight-container262"></div>
                                    </div>
                                    <div className="frame1920wlight-container263">
                                      <span className="frame1920wlight-text377 www.bohmenergy.nlSemanticLink">
                                        min read
                                      </span>
                                    </div>
                                    <div className="frame1920wlight-margin45">
                                      <div className="frame1920wlight-container264">
                                        <span className="frame1920wlight-text378 www.bohmenergy.nlSemanticLink">
                                          July 2025
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-group46margin"></div>
                          <div className="frame1920wlight-group56margin"></div>
                          <div className="frame1920wlight-group66margin"></div>
                        </div>
                        <div className="frame1920wlight-container265">
                          <button className="frame1920wlight-button-previousslidemargin">
                            <button className="frame1920wlight-button-previousslide">
                              <div className="frame1920wlight-arrow5">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="SVG6578a5b54fa1fa278cef65a3arrowrightsvgfill1652"
                                  className="frame1920wlight-svg6578a5b54fa1fa278cef65a3arrowrightsvgfill1"
                                />
                              </div>
                            </button>
                          </button>
                          <button className="frame1920wlight-button-nextslide">
                            <div className="frame1920wlight-arrow6">
                              <img
                                src="https://play.teleporthq.io/static/svg/default-img.svg"
                                alt="SVG6578a5b54fa1fa278cef65a3arrowrightsvgfill1653"
                                className="frame1920wlight-svg6578a5b54fa1fa278cef65a3arrowrightsvgfill2"
                              />
                            </div>
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="frame1920wlight-footer">
                    <div className="frame1920wlight-container266">
                      <div className="frame1920wlight-horizontal-border9">
                        <div className="frame1920wlight-container267">
                          <div className="frame1920wlight-linkmargin13">
                            <div className="frame1920wlight-link5">
                              <div className="frame1920wlight-logo2">
                                <img
                                  src="https://play.teleporthq.io/static/svg/default-img.svg"
                                  alt="SVG6578a5b54fa1fa278cef6591footerlogosvgfill1657"
                                  className="frame1920wlight-svg6578a5b54fa1fa278cef6591footerlogosvgfill2"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-linkmargin14">
                            <div className="frame1920wlight-component214">
                              <span className="frame1920wlight-text379 www.bohmenergy.nlOutfitLight3">
                                (+31) 85-7606981
                              </span>
                            </div>
                          </div>
                          <div className="frame1920wlight-linkmargin15">
                            <div className="frame1920wlight-component215">
                              <span className="frame1920wlight-text380 www.bohmenergy.nlOutfitLight3">
                                info@bohmenergy.nl
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-container268">
                          <span className="frame1920wlight-text381 www.bohmenergy.nlOutfitLight10">
                            <span>Hogebrinkerweg 14m</span>
                            <br></br>
                            <span>3871 KM, Hoevelaken</span>
                          </span>
                        </div>
                        <div className="frame1920wlight-container269">
                          <div className="frame1920wlight-container270">
                            <div className="frame1920wlight-margin46">
                              <div className="frame1920wlight-container271">
                                <span className="frame1920wlight-text385 www.bohmenergy.nlOutfitLight3">
                                  About
                                </span>
                              </div>
                            </div>
                            <div className="frame1920wlight-linkmargin16">
                              <div className="frame1920wlight-component216">
                                <span className="frame1920wlight-text386 www.bohmenergy.nlOutfitLight1">
                                  Zonnepanelen
                                </span>
                              </div>
                            </div>
                            <div className="frame1920wlight-linkmargin17">
                              <div className="frame1920wlight-component217">
                                <span className="frame1920wlight-text387 www.bohmenergy.nlOutfitLight1">
                                  Thuisbatterij
                                </span>
                              </div>
                            </div>
                            <div className="frame1920wlight-linkmargin18">
                              <div className="frame1920wlight-component218">
                                <span className="frame1920wlight-text388 www.bohmenergy.nlOutfitLight1">
                                  Over ons
                                </span>
                              </div>
                            </div>
                            <div className="frame1920wlight-linkmargin19">
                              <div className="frame1920wlight-component219">
                                <span className="frame1920wlight-text389 www.bohmenergy.nlOutfitLight1">
                                  Blog
                                </span>
                              </div>
                            </div>
                            <div className="frame1920wlight-linkmargin20">
                              <div className="frame1920wlight-component220">
                                <span className="frame1920wlight-text390 www.bohmenergy.nlOutfitLight1">
                                  Product
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-container272">
                            <div className="frame1920wlight-margin47">
                              <div className="frame1920wlight-container273">
                                <span className="frame1920wlight-text391 www.bohmenergy.nlOutfitLight3">
                                  Support
                                </span>
                              </div>
                            </div>
                            <div className="frame1920wlight-linkmargin21">
                              <div className="frame1920wlight-component221">
                                <span className="frame1920wlight-text392 www.bohmenergy.nlOutfitLight1">
                                  Contact
                                </span>
                              </div>
                            </div>
                            <div className="frame1920wlight-linkmargin22">
                              <div className="frame1920wlight-component222">
                                <span className="frame1920wlight-text393 www.bohmenergy.nlOutfitLight1">
                                  Privacy Policy
                                </span>
                              </div>
                            </div>
                            <div className="frame1920wlight-linkmargin23">
                              <div className="frame1920wlight-component223">
                                <span className="frame1920wlight-text394 www.bohmenergy.nlOutfitLight1">
                                  Terms of Service
                                </span>
                              </div>
                            </div>
                          </div>
                          <div className="frame1920wlight-container274">
                            <div className="frame1920wlight-margin48">
                              <div className="frame1920wlight-container275">
                                <span className="frame1920wlight-text395 www.bohmenergy.nlOutfitLight3">
                                  Connect
                                </span>
                              </div>
                            </div>
                            <div className="frame1920wlight-linkmargin24">
                              <div className="frame1920wlight-component224">
                                <span className="frame1920wlight-text396 www.bohmenergy.nlOutfitLight1">
                                  LinkedIn
                                </span>
                              </div>
                            </div>
                            <div className="frame1920wlight-linkmargin25">
                              <div className="frame1920wlight-component225">
                                <span className="frame1920wlight-text397 www.bohmenergy.nlOutfitLight1">
                                  Instagram
                                </span>
                              </div>
                            </div>
                            <div className="frame1920wlight-linkmargin26">
                              <div className="frame1920wlight-component226">
                                <span className="frame1920wlight-text398 www.bohmenergy.nlOutfitLight1">
                                  Facebook
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="frame1920wlight-container276">
                        <div className="frame1920wlight-container277">
                          <span className="frame1920wlight-text399 www.bohmenergy.nlOutfitLight">
                            2023 Bohm Energy. All right reserved.
                          </span>
                        </div>
                        <div className="frame1920wlight-container278">
                          <span className="frame1920wlight-text400 www.bohmenergy.nlOutfitLight">
                            designed by 
                          </span>
                          <div className="frame1920wlight-component227">
                            <span className="frame1920wlight-text401 www.bohmenergy.nlOutfitLight">
                              celerart
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="frame1920wlight-container279">
                    <div className="frame1920wlight-container280">
                      <div className="frame1920wlight-background-border">
                        <div className="frame1920wlight-container281">
                          <span className="frame1920wlight-text402 www.bohmenergy.nlSemanticHeading4">
                            Wij gebruiken cookies
                          </span>
                          <div className="frame1920wlight-container282">
                            <span className="frame1920wlight-text403 www.bohmenergy.nlOutfitLight">
                              <span>
                                Onze website gebruikt cookies. Door verder te
                                navigeren, gaan we ervan uit dat u toestemming
                                geeft
                              </span>
                              <br></br>
                              <span>
                                voor het gebruik van cookies zoals beschreven in
                                onze
                                <span
                                  dangerouslySetInnerHTML={{
                                    __html: ' ',
                                  }}
                                />
                              </span>
                            </span>
                            <div className="frame1920wlight-component228">
                              <span className="frame1920wlight-text407 www.bohmenergy.nlOutfitLight">
                                Privacy Policy.
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="frame1920wlight-container283">
                          <img
                            src="https://play.teleporthq.io/static/svg/default-img.svg"
                            alt="SVG6578a5b54fa1fa278cef65a6closecookiesvg1671"
                            className="frame1920wlight-svg6578a5b54fa1fa278cef65a6closecookiesvg"
                          />
                        </div>
                        <button className="frame1920wlight-buttonmargin">
                          <div className="frame1920wlight-component17">
                            <div className="frame1920wlight-container284">
                              <span className="frame1920wlight-text408 www.bohmenergy.nlOutfitLight7">
                                Contact
                              </span>
                            </div>
                            <img
                              src="https://play.teleporthq.io/static/svg/default-img.svg"
                              alt="BackgroundI167"
                              className="frame1920wlight-background46"
                            />
                            <img
                              src="https://play.teleporthq.io/static/svg/default-img.svg"
                              alt="BackgroundI167"
                              className="frame1920wlight-background47"
                            />
                          </div>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <a
          href="https://play.teleporthq.io/signup"
          className="frame1920wlight-link6"
        >
          <div
            aria-label="Sign up to TeleportHQ"
            className="frame1920wlight-container285"
          >
            <svg
              width="24"
              height="24"
              viewBox="0 0 19 21"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              className="frame1920wlight-icon5"
            >
              <path
                d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
                fill="#B23ADE"
              ></path>
              <path
                d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
                fill="#FF5C5C"
              ></path>
              <path
                d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
                fill="#2874DE"
              ></path>
            </svg>
            <span className="frame1920wlight-text409">Built in TeleportHQ</span>
          </div>
        </a>
      </div>
      <style jsx>
        {`
          .frame1920wlight-container100 {
            width: 100%;
            display: flex;
            overflow: auto;
            min-height: 100vh;
            align-items: center;
            flex-direction: column;
          }
          .frame1920wlight-frame1920wlight {
            width: 100%;
            height: 10676px;
            display: flex;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-frame1 {
            top: -66px;
            left: -26px;
            width: 1946px;
            height: 10675.5px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-group3 {
            top: 0px;
            left: 0px;
            width: 1946px;
            height: 10675.5px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-banner {
            top: 138px;
            left: 26px;
            display: flex;
            position: absolute;
            align-items: center;
            flex-direction: column;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-background10 {
            width: 1920px;
            display: flex;
            padding: 0 254px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            background-color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-container101 {
            display: flex;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: flex-end;
          }
          .frame1920wlight-margin10 {
            display: flex;
            padding: 0 24px 0 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text100 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 18px;
          }
          .frame1920wlight-flag {
            width: 23px;
            height: 18px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
            border-radius: 3px;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-linkmargin10 {
            display: flex;
            padding: 0 0 0 10px;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component210 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text101 {
            color: var(--dl-color-www.bohmenergy.nl-aeroblue);
            height: auto;
            text-align: left;
            line-height: 18px;
          }
          .frame1920wlight-margin11 {
            width: 1920px;
            display: flex;
            padding: 0 190px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-background11 {
            gap: 0.003000000026077032px;
            display: flex;
            padding: 20px 64px;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: space-between;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-linkhome {
            display: flex;
            padding: 2.299999952316284px 0 3.552713678800501e-15px;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-logo1 {
            display: flex;
            overflow: hidden;
            align-items: flex-start;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6591footerlogosvgfill1 {
            width: 167px;
            height: 28px;
          }
          .frame1920wlight-navigationmargin {
            width: 1245px;
            display: flex;
            padding: 0 0 0 426.0469970703125px;
            flex-grow: 1;
            align-items: flex-end;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-navigation {
            display: flex;
            align-items: center;
          }
          .frame1920wlight-component61 {
            display: flex;
            padding: 0 17px;
            align-items: center;
            flex-direction: column;
          }
          .frame1920wlight-text102 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: center;
            line-height: 22px;
          }
          .frame1920wlight-component62 {
            display: flex;
            padding: 0 17px;
            align-items: center;
            flex-direction: column;
          }
          .frame1920wlight-text103 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: center;
            line-height: 22px;
          }
          .frame1920wlight-component63 {
            display: flex;
            padding: 0 17px;
            align-items: center;
            flex-direction: column;
          }
          .frame1920wlight-text104 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: center;
            line-height: 22px;
          }
          .frame1920wlight-component64 {
            display: flex;
            padding: 0 17px;
            align-items: center;
            flex-direction: column;
          }
          .frame1920wlight-text105 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: center;
            line-height: 22px;
          }
          .frame1920wlight-component65 {
            display: flex;
            padding: 0 17px;
            align-items: center;
            flex-direction: column;
          }
          .frame1920wlight-text106 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: center;
            line-height: 22px;
          }
          .frame1920wlight-margin12 {
            display: flex;
            padding: 0 0 0 8px;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container102 {
            display: flex;
            align-items: center;
          }
          .frame1920wlight-component11 {
            display: flex;
            padding: 13px 59px 13px 33px;
            position: relative;
            align-items: center;
            border-color: rgba(81, 81, 81, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 8px;
          }
          .frame1920wlight-container103 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text107 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-background12 {
            top: 22px;
            left: 130.69000244140625px;
            width: 10px;
            height: 10px;
            z-index: 1;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-background13 {
            top: 22px;
            left: 23px;
            width: 10px;
            height: 10px;
            opacity: 0;
            z-index: 2;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-group2 {
            top: 0px;
            left: 0px;
            width: 1946px;
            height: 10675.5px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-container104 {
            top: 9668.5px;
            left: 317px;
            width: 463px;
            display: flex;
            position: absolute;
            flex-grow: 1;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-margin13 {
            display: flex;
            padding: 0 0 24px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container105 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text108 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-heading3margin1 {
            display: flex;
            padding: 0 0 30px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-heading31 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text109 {
            color: rgba(29, 29, 29, 1);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 42px;
          }
          .frame1920wlight-text110 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text112 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text114 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text115 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
          }
          .frame1920wlight-text116 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text118 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-component12 {
            display: flex;
            padding: 13px 59px 13px 33px;
            position: relative;
            align-items: center;
            border-color: rgba(81, 81, 81, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 8px;
          }
          .frame1920wlight-container106 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text121 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-background14 {
            top: 22px;
            left: 23px;
            width: 10px;
            height: 10px;
            opacity: 0;
            z-index: 1;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-background15 {
            top: 22px;
            left: 131px;
            width: 10px;
            height: 10px;
            z-index: 2;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-container107 {
            top: 9654.5px;
            left: 828px;
            width: 632px;
            display: flex;
            position: absolute;
            align-items: center;
            flex-shrink: 0;
            border-radius: 20px;
            justify-content: center;
          }
          .frame1920wlight-frame68b56635f3faf1bcad506866-website20onderaanpng {
            width: 500px;
            height: 500px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            border-radius: 20px;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-group1 {
            top: 0px;
            left: 0px;
            width: 1946px;
            height: 10675.5px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-section1 {
            gap: 112.9800033569336px;
            top: 0px;
            left: 257.4396057128906px;
            width: 1431.120849609375px;
            height: 1200px;
            display: flex;
            padding: 292.9200134277344px 0 222.3300018310547px;
            position: absolute;
            align-items: center;
            flex-shrink: 0;
          }
          .frame1920wlight-container108 {
            width: 621.27001953125px;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-heading1margin {
            display: flex;
            padding: 0 0 20px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-heading1 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text122 {
            color: rgba(29, 29, 29, 1);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 78px;
          }
          .frame1920wlight-text123 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text125 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-margin14 {
            display: flex;
            padding: 0 25.75px 32px 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text128 {
            color: rgba(29, 29, 29, 1);
            height: auto;
            text-align: left;
            line-height: 30px;
          }
          .frame1920wlight-text129 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text130 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
          }
          .frame1920wlight-text131 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text133 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text134 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
          }
          .frame1920wlight-margin15 {
            display: flex;
            padding: 0 0 60px;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container109 {
            gap: 14px;
            display: flex;
            align-items: center;
          }
          .frame1920wlight-component13 {
            display: flex;
            padding: 13px 59px 13px 33px;
            position: relative;
            align-items: center;
            border-color: rgba(0, 173, 98, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 8px;
            background-color: rgba(0, 173, 98, 1);
          }
          .frame1920wlight-container110 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text138 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-background16 {
            top: 22px;
            left: 23px;
            width: 10px;
            height: 10px;
            opacity: 0;
            z-index: 1;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-background17 {
            top: 22px;
            left: 131px;
            width: 10px;
            height: 10px;
            z-index: 2;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-container111 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text139 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-container112 {
            gap: 3px;
            display: flex;
            padding: 0 0 2px;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container113 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text140 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-component211 {
            display: flex;
            padding: 0.5px 0;
            align-items: flex-start;
          }
          .frame1920wlight-text141 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-container114 {
            gap: 20px;
            display: flex;
            align-items: flex-start;
          }
          .frame1920wlight-container115 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
          }
          .frame1920wlight-img1 {
            width: 64px;
            height: 54px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-margin16 {
            height: 54px;
            display: flex;
            padding: 0 0 0 9px;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-paragraph1 {
            gap: 1.5px;
            height: 54px;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text142 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 26px;
          }
          .frame1920wlight-text143 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
            height: auto;
            text-align: left;
            line-height: 26px;
          }
          .frame1920wlight-vertical-divider {
            width: 1px;
            height: auto;
            align-self: stretch;
          }
          .frame1920wlight-container116 {
            gap: 5.6843418860808015e-14px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
          }
          .frame1920wlight-trophy {
            width: 50px;
            height: 54px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-margin17 {
            height: 54px;
            display: flex;
            padding: 0 0 0 9px;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-paragraph2 {
            gap: 1.5px;
            height: 54px;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text144 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 26px;
          }
          .frame1920wlight-text145 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
            height: auto;
            text-align: left;
            line-height: 26px;
          }
          .frame1920wlight-container117 {
            width: 677.75px;
            display: flex;
            padding: 0 0 7px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-component310 {
            width: 677.75px;
            height: 677.75px;
            display: flex;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
          }
          .frame1920wlight-clippathgroup1 {
            top: 0px;
            left: 0px;
            width: 677.75px;
            height: 677.75px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-framelottieelement2 {
            top: 0px;
            left: 0px;
            width: 677.75px;
            height: 677.75px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector100 {
            top: 0px;
            left: 0px;
            width: 678px;
            height: 678px;
            position: absolute;
          }
          .frame1920wlight-group100 {
            top: -75.93310546875px;
            left: 0px;
            width: 677.75px;
            height: 754.8521118164062px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group101 {
            top: 343.9757080078125px;
            left: 8.805095672607422px;
            width: 660.1398315429688px;
            height: 386.41351318359375px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group102 {
            top: 6.69403076171875px;
            left: 0.000003814697265625px;
            width: 660.1398315429688px;
            height: 379.719482421875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector101 {
            top: 0px;
            left: 0px;
            width: 660px;
            height: 380px;
            position: absolute;
          }
          .frame1920wlight-group103 {
            top: 185.45249938964844px;
            left: 639.2826538085938px;
            width: 20.85713005065918px;
            height: 9.355460166931152px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector102 {
            top: -0.0000019073486328125px;
            left: 0.00001239776611328125px;
            width: 21px;
            height: 9px;
            position: absolute;
          }
          .frame1920wlight-group104 {
            top: 188.87953186035156px;
            left: 0px;
            width: 16.98391342163086px;
            height: 9.763364791870117px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector103 {
            top: -0.00000476837158203125px;
            left: 0px;
            width: 17px;
            height: 10px;
            position: absolute;
          }
          .frame1920wlight-group105 {
            top: 0px;
            left: 0.000003814697265625px;
            width: 660.1398315429688px;
            height: 377.83685302734375px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector104 {
            top: 0px;
            left: 0px;
            width: 660px;
            height: 378px;
            position: absolute;
          }
          .frame1920wlight-group106 {
            top: 77.73603820800781px;
            left: 68.01727294921875px;
            width: 533.6220703125px;
            height: 252.93630981445312px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector105 {
            top: 0px;
            left: 0px;
            width: 534px;
            height: 253px;
            position: absolute;
          }
          .frame1920wlight-group107 {
            top: 492.62384033203125px;
            left: 134.33255004882812px;
            width: 440.620361328125px;
            height: 151.23114013671875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group108 {
            top: -0.0000152587890625px;
            left: 0px;
            width: 440.620361328125px;
            height: 151.23114013671875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector106 {
            top: 0.00000762939453125px;
            left: 0px;
            width: 441px;
            height: 151px;
            position: absolute;
          }
          .frame1920wlight-group109 {
            top: 75.93310546875px;
            left: 0px;
            width: 677.75px;
            height: 677.75px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-rectangle1 {
            top: 0px;
            left: 0px;
            width: 678px;
            height: 678px;
            position: absolute;
          }
          .frame1920wlight-group110 {
            top: 175.55734252929688px;
            left: 241.58961486816406px;
            width: 344.55120849609375px;
            height: 137.57383728027344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group111 {
            top: 0px;
            left: 0.0006866455078125px;
            width: 344.550537109375px;
            height: 129.78160095214844px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector107 {
            top: 0px;
            left: 0px;
            width: 345px;
            height: 130px;
            position: absolute;
          }
          .frame1920wlight-group112 {
            top: 125.23753356933594px;
            left: 216.91326904296875px;
            width: 127.63790130615234px;
            height: 12.336305618286133px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector108 {
            top: 0.000003337860107421875px;
            left: -0.00000762939453125px;
            width: 128px;
            height: 12px;
            position: absolute;
          }
          .frame1920wlight-group113 {
            top: 2.7254257202148438px;
            left: 0px;
            width: 217.3594512939453px;
            height: 134.84840393066406px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector109 {
            top: 0px;
            left: 0px;
            width: 217px;
            height: 135px;
            position: absolute;
          }
          .frame1920wlight-group114 {
            top: 419.7079772949219px;
            left: 162.88528442382812px;
            width: 24.71590805053711px;
            height: 84.7996826171875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group115 {
            top: 3.677410125732422px;
            left: 6.158090591430664px;
            width: 18.55780029296875px;
            height: 81.12165832519531px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector110 {
            top: 0.000011444091796875px;
            left: 0.00000286102294921875px;
            width: 19px;
            height: 81px;
            position: absolute;
          }
          .frame1920wlight-group116 {
            top: 12.260360717773438px;
            left: 0.0006308555603027344px;
            width: 3.687462091445923px;
            height: 72.53933715820312px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector111 {
            top: -0.000011444091796875px;
            left: 0.0000011920928955078125px;
            width: 4px;
            height: 73px;
            position: absolute;
          }
          .frame1920wlight-group117 {
            top: 0.000005245208740234375px;
            left: 0.0006246566772460938px;
            width: 24.715282440185547px;
            height: 14.326882362365723px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector112 {
            top: -4.76837158203125e-7px;
            left: 9.5367431640625e-7px;
            width: 25px;
            height: 14px;
            position: absolute;
          }
          .frame1920wlight-group118 {
            top: 14.326896667480469px;
            left: 3.5788846015930176px;
            width: 2.5792155265808105px;
            height: 70.4721908569336px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector113 {
            top: -0.000011444091796875px;
            left: 0.000005245208740234375px;
            width: 3px;
            height: 70px;
            position: absolute;
          }
          .frame1920wlight-group119 {
            top: 17.18809700012207px;
            left: 11.956016540527344px;
            width: 7.843073844909668px;
            height: 10.127602577209473px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector114 {
            top: 0.00000858306884765625px;
            left: -7.152557373046875e-7px;
            width: 8px;
            height: 10px;
            position: absolute;
          }
          .frame1920wlight-group120 {
            top: 14.327502250671387px;
            left: 7.250051498413086px;
            width: 1.8487515449523926px;
            height: 1.7056708335876465px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector115 {
            top: -0.00000947713851928711px;
            left: -0.0000028014183044433594px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group121 {
            top: 45.36146545410156px;
            left: 15.380531311035156px;
            width: 0.9940333366394043px;
            height: 4.386099338531494px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector116 {
            top: -0.0000026226043701171875px;
            left: 0.00000527501106262207px;
            width: 1px;
            height: 4px;
            position: absolute;
          }
          .frame1920wlight-group122 {
            top: 65.89803314208984px;
            left: 15.380531311035156px;
            width: 0.9940333366394043px;
            height: 4.386634826660156px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector117 {
            top: -0.000010013580322265625px;
            left: 0.00000527501106262207px;
            width: 1px;
            height: 4px;
            position: absolute;
          }
          .frame1920wlight-group123 {
            top: 27.544891357421875px;
            left: -0.00000762939453125px;
            width: 24.715282440185547px;
            height: 11.344781875610352px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector118 {
            top: 0.000001430511474609375px;
            left: -0.00000476837158203125px;
            width: 25px;
            height: 11px;
            position: absolute;
          }
          .frame1920wlight-group124 {
            top: 37.11185836791992px;
            left: 0.0006246566772460938px;
            width: 24.715282440185547px;
            height: 11.343526840209961px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector119 {
            top: -0.0000133514404296875px;
            left: 9.5367431640625e-7px;
            width: 25px;
            height: 11px;
            position: absolute;
          }
          .frame1920wlight-group125 {
            top: 57.828365325927734px;
            left: -0.00000762939453125px;
            width: 24.715282440185547px;
            height: 11.343526840209961px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector120 {
            top: -4.76837158203125e-7px;
            left: -0.00000476837158203125px;
            width: 25px;
            height: 11px;
            position: absolute;
          }
          .frame1920wlight-group126 {
            top: 4.526621341705322px;
            left: 14.490415573120117px;
            width: 3.8524227142333984px;
            height: 2.2125799655914307px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector121 {
            top: 0.000002384185791015625px;
            left: 0.0000022649765014648438px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group127 {
            top: 6.5691046714782715px;
            left: 10.434832572937012px;
            width: 3.997856855392456px;
            height: 2.2960450649261475px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector122 {
            top: -0.0000032186508178710938px;
            left: -7.152557373046875e-7px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group128 {
            top: 8.865168571472168px;
            left: 6.065918922424316px;
            width: 4.472604274749756px;
            height: 2.568793773651123px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector123 {
            top: -0.000009894371032714844px;
            left: 0.00000667572021484375px;
            width: 4px;
            height: 3px;
            position: absolute;
          }
          .frame1920wlight-group129 {
            top: 535.5235595703125px;
            left: 219.9875946044922px;
            width: 107.01421356201172px;
            height: 47.742469787597656px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group130 {
            top: 0px;
            left: 0px;
            width: 107.01421356201172px;
            height: 47.742469787597656px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector124 {
            top: -0.000003814697265625px;
            left: 0.00000762939453125px;
            width: 107px;
            height: 48px;
            position: absolute;
          }
          .frame1920wlight-group131 {
            top: 363.703857421875px;
            left: 226.4161834716797px;
            width: 73.65762329101562px;
            height: 42.437191009521484px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group132 {
            top: -0.0000152587890625px;
            left: 0px;
            width: 73.65762329101562px;
            height: 42.437191009521484px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector125 {
            top: 0.0000152587890625px;
            left: 0px;
            width: 74px;
            height: 42px;
            position: absolute;
          }
          .frame1920wlight-group133 {
            top: 284.2251281738281px;
            left: 177.443115234375px;
            width: 278.4059143066406px;
            height: 188.95921325683594px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group134 {
            top: 0px;
            left: 0px;
            width: 278.4059143066406px;
            height: 188.95921325683594px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector126 {
            top: -0.00000762939453125px;
            left: 0px;
            width: 278px;
            height: 189px;
            position: absolute;
          }
          .frame1920wlight-group135 {
            top: 189.9375457763672px;
            left: 171.74562072753906px;
            width: 93.21070861816406px;
            height: 237.4509735107422px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group136 {
            top: 0px;
            left: 0px;
            width: 93.21070861816406px;
            height: 237.4509735107422px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector127 {
            top: 0px;
            left: -0.000003814697265625px;
            width: 93px;
            height: 237px;
            position: absolute;
          }
          .frame1920wlight-group137 {
            top: 390.9450378417969px;
            left: 136.89483642578125px;
            width: 112.20528411865234px;
            height: 174.0775909423828px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group138 {
            top: 0px;
            left: 0px;
            width: 112.20528411865234px;
            height: 174.0775909423828px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector128 {
            top: -0.00000762939453125px;
            left: -0.00000762939453125px;
            width: 112px;
            height: 174px;
            position: absolute;
          }
          .frame1920wlight-group139 {
            top: 425.83154296875px;
            left: 256.76495361328125px;
            width: 11.61713695526123px;
            height: 6.6344194412231445px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group140 {
            top: 0.0000152587890625px;
            left: 0px;
            width: 11.61713695526123px;
            height: 6.6344194412231445px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector129 {
            top: -0.0000026226043701171875px;
            left: 0.00001239776611328125px;
            width: 12px;
            height: 7px;
            position: absolute;
          }
          .frame1920wlight-group141 {
            top: 428.474853515625px;
            left: 256.76495361328125px;
            width: 6.864101409912109px;
            height: 9.917741775512695px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group142 {
            top: -0.0000152587890625px;
            left: 0px;
            width: 6.864101409912109px;
            height: 9.917741775512695px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector130 {
            top: -0.000004291534423828125px;
            left: -0.0000064373016357421875px;
            width: 7px;
            height: 10px;
            position: absolute;
          }
          .frame1920wlight-group143 {
            top: 429.72235107421875px;
            left: 263.61834716796875px;
            width: 4.7630767822265625px;
            height: 8.67017936706543px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group144 {
            top: 0px;
            left: 0.0000152587890625px;
            width: 4.7630767822265625px;
            height: 8.67017936706543px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector131 {
            top: 0.00001430511474609375px;
            left: -0.0000035762786865234375px;
            width: 5px;
            height: 9px;
            position: absolute;
          }
          .frame1920wlight-group145 {
            top: 186.48541259765625px;
            left: 257.266357421875px;
            width: 5.808568477630615px;
            height: 13.896385192871094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group146 {
            top: 9.5367431640625e-7px;
            left: -0.0000152587890625px;
            width: 5.808568477630615px;
            height: 13.896385192871094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector132 {
            top: 9.5367431640625e-7px;
            left: 0.000006198883056640625px;
            width: 6px;
            height: 14px;
            position: absolute;
          }
          .frame1920wlight-group147 {
            top: 226.33462524414062px;
            left: 325.6519775390625px;
            width: 98.39801025390625px;
            height: 62.964229583740234px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group148 {
            top: -0.00000762939453125px;
            left: 0px;
            width: 98.39801025390625px;
            height: 62.964229583740234px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector133 {
            top: -0.000003814697265625px;
            left: 0.000003814697265625px;
            width: 98px;
            height: 63px;
            position: absolute;
          }
          .frame1920wlight-group149 {
            top: 546.1259765625px;
            left: 219.9875946044922px;
            width: 88.63150024414062px;
            height: 37.140071868896484px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group150 {
            top: 0px;
            left: 0px;
            width: 88.63150024414062px;
            height: 37.140071868896484px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector134 {
            top: -0.0000133514404296875px;
            left: 0.00000762939453125px;
            width: 89px;
            height: 37px;
            position: absolute;
          }
          .frame1920wlight-group151 {
            top: 284.2251281738281px;
            left: 177.443115234375px;
            width: 278.4059143066406px;
            height: 188.95921325683594px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group152 {
            top: 0px;
            left: 0px;
            width: 278.4059143066406px;
            height: 188.95921325683594px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector135 {
            top: -0.00000762939453125px;
            left: 0px;
            width: 278px;
            height: 189px;
            position: absolute;
          }
          .frame1920wlight-group153 {
            top: 425.83154296875px;
            left: 256.76495361328125px;
            width: 11.61713695526123px;
            height: 6.6344194412231445px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group154 {
            top: 0.0000152587890625px;
            left: 0px;
            width: 11.61713695526123px;
            height: 6.6344194412231445px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector136 {
            top: -0.0000026226043701171875px;
            left: 0.00001239776611328125px;
            width: 12px;
            height: 7px;
            position: absolute;
          }
          .frame1920wlight-group155 {
            top: 428.474853515625px;
            left: 256.76495361328125px;
            width: 6.864101409912109px;
            height: 9.917741775512695px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group156 {
            top: -0.0000152587890625px;
            left: 0px;
            width: 6.864101409912109px;
            height: 9.917741775512695px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector137 {
            top: -0.000004291534423828125px;
            left: -0.0000064373016357421875px;
            width: 7px;
            height: 10px;
            position: absolute;
          }
          .frame1920wlight-group157 {
            top: 322.0599060058594px;
            left: 219.98699951171875px;
            width: 121.69879913330078px;
            height: 193.4549560546875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group158 {
            top: 0px;
            left: 0px;
            width: 121.69879913330078px;
            height: 193.4549560546875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector138 {
            top: 0px;
            left: -0.000003814697265625px;
            width: 122px;
            height: 193px;
            position: absolute;
          }
          .frame1920wlight-group159 {
            top: 189.9375457763672px;
            left: 171.74562072753906px;
            width: 93.21070861816406px;
            height: 237.4509735107422px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group160 {
            top: 0px;
            left: 0px;
            width: 93.21070861816406px;
            height: 237.4509735107422px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector139 {
            top: 0px;
            left: -0.000003814697265625px;
            width: 93px;
            height: 237px;
            position: absolute;
          }
          .frame1920wlight-group161 {
            top: 390.9450378417969px;
            left: 136.89483642578125px;
            width: 112.20528411865234px;
            height: 174.0775909423828px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group162 {
            top: 0px;
            left: 0px;
            width: 112.20528411865234px;
            height: 174.0775909423828px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector140 {
            top: -0.00000762939453125px;
            left: -0.00000762939453125px;
            width: 112px;
            height: 174px;
            position: absolute;
          }
          .frame1920wlight-group163 {
            top: 415.4933776855469px;
            left: 219.98699951171875px;
            width: 64.4577865600586px;
            height: 100.0214614868164px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group164 {
            top: 0px;
            left: 0px;
            width: 64.4577865600586px;
            height: 100.0214614868164px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector141 {
            top: -0.000004291534423828125px;
            left: -0.000003814697265625px;
            width: 64px;
            height: 100px;
            position: absolute;
          }
          .frame1920wlight-group165 {
            top: 186.48541259765625px;
            left: 257.266357421875px;
            width: 5.808568477630615px;
            height: 13.896385192871094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group166 {
            top: 9.5367431640625e-7px;
            left: -0.0000152587890625px;
            width: 5.808568477630615px;
            height: 13.896385192871094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector142 {
            top: 9.5367431640625e-7px;
            left: 0.000006198883056640625px;
            width: 6px;
            height: 14px;
            position: absolute;
          }
          .frame1920wlight-group167 {
            top: 226.33462524414062px;
            left: 325.6519775390625px;
            width: 98.39801025390625px;
            height: 62.964229583740234px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group168 {
            top: -0.00000762939453125px;
            left: 0px;
            width: 98.39801025390625px;
            height: 62.964229583740234px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector143 {
            top: -0.000003814697265625px;
            left: 0.000003814697265625px;
            width: 98px;
            height: 63px;
            position: absolute;
          }
          .frame1920wlight-group169 {
            top: 413.18902587890625px;
            left: 277.93463134765625px;
            width: 7.844328880310059px;
            height: 7.844328880310059px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group170 {
            top: 0.00001430511474609375px;
            left: -0.0000152587890625px;
            width: 7.844328880310059px;
            height: 7.844328880310059px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector144 {
            top: -7.152557373046875e-7px;
            left: -9.5367431640625e-7px;
            width: 8px;
            height: 8px;
            position: absolute;
          }
          .frame1920wlight-group171 {
            top: 544.77734375px;
            left: 299.6577453613281px;
            width: 7.844328880310059px;
            height: 7.844328880310059px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group172 {
            top: 0.00000667572021484375px;
            left: 0px;
            width: 7.844328880310059px;
            height: 7.844328880310059px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector145 {
            top: -0.000007867813110351562px;
            left: -0.0000040531158447265625px;
            width: 8px;
            height: 8px;
            position: absolute;
          }
          .frame1920wlight-group173 {
            top: 754.8521118164062px;
            left: 401.625px;
            width: 25px;
            height: 25px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group174 {
            top: 0px;
            left: 0px;
            width: 25px;
            height: 25px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group175 {
            top: 75.93310546875px;
            left: 0px;
            width: 677.75px;
            height: 677.75px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-rectangle2 {
            top: 0px;
            left: 0px;
            width: 678px;
            height: 678px;
            position: absolute;
          }
          .frame1920wlight-group176 {
            top: 184.75967407226562px;
            left: 284.0142517089844px;
            width: 170.33990478515625px;
            height: 52.9184684753418px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group177 {
            top: -0.0000019073486328125px;
            left: 0.00000762939453125px;
            width: 170.33990478515625px;
            height: 52.9184684753418px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector146 {
            top: 0.0000019073486328125px;
            left: 0.00000762939453125px;
            width: 170px;
            height: 53px;
            position: absolute;
          }
          .frame1920wlight-group178 {
            top: 241.29342651367188px;
            left: 382.4122619628906px;
            width: 170.34117126464844px;
            height: 52.9184684753418px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group179 {
            top: 0.00000762939453125px;
            left: 0px;
            width: 170.34117126464844px;
            height: 52.9184684753418px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector147 {
            top: 0.0000057220458984375px;
            left: -0.00000762939453125px;
            width: 170px;
            height: 53px;
            position: absolute;
          }
          .frame1920wlight-group180 {
            top: 183.19580078125px;
            left: 327.3958740234375px;
            width: 78.0529556274414px;
            height: 24.426612854003906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group181 {
            top: 0.00000286102294921875px;
            left: -0.00000762939453125px;
            width: 78.0529556274414px;
            height: 24.426612854003906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector148 {
            top: 0.00000286102294921875px;
            left: 0.0000152587890625px;
            width: 78px;
            height: 24px;
            position: absolute;
          }
          .frame1920wlight-group182 {
            top: 181.98654174804688px;
            left: 323.21331787109375px;
            width: 86.70556640625px;
            height: 26.90416717529297px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group183 {
            top: 0.0000019073486328125px;
            left: -0.00000762939453125px;
            width: 86.70556640625px;
            height: 26.90416717529297px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector149 {
            top: -0.000003814697265625px;
            left: -0.000011444091796875px;
            width: 87px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group184 {
            top: 183.59619140625px;
            left: 336.6559753417969px;
            width: 58.324153900146484px;
            height: 23.570640563964844px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group185 {
            top: -9.5367431640625e-7px;
            left: -0.00000762939453125px;
            width: 58.324153900146484px;
            height: 23.570640563964844px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector150 {
            top: -0.00000286102294921875px;
            left: 0.0000133514404296875px;
            width: 58px;
            height: 24px;
            position: absolute;
          }
          .frame1920wlight-group186 {
            top: 184.7276611328125px;
            left: 288.153564453125px;
            width: 77.23212432861328px;
            height: 24.34628677368164px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group187 {
            top: -0.00000286102294921875px;
            left: -0.00000762939453125px;
            width: 77.23212432861328px;
            height: 24.34628677368164px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector151 {
            top: -9.5367431640625e-7px;
            left: 0.0000152587890625px;
            width: 77px;
            height: 24px;
            position: absolute;
          }
          .frame1920wlight-group188 {
            top: 183.52340698242188px;
            left: 284.01300048828125px;
            width: 85.79562377929688px;
            height: 26.815053939819336px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group189 {
            top: 9.5367431640625e-7px;
            left: 0px;
            width: 85.79562377929688px;
            height: 26.815053939819336px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector152 {
            top: 0.00000286102294921875px;
            left: 0.0000152587890625px;
            width: 86px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group190 {
            top: 185.12615966796875px;
            left: 297.2900085449219px;
            width: 57.702880859375px;
            height: 23.495332717895508px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group191 {
            top: -0.0000019073486328125px;
            left: 0px;
            width: 57.702880859375px;
            height: 23.495332717895508px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector153 {
            top: -0.000003814697265625px;
            left: -0.0000057220458984375px;
            width: 58px;
            height: 23px;
            position: absolute;
          }
          .frame1920wlight-group192 {
            top: 207.2854461669922px;
            left: 370.3370361328125px;
            width: 79.46744537353516px;
            height: 24.847068786621094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group193 {
            top: -0.000003814697265625px;
            left: 0.00000762939453125px;
            width: 79.46744537353516px;
            height: 24.847068786621094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector154 {
            top: 0px;
            left: 0.000003814697265625px;
            width: 79px;
            height: 25px;
            position: absolute;
          }
          .frame1920wlight-group194 {
            top: 206.05670166015625px;
            left: 366.0810241699219px;
            width: 88.27317810058594px;
            height: 27.364784240722656px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group195 {
            top: 0.000003814697265625px;
            left: 0.00000762939453125px;
            width: 88.27317810058594px;
            height: 27.364784240722656px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector155 {
            top: 0.00000476837158203125px;
            left: 0.00000762939453125px;
            width: 88px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group196 {
            top: 207.6669921875px;
            left: 379.7935791015625px;
            width: 59.385963439941406px;
            height: 24.033769607543945px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group197 {
            top: 0.000003814697265625px;
            left: -0.0000152587890625px;
            width: 59.385963439941406px;
            height: 24.033769607543945px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector156 {
            top: -0.0000057220458984375px;
            left: 0.0000057220458984375px;
            width: 59px;
            height: 24px;
            position: absolute;
          }
          .frame1920wlight-group198 {
            top: 208.48593139648438px;
            left: 329.8640441894531px;
            width: 80.35354614257812px;
            height: 25.134483337402344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group199 {
            top: 0.000003814697265625px;
            left: 0.00000762939453125px;
            width: 80.35354614257812px;
            height: 25.134483337402344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector157 {
            top: 0.00000762939453125px;
            left: 0.000011444091796875px;
            width: 80px;
            height: 25px;
            position: absolute;
          }
          .frame1920wlight-group200 {
            top: 207.59982299804688px;
            left: 325.6519470214844px;
            width: 88.29325866699219px;
            height: 27.305795669555664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group201 {
            top: 0.00000762939453125px;
            left: 0px;
            width: 88.29325866699219px;
            height: 27.305795669555664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector158 {
            top: 0.000003814697265625px;
            left: -0.000003814697265625px;
            width: 88px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group202 {
            top: 209.23585510253906px;
            left: 339.1925354003906px;
            width: 58.749629974365234px;
            height: 23.95595359802246px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group203 {
            top: -0.000003814697265625px;
            left: 0px;
            width: 58.749629974365234px;
            height: 23.95595359802246px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector159 {
            top: -0.00000286102294921875px;
            left: -0.0000095367431640625px;
            width: 59px;
            height: 24px;
            position: absolute;
          }
          .frame1920wlight-group204 {
            top: 239.72958374023438px;
            left: 425.795166015625px;
            width: 78.0529556274414px;
            height: 24.426612854003906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group205 {
            top: 0px;
            left: 0.0000152587890625px;
            width: 78.0529556274414px;
            height: 24.426612854003906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector160 {
            top: -0.00000476837158203125px;
            left: 0.0000152587890625px;
            width: 78px;
            height: 24px;
            position: absolute;
          }
          .frame1920wlight-group206 {
            top: 238.52029418945312px;
            left: 421.61260986328125px;
            width: 86.70556640625px;
            height: 26.90416717529297px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group207 {
            top: 0px;
            left: 0px;
            width: 86.70556640625px;
            height: 26.90416717529297px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector161 {
            top: 0.0000019073486328125px;
            left: -0.000011444091796875px;
            width: 87px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group208 {
            top: 240.12994384765625px;
            left: 435.055908203125px;
            width: 58.32352828979492px;
            height: 23.570640563964844px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group209 {
            top: 0.00000762939453125px;
            left: 0px;
            width: 58.32352828979492px;
            height: 23.570640563964844px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector162 {
            top: -0.00000476837158203125px;
            left: -0.0000133514404296875px;
            width: 58px;
            height: 24px;
            position: absolute;
          }
          .frame1920wlight-group210 {
            top: 241.26141357421875px;
            left: 386.553466796875px;
            width: 77.23087310791016px;
            height: 24.34628677368164px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group211 {
            top: 0px;
            left: 0.0000152587890625px;
            width: 77.23087310791016px;
            height: 24.34628677368164px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector163 {
            top: -0.00000667572021484375px;
            left: 0px;
            width: 77px;
            height: 24px;
            position: absolute;
          }
          .frame1920wlight-group212 {
            top: 240.05718994140625px;
            left: 382.4122619628906px;
            width: 85.79562377929688px;
            height: 26.815053939819336px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group213 {
            top: -0.00000762939453125px;
            left: 0px;
            width: 85.79562377929688px;
            height: 26.815053939819336px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector164 {
            top: 0.00000476837158203125px;
            left: -0.000011444091796875px;
            width: 86px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group214 {
            top: 241.65992736816406px;
            left: 395.6893005371094px;
            width: 57.702880859375px;
            height: 23.495332717895508px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group215 {
            top: 0px;
            left: 0px;
            width: 57.702880859375px;
            height: 23.495332717895508px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector165 {
            top: -0.000003814697265625px;
            left: 0.0000133514404296875px;
            width: 58px;
            height: 23px;
            position: absolute;
          }
          .frame1920wlight-group216 {
            top: 263.8192138671875px;
            left: 468.7362976074219px;
            width: 79.46744537353516px;
            height: 24.847068786621094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group217 {
            top: 0.00000762939453125px;
            left: 0px;
            width: 79.46744537353516px;
            height: 24.847068786621094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector166 {
            top: 9.5367431640625e-7px;
            left: -0.000003814697265625px;
            width: 79px;
            height: 25px;
            position: absolute;
          }
          .frame1920wlight-group218 {
            top: 262.5904541015625px;
            left: 464.4802551269531px;
            width: 88.27317810058594px;
            height: 27.364784240722656px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group219 {
            top: -0.00000762939453125px;
            left: 0px;
            width: 88.27317810058594px;
            height: 27.364784240722656px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector167 {
            top: 9.5367431640625e-7px;
            left: -0.00000762939453125px;
            width: 88px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group220 {
            top: 264.20074462890625px;
            left: 478.19281005859375px;
            width: 59.385963439941406px;
            height: 24.033769607543945px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group221 {
            top: 0px;
            left: 0px;
            width: 59.385963439941406px;
            height: 24.033769607543945px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector168 {
            top: 0.000003814697265625px;
            left: -0.0000019073486328125px;
            width: 59px;
            height: 24px;
            position: absolute;
          }
          .frame1920wlight-group222 {
            top: 265.01971435546875px;
            left: 428.2633056640625px;
            width: 80.35354614257812px;
            height: 25.134483337402344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group223 {
            top: 0.00000762939453125px;
            left: 0.0000152587890625px;
            width: 80.35354614257812px;
            height: 25.134483337402344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector169 {
            top: -0.00000762939453125px;
            left: 0.000011444091796875px;
            width: 80px;
            height: 25px;
            position: absolute;
          }
          .frame1920wlight-group224 {
            top: 264.13360595703125px;
            left: 424.05059814453125px;
            width: 88.29325866699219px;
            height: 27.305795669555664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group225 {
            top: 0.00000762939453125px;
            left: 0.0000152587890625px;
            width: 88.29325866699219px;
            height: 27.305795669555664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector170 {
            top: -0.0000057220458984375px;
            left: -0.0000152587890625px;
            width: 88px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group226 {
            top: 265.7696228027344px;
            left: 437.5917663574219px;
            width: 58.749629974365234px;
            height: 23.95595359802246px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group227 {
            top: -0.00000762939453125px;
            left: 0px;
            width: 58.749629974365234px;
            height: 23.95595359802246px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector171 {
            top: 0.00000667572021484375px;
            left: 0.0000133514404296875px;
            width: 59px;
            height: 24px;
            position: absolute;
          }
          .frame1920wlight-group228 {
            top: 419.4300231933594px;
            left: 97.36946105957031px;
            width: 544.188232421875px;
            height: 263.5121765136719px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group229 {
            top: 135.4920196533203px;
            left: -0.0000019073486328125px;
            width: 47.09029006958008px;
            height: 27.18122673034668px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector172 {
            top: 0.0000095367431640625px;
            left: -0.000003814697265625px;
            width: 47px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group230 {
            top: 151.082275390625px;
            left: 27.025297164916992px;
            width: 0.7760922312736511px;
            height: 0.9797695279121399px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector173 {
            top: -0.000010192394256591797px;
            left: 1.7881393432617188e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group231 {
            top: 151.04644775390625px;
            left: 30.56143569946289px;
            width: 0.8606554865837097px;
            height: 1.1930564641952515px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector174 {
            top: 0.000004708766937255859px;
            left: 0.000003159046173095703px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group232 {
            top: 141.81661987304688px;
            left: 26.870071411132812px;
            width: 4.827291965484619px;
            height: 12.053667068481445px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector175 {
            top: -0.00000858306884765625px;
            left: -0.0000021457672119140625px;
            width: 5px;
            height: 12px;
            position: absolute;
          }
          .frame1920wlight-group233 {
            top: 152.23391723632812px;
            left: 27.02277183532715px;
            width: 0.5958622097969055px;
            height: 0.9664213061332703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector176 {
            top: -0.000014185905456542969px;
            left: -0.0000024437904357910156px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group234 {
            top: 152.9033966064453px;
            left: 29.582529067993164px;
            width: 0.5785976648330688px;
            height: 0.860466480255127px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector177 {
            top: 0.000009149312973022461px;
            left: 0.0000022649765014648438px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group235 {
            top: 152.49722290039062px;
            left: 30.582483291625977px;
            width: 0.684994101524353px;
            height: 0.6020728945732117px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector178 {
            top: 0.00000908970832824707px;
            left: 8.046627044677734e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group236 {
            top: 142.69415283203125px;
            left: 15.94301986694336px;
            width: 0.7731786966323853px;
            height: 0.9788203239440918px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector179 {
            top: 0.000004500150680541992px;
            left: -0.000003039836883544922px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group237 {
            top: 142.66024780273438px;
            left: 12.31523609161377px;
            width: 0.8656620979309082px;
            height: 1.1925158500671387px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector180 {
            top: 0.000011920928955078125px;
            left: -1.7881393432617188e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group238 {
            top: 133.42384338378906px;
            left: 12.046374320983887px;
            width: 4.82674503326416px;
            height: 12.05798625946045px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector181 {
            top: 0.000002384185791015625px;
            left: 0.000003814697265625px;
            width: 5px;
            height: 12px;
            position: absolute;
          }
          .frame1920wlight-group239 {
            top: 143.84669494628906px;
            left: 16.127649307250977px;
            width: 0.5857800245285034px;
            height: 0.9601458311080933px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector182 {
            top: 0.000004231929779052734px;
            left: 3.129243850708008e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group240 {
            top: 144.51438903808594px;
            left: 13.580718994140625px;
            width: 0.5836180448532104px;
            height: 0.8629639744758606px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector183 {
            top: -0.00001043081283569336px;
            left: 0.0000019073486328125px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group241 {
            top: 144.109130859375px;
            left: 12.484843254089355px;
            width: 0.6757010817527771px;
            height: 0.6023390889167786px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector184 {
            top: -0.000006765127182006836px;
            left: 0.000001341104507446289px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group242 {
            top: 124.42127990722656px;
            left: 1.073324203491211px;
            width: 47.63916015625px;
            height: 27.951725006103516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector185 {
            top: 0.000011444091796875px;
            left: 0px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group243 {
            top: 121.89842224121094px;
            left: 1.0718421936035156px;
            width: 47.6416015625px;
            height: 27.98041534423828px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector186 {
            top: 0.0000133514404296875px;
            left: 0.0000019073486328125px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group244 {
            top: 119.87895202636719px;
            left: 1.07293701171875px;
            width: 47.6380615234375px;
            height: 27.987714767456055px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector187 {
            top: -0.0000095367431640625px;
            left: -0.000003814697265625px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group245 {
            top: 117.56008911132812px;
            left: 1.0715999603271484px;
            width: 47.640892028808594px;
            height: 27.952661514282227px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector188 {
            top: 0.000003814697265625px;
            left: 0px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group246 {
            top: 114.86862182617188px;
            left: 1.075429916381836px;
            width: 47.63634490966797px;
            height: 27.959026336669922px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector189 {
            top: 0px;
            left: 0px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group247 {
            top: 112.44474792480469px;
            left: 1.07293701171875px;
            width: 47.64017868041992px;
            height: 27.985122680664062px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector190 {
            top: 0.00000762939453125px;
            left: -0.000003814697265625px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group248 {
            top: 110.11709594726562px;
            left: 1.0800037384033203px;
            width: 47.63241195678711px;
            height: 27.98348045349121px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector191 {
            top: 0px;
            left: -0.0000019073486328125px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group249 {
            top: 109.85787963867188px;
            left: 3.073240280151367px;
            width: 42.84745407104492px;
            height: 25.199176788330078px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector192 {
            top: -0.00001430511474609375px;
            left: 0.000003814697265625px;
            width: 43px;
            height: 25px;
            position: absolute;
          }
          .frame1920wlight-group250 {
            top: 109.40375518798828px;
            left: 4.971401214599609px;
            width: 39.052520751953125px;
            height: 22.888925552368164px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector193 {
            top: 0.00000476837158203125px;
            left: 0.0000019073486328125px;
            width: 39px;
            height: 23px;
            position: absolute;
          }
          .frame1920wlight-group251 {
            top: 166.73255920410156px;
            left: 53.99847412109375px;
            width: 47.09029006958008px;
            height: 27.18122673034668px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector194 {
            top: 0.00000762939453125px;
            left: -0.0000019073486328125px;
            width: 47px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group252 {
            top: 182.3233642578125px;
            left: 81.02438354492188px;
            width: 0.7752576470375061px;
            height: 0.9797695279121399px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector195 {
            top: 0.000020951032638549805px;
            left: -0.0000054836273193359375px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group253 {
            top: 182.2882080078125px;
            left: 84.55994415283203px;
            width: 0.8606554865837097px;
            height: 1.1924437284469604px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector196 {
            top: 5.9604644775390625e-8px;
            left: 8.344650268554688e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group254 {
            top: 173.0584259033203px;
            left: 80.86854553222656px;
            width: 4.827291965484619px;
            height: 12.053988456726074px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector197 {
            top: -0.000028133392333984375px;
            left: -7.152557373046875e-7px;
            width: 5px;
            height: 12px;
            position: absolute;
          }
          .frame1920wlight-group255 {
            top: 183.47445678710938px;
            left: 81.02186584472656px;
            width: 0.5946530699729919px;
            height: 0.9676764607429504px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector198 {
            top: -0.000016033649444580078px;
            left: 0.0000033974647521972656px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group256 {
            top: 184.1445770263672px;
            left: 83.58100891113281px;
            width: 0.5785976648330688px;
            height: 0.8610811829566956px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector199 {
            top: -0.000020742416381835938px;
            left: -0.0000039637088775634766px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group257 {
            top: 183.739013671875px;
            left: 84.5808334350586px;
            width: 0.6851226687431335px;
            height: 0.6020728945732117px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector200 {
            top: -0.000026106834411621094px;
            left: 0.000005513429641723633px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group258 {
            top: 173.93533325195312px;
            left: 69.94178009033203px;
            width: 0.7729158401489258px;
            height: 0.9788203239440918px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector201 {
            top: -0.000025391578674316406px;
            left: 0.000005304813385009766px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group259 {
            top: 173.9013671875px;
            left: 66.31372833251953px;
            width: 0.8656193614006042px;
            height: 1.1925158500671387px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector202 {
            top: -0.00002574920654296875px;
            left: -0.000006377696990966797px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group260 {
            top: 164.6649932861328px;
            left: 66.04485321044922px;
            width: 4.82674503326416px;
            height: 12.058613777160645px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector203 {
            top: 0.00000286102294921875px;
            left: 0.0000050067901611328125px;
            width: 5px;
            height: 12px;
            position: absolute;
          }
          .frame1920wlight-group261 {
            top: 175.0879364013672px;
            left: 70.1266860961914px;
            width: 0.5852010846138px;
            height: 0.9601458311080933px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector204 {
            top: -0.000017851591110229492px;
            left: 0.00000406801700592041px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group262 {
            top: 175.7561492919922px;
            left: 67.5792007446289px;
            width: 0.5836180448532104px;
            height: 0.8629768490791321px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector205 {
            top: -0.0000073015689849853516px;
            left: -0.0000023543834686279297px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group263 {
            top: 175.35032653808594px;
            left: 66.48332977294922px;
            width: 0.6751984357833862px;
            height: 0.6023390889167786px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector206 {
            top: 0.0000016689300537109375px;
            left: -0.000004887580871582031px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group264 {
            top: 155.66311645507812px;
            left: 55.071800231933594px;
            width: 47.63916015625px;
            height: 27.951725006103516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector207 {
            top: -0.00000858306884765625px;
            left: 0.00000762939453125px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group265 {
            top: 153.13958740234375px;
            left: 55.07032775878906px;
            width: 47.6416015625px;
            height: 27.980180740356445px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector208 {
            top: 0.00001430511474609375px;
            left: 0.00000762939453125px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group266 {
            top: 151.1200714111328px;
            left: 55.0714111328125px;
            width: 47.6380615234375px;
            height: 27.987714767456055px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector209 {
            top: 0.0000133514404296875px;
            left: -0.0000019073486328125px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group267 {
            top: 148.80123901367188px;
            left: 55.07007598876953px;
            width: 47.640892028808594px;
            height: 27.952661514282227px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector210 {
            top: 0.000003814697265625px;
            left: -0.0000057220458984375px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group268 {
            top: 146.11001586914062px;
            left: 55.07392120361328px;
            width: 47.63634490966797px;
            height: 27.958467483520508px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector211 {
            top: -0.0000133514404296875px;
            left: -0.0000057220458984375px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group269 {
            top: 143.68589782714844px;
            left: 55.0714111328125px;
            width: 47.64017868041992px;
            height: 27.985122680664062px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector212 {
            top: 0.00000762939453125px;
            left: -0.0000019073486328125px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group270 {
            top: 141.3582305908203px;
            left: 55.07848358154297px;
            width: 47.63241195678711px;
            height: 27.98410987854004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector213 {
            top: -0.00000667572021484375px;
            left: 0px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group271 {
            top: 141.09902954101562px;
            left: 57.07171630859375px;
            width: 42.84745407104492px;
            height: 25.199176788330078px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector214 {
            top: -0.0000133514404296875px;
            left: -0.000003814697265625px;
            width: 43px;
            height: 25px;
            position: absolute;
          }
          .frame1920wlight-group272 {
            top: 140.6448974609375px;
            left: 58.97052764892578px;
            width: 39.052520751953125px;
            height: 22.888925552368164px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector215 {
            top: 0.0000057220458984375px;
            left: -0.0000057220458984375px;
            width: 39px;
            height: 23px;
            position: absolute;
          }
          .frame1920wlight-group273 {
            top: 199.0637664794922px;
            left: 111.01231384277344px;
            width: 47.09029006958008px;
            height: 27.18122673034668px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector216 {
            top: -0.0000095367431640625px;
            left: -0.0000019073486328125px;
            width: 47px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group274 {
            top: 214.6539764404297px;
            left: 138.0382080078125px;
            width: 0.7752576470375061px;
            height: 0.9797695279121399px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector217 {
            top: 0.0000015795230865478516px;
            left: 0.0000010132789611816406px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group275 {
            top: 214.6181182861328px;
            left: 141.57313537597656px;
            width: 0.8606554865837097px;
            height: 1.1930564641952515px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector218 {
            top: 0.000016450881958007812px;
            left: 9.5367431640625e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group276 {
            top: 205.38836669921875px;
            left: 137.8824005126953px;
            width: 4.827291965484619px;
            height: 12.053988456726074px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector219 {
            top: 0.000010967254638671875px;
            left: -0.0000057220458984375px;
            width: 5px;
            height: 12px;
            position: absolute;
          }
          .frame1920wlight-group277 {
            top: 215.80557250976562px;
            left: 138.03570556640625px;
            width: 0.5946530699729919px;
            height: 0.9664213061332703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector220 {
            top: -0.000010192394256591797px;
            left: -0.000005364418029785156px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group278 {
            top: 216.47511291503906px;
            left: 140.59483337402344px;
            width: 0.5785976648330688px;
            height: 0.8610811829566956px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector221 {
            top: -0.000001817941665649414px;
            left: 0.0000025331974029541016px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group279 {
            top: 216.0689239501953px;
            left: 141.59405517578125px;
            width: 0.6851226687431335px;
            height: 0.6020728945732117px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector222 {
            top: -0.000009655952453613281px;
            left: -0.000005751848220825195px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group280 {
            top: 206.2658233642578px;
            left: 126.95498657226562px;
            width: 0.7729158401489258px;
            height: 0.9788203239440918px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector223 {
            top: 0.00001627206802368164px;
            left: 0.000005424022674560547px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group281 {
            top: 206.23194885253906px;
            left: 123.32754516601562px;
            width: 0.8656193614006042px;
            height: 1.1925158500671387px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector224 {
            top: -0.000006854534149169922px;
            left: 1.1920928955078125e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group282 {
            top: 196.99551391601562px;
            left: 123.05868530273438px;
            width: 4.82674503326416px;
            height: 12.058695793151855px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector225 {
            top: 0.00001430511474609375px;
            left: -0.0000035762786865234375px;
            width: 5px;
            height: 12px;
            position: absolute;
          }
          .frame1920wlight-group283 {
            top: 207.41845703125px;
            left: 127.14054870605469px;
            width: 0.5852010846138px;
            height: 0.9601458311080933px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector226 {
            top: -0.000014483928680419922px;
            left: -8.046627044677734e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group284 {
            top: 208.08670043945312px;
            left: 124.59303283691406px;
            width: 0.5836180448532104px;
            height: 0.8629768490791321px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector227 {
            top: -0.000026673078536987305px;
            left: 0.0000041425228118896484px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group285 {
            top: 207.6808319091797px;
            left: 123.49653625488281px;
            width: 0.6751984357833862px;
            height: 0.6023390889167786px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector228 {
            top: 0.0000050067901611328125px;
            left: -8.642673492431641e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group286 {
            top: 187.99295043945312px;
            left: 112.08564758300781px;
            width: 47.63916015625px;
            height: 27.951725006103516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector229 {
            top: 0.00002288818359375px;
            left: -0.0000057220458984375px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group287 {
            top: 185.47015380859375px;
            left: 112.08354187011719px;
            width: 47.6416015625px;
            height: 27.980180740356445px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector230 {
            top: 0.0000247955322265625px;
            left: -0.00000762939453125px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group288 {
            top: 183.45062255859375px;
            left: 112.08462524414062px;
            width: 47.6380615234375px;
            height: 27.987714767456055px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector231 {
            top: 0.0000019073486328125px;
            left: 0.0000019073486328125px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group289 {
            top: 181.1317901611328px;
            left: 112.08424377441406px;
            width: 47.64057540893555px;
            height: 27.952661514282227px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector232 {
            top: -0.0000152587890625px;
            left: 0px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group290 {
            top: 178.4405059814453px;
            left: 112.0877685546875px;
            width: 47.63634490966797px;
            height: 27.958467483520508px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector233 {
            top: 0.0000286102294921875px;
            left: -0.0000019073486328125px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group291 {
            top: 176.01641845703125px;
            left: 112.08462524414062px;
            width: 47.64017868041992px;
            height: 27.985122680664062px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector234 {
            top: 0.000019073486328125px;
            left: 0.0000019073486328125px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group292 {
            top: 173.6887969970703px;
            left: 112.09169006347656px;
            width: 47.63241195678711px;
            height: 27.98410987854004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector235 {
            top: -0.00001811981201171875px;
            left: 0.000003814697265625px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group293 {
            top: 173.42893981933594px;
            left: 114.08555603027344px;
            width: 42.84745407104492px;
            height: 25.199804306030273px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector236 {
            top: 0.00002574920654296875px;
            left: 0.0000057220458984375px;
            width: 43px;
            height: 25px;
            position: absolute;
          }
          .frame1920wlight-group294 {
            top: 172.97544860839844px;
            left: 115.98434448242188px;
            width: 39.05189514160156px;
            height: 22.88829803466797px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector237 {
            top: 0.00001621246337890625px;
            left: 0.0000019073486328125px;
            width: 39px;
            height: 23px;
            position: absolute;
          }
          .frame1920wlight-group295 {
            top: 214.72592163085938px;
            left: 277.7083435058594px;
            width: 39.281890869140625px;
            height: 22.67983627319336px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector238 {
            top: 0.000011444091796875px;
            left: 0.0000133514404296875px;
            width: 39px;
            height: 23px;
            position: absolute;
          }
          .frame1920wlight-group296 {
            top: 221.89804077148438px;
            left: 291.833984375px;
            width: 1.9766814708709717px;
            height: 2.4995276927948px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector239 {
            top: -0.000024199485778808594px;
            left: -0.000012755393981933594px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group297 {
            top: 221.8077392578125px;
            left: 300.6104431152344px;
            width: 2.2037928104400635px;
            height: 3.046123504638672px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector240 {
            top: 0.0000064373016357421875px;
            left: -0.000007927417755126953px;
            width: 2px;
            height: 3px;
            position: absolute;
          }
          .frame1920wlight-group298 {
            top: 184.65670776367188px;
            left: 291.1856689453125px;
            width: 12.32773208618164px;
            height: 44.34917068481445px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector241 {
            top: 0.0000133514404296875px;
            left: -0.000003337860107421875px;
            width: 12px;
            height: 44px;
            position: absolute;
          }
          .frame1920wlight-group299 {
            top: 224.83847045898438px;
            left: 291.5862731933594px;
            width: 1.5056405067443848px;
            height: 2.4574713706970215px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector242 {
            top: 0.000020384788513183594px;
            left: -0.0000030994415283203125px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group300 {
            top: 226.54136657714844px;
            left: 298.1070556640625px;
            width: 1.4847745895385742px;
            height: 2.1998422145843506px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector243 {
            top: 0.000025391578674316406px;
            left: 0.000012099742889404297px;
            width: 1px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group301 {
            top: 225.51235961914062px;
            left: 300.66253662109375px;
            width: 1.735140085220337px;
            height: 1.531307339668274px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector244 {
            top: 0.000023484230041503906px;
            left: -0.000010192394256591797px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group302 {
            top: 178.58006286621094px;
            left: 280.2681579589844px;
            width: 32.078094482421875px;
            height: 18.220867156982422px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector245 {
            top: -9.5367431640625e-7px;
            left: -0.0000057220458984375px;
            width: 32px;
            height: 18px;
            position: absolute;
          }
          .frame1920wlight-group303 {
            top: 170.5626678466797px;
            left: 277.3901062011719px;
            width: 38.19443130493164px;
            height: 21.626972198486328px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector246 {
            top: 0.0000152587890625px;
            left: 0.000003814697265625px;
            width: 38px;
            height: 22px;
            position: absolute;
          }
          .frame1920wlight-group304 {
            top: 160.8325653076172px;
            left: 274.83001708984375px;
            width: 43.55509948730469px;
            height: 24.742183685302734px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector247 {
            top: 0.0000095367431640625px;
            left: -0.00000762939453125px;
            width: 44px;
            height: 25px;
            position: absolute;
          }
          .frame1920wlight-group305 {
            top: 153.092529296875px;
            left: 274.4097595214844px;
            width: 45.06072998046875px;
            height: 25.517131805419922px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector248 {
            top: -0.0000019073486328125px;
            left: -0.000003814697265625px;
            width: 45px;
            height: 26px;
            position: absolute;
          }
          .frame1920wlight-group306 {
            top: 145.4835662841797px;
            left: 275.2234191894531px;
            width: 43.81956481933594px;
            height: 24.889720916748047px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector249 {
            top: -0.00001430511474609375px;
            left: 0.0000019073486328125px;
            width: 44px;
            height: 25px;
            position: absolute;
          }
          .frame1920wlight-group307 {
            top: 139.6212921142578px;
            left: 276.4420471191406px;
            width: 40.17810821533203px;
            height: 22.750593185424805px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector250 {
            top: 0.00000286102294921875px;
            left: 0.000003814697265625px;
            width: 40px;
            height: 23px;
            position: absolute;
          }
          .frame1920wlight-group308 {
            top: 133.4180145263672px;
            left: 277.97894287109375px;
            width: 37.72303771972656px;
            height: 21.426132202148438px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector251 {
            top: 0.0000095367431640625px;
            left: -0.0000095367431640625px;
            width: 38px;
            height: 21px;
            position: absolute;
          }
          .frame1920wlight-group309 {
            top: 128.12734985351562px;
            left: 279.43505859375px;
            width: 34.79775619506836px;
            height: 19.70793342590332px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector252 {
            top: -0.000011444091796875px;
            left: 0.0000095367431640625px;
            width: 35px;
            height: 20px;
            position: absolute;
          }
          .frame1920wlight-group310 {
            top: 122.76966857910156px;
            left: 282.6062927246094px;
            width: 29.486793518066406px;
            height: 16.764081954956055px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector253 {
            top: -0.00001430511474609375px;
            left: -0.0000095367431640625px;
            width: 29px;
            height: 17px;
            position: absolute;
          }
          .frame1920wlight-group311 {
            top: 117.46381378173828px;
            left: 284.74615478515625px;
            width: 24.233470916748047px;
            height: 13.77893352508545px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector254 {
            top: -0.0000057220458984375px;
            left: 0.0000057220458984375px;
            width: 24px;
            height: 14px;
            position: absolute;
          }
          .frame1920wlight-group312 {
            top: 113.0326919555664px;
            left: 287.1756896972656px;
            width: 19.17656135559082px;
            height: 10.8582763671875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector255 {
            top: -0.00001049041748046875px;
            left: -0.00000858306884765625px;
            width: 19px;
            height: 11px;
            position: absolute;
          }
          .frame1920wlight-group313 {
            top: 109.75403594970703px;
            left: 289.2911071777344px;
            width: 15.45215892791748px;
            height: 8.784006118774414px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector256 {
            top: -4.76837158203125e-7px;
            left: 0.000007152557373046875px;
            width: 15px;
            height: 9px;
            position: absolute;
          }
          .frame1920wlight-group314 {
            top: 106.7096939086914px;
            left: 290.31390380859375px;
            width: 13.135956764221191px;
            height: 7.433599948883057px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector257 {
            top: -0.000008821487426757812px;
            left: -9.5367431640625e-7px;
            width: 13px;
            height: 7px;
            position: absolute;
          }
          .frame1920wlight-group315 {
            top: 104.27979278564453px;
            left: 291.8722839355469px;
            width: 10.282543182373047px;
            height: 5.850266456604004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector258 {
            top: -0.000011205673217773438px;
            left: -0.000002384185791015625px;
            width: 10px;
            height: 6px;
            position: absolute;
          }
          .frame1920wlight-group316 {
            top: 245.5498046875px;
            left: 257.48876953125px;
            width: 31.110137939453125px;
            height: 17.96233558654785px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector259 {
            top: -0.00001811981201171875px;
            left: -0.00000476837158203125px;
            width: 31px;
            height: 18px;
            position: absolute;
          }
          .frame1920wlight-group317 {
            top: 251.2310791015625px;
            left: 268.6750793457031px;
            width: 1.5655933618545532px;
            height: 1.9791436195373535px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector260 {
            top: 0.00000858306884765625px;
            left: 0.0000050067901611328125px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group318 {
            top: 251.15936279296875px;
            left: 275.6261291503906px;
            width: 1.7456493377685547px;
            height: 2.412302255630493px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector261 {
            top: -0.000015497207641601562px;
            left: 0.000003635883331298828px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group319 {
            top: 221.73585510253906px;
            left: 268.1624450683594px;
            width: 9.763350486755371px;
            height: 35.12379837036133px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector262 {
            top: 0.000011444091796875px;
            left: 0.000008106231689453125px;
            width: 10px;
            height: 35px;
            position: absolute;
          }
          .frame1920wlight-group320 {
            top: 253.55938720703125px;
            left: 268.4794006347656px;
            width: 1.192304253578186px;
            height: 1.9460209608078003px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector263 {
            top: 0.0000032186508178710938px;
            left: -0.000003159046173095703px;
            width: 1px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group321 {
            top: 254.90780639648438px;
            left: 273.6434326171875px;
            width: 1.1760218143463135px;
            height: 1.7429211139678955px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector264 {
            top: -0.000026524066925048828px;
            left: 0.00000762939453125px;
            width: 1px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group322 {
            top: 254.09286499023438px;
            left: 275.6680603027344px;
            width: 1.3735661506652832px;
            height: 1.2123820781707764px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector265 {
            top: -0.00000667572021484375px;
            left: 0.000013589859008789062px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group323 {
            top: 216.92306518554688px;
            left: 259.5160217285156px;
            width: 25.404443740844727px;
            height: 14.430683135986328px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector266 {
            top: 0.00000762939453125px;
            left: 0.00000476837158203125px;
            width: 25px;
            height: 14px;
            position: absolute;
          }
          .frame1920wlight-group324 {
            top: 210.573486328125px;
            left: 257.23687744140625px;
            width: 30.248830795288086px;
            height: 17.128719329833984px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector267 {
            top: 0px;
            left: 0.000003814697265625px;
            width: 30px;
            height: 17px;
            position: absolute;
          }
          .frame1920wlight-group325 {
            top: 202.8676300048828px;
            left: 255.2086181640625px;
            width: 34.49485397338867px;
            height: 19.595287322998047px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector268 {
            top: 0.00002193450927734375px;
            left: -0.0000019073486328125px;
            width: 34px;
            height: 20px;
            position: absolute;
          }
          .frame1920wlight-group326 {
            top: 196.73873901367188px;
            left: 254.87579345703125px;
            width: 35.686912536621094px;
            height: 20.208559036254883px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector269 {
            top: -0.0000286102294921875px;
            left: 0.0000133514404296875px;
            width: 36px;
            height: 20px;
            position: absolute;
          }
          .frame1920wlight-group327 {
            top: 190.7118682861328px;
            left: 255.52011108398438px;
            width: 34.70423126220703px;
            height: 19.712087631225586px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector270 {
            top: -0.0000152587890625px;
            left: -0.000011444091796875px;
            width: 35px;
            height: 20px;
            position: absolute;
          }
          .frame1920wlight-group328 {
            top: 186.06826782226562px;
            left: 256.4849853515625px;
            width: 31.82028579711914px;
            height: 18.01795196533203px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector271 {
            top: -0.00002765655517578125px;
            left: -0.000011444091796875px;
            width: 32px;
            height: 18px;
            position: absolute;
          }
          .frame1920wlight-group329 {
            top: 181.1555633544922px;
            left: 257.7025451660156px;
            width: 29.876220703125px;
            height: 16.969547271728516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector272 {
            top: -0.00001049041748046875px;
            left: -0.00001430511474609375px;
            width: 30px;
            height: 17px;
            position: absolute;
          }
          .frame1920wlight-group330 {
            top: 176.96595764160156px;
            left: 258.8560485839844px;
            width: 27.55924415588379px;
            height: 15.608017921447754px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector273 {
            top: -0.000027179718017578125px;
            left: -0.00001049041748046875px;
            width: 28px;
            height: 16px;
            position: absolute;
          }
          .frame1920wlight-group331 {
            top: 172.7226104736328px;
            left: 261.3668518066406px;
            width: 23.35357666015625px;
            height: 13.276723861694336px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector274 {
            top: 0.0000286102294921875px;
            left: -0.00000858306884765625px;
            width: 23px;
            height: 13px;
            position: absolute;
          }
          .frame1920wlight-group332 {
            top: 168.5206298828125px;
            left: 263.062744140625px;
            width: 19.191890716552734px;
            height: 10.912506103515625px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector275 {
            top: -0.00000762939453125px;
            left: 0.00000667572021484375px;
            width: 19px;
            height: 11px;
            position: absolute;
          }
          .frame1920wlight-group333 {
            top: 165.01165771484375px;
            left: 264.9859619140625px;
            width: 15.188345909118652px;
            height: 8.598953247070312px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector276 {
            top: 0.000006198883056640625px;
            left: -0.000002384185791015625px;
            width: 15px;
            height: 9px;
            position: absolute;
          }
          .frame1920wlight-group334 {
            top: 162.41482543945312px;
            left: 266.6619873046875px;
            width: 12.237252235412598px;
            height: 6.9570488929748535px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector277 {
            top: 0.000005245208740234375px;
            left: 0.000008106231689453125px;
            width: 12px;
            height: 7px;
            position: absolute;
          }
          .frame1920wlight-group335 {
            top: 160.0035400390625px;
            left: 267.4713439941406px;
            width: 10.403618812561035px;
            height: 5.887168884277344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector278 {
            top: 0.0000021457672119140625px;
            left: 0.000011444091796875px;
            width: 10px;
            height: 6px;
            position: absolute;
          }
          .frame1920wlight-group336 {
            top: 158.07920837402344px;
            left: 268.70660400390625px;
            width: 8.143096923828125px;
            height: 4.632906913757324px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector279 {
            top: -9.5367431640625e-7px;
            left: 0.000003337860107421875px;
            width: 8px;
            height: 5px;
            position: absolute;
          }
          .frame1920wlight-group337 {
            top: 98.97457122802734px;
            left: 506.7640075683594px;
            width: 35.20150375366211px;
            height: 20.32442283630371px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector280 {
            top: 0.00000858306884765625px;
            left: 0.0000247955322265625px;
            width: 35px;
            height: 20px;
            position: absolute;
          }
          .frame1920wlight-group338 {
            top: 105.40132904052734px;
            left: 519.422119140625px;
            width: 1.7711213827133179px;
            height: 2.240016222000122px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector281 {
            top: 0.000007867813110351562px;
            left: 0.0000021457672119140625px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group339 {
            top: 105.32102966308594px;
            left: 527.287109375px;
            width: 1.9754189252853394px;
            height: 2.729825735092163px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector282 {
            top: 0.000010013580322265625px;
            left: 0.000024020671844482422px;
            width: 2px;
            height: 3px;
            position: absolute;
          }
          .frame1920wlight-group340 {
            top: 72.02843475341797px;
            left: 518.841552734375px;
            width: 11.047860145568848px;
            height: 39.74296951293945px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector283 {
            top: -0.0000057220458984375px;
            left: 0.000019073486328125px;
            width: 11px;
            height: 40px;
            position: absolute;
          }
          .frame1920wlight-group341 {
            top: 108.03704071044922px;
            left: 519.1998291015625px;
            width: 1.3493967056274414px;
            height: 2.201432466506958px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector284 {
            top: -0.0000016689300537109375px;
            left: 0.000023365020751953125px;
            width: 1px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group342 {
            top: 109.56233978271484px;
            left: 525.04345703125px;
            width: 1.3303980827331543px;
            height: 1.9720022678375244px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector285 {
            top: 0.0000152587890625px;
            left: 0.000014722347259521484px;
            width: 1px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group343 {
            top: 108.63980102539062px;
            left: 527.3343505859375px;
            width: 1.55483877658844px;
            height: 1.3721528053283691px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector286 {
            top: 0.000010311603546142578px;
            left: 0.000009655952453613281px;
            width: 2px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group344 {
            top: 66.58273315429688px;
            left: 509.0575866699219px;
            width: 28.74624252319336px;
            height: 16.329097747802734px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector287 {
            top: -0.0000152587890625px;
            left: -0.00000667572021484375px;
            width: 29px;
            height: 16px;
            position: absolute;
          }
          .frame1920wlight-group345 {
            top: 59.39863586425781px;
            left: 506.4794006347656px;
            width: 34.22739791870117px;
            height: 19.380355834960938px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector288 {
            top: -0.0000133514404296875px;
            left: -0.000030517578125px;
            width: 34px;
            height: 19px;
            position: absolute;
          }
          .frame1920wlight-group346 {
            top: 50.67910385131836px;
            left: 504.1842956542969px;
            width: 39.03094482421875px;
            height: 22.172080993652344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector289 {
            top: -9.5367431640625e-7px;
            left: -0.0000057220458984375px;
            width: 39px;
            height: 22px;
            position: absolute;
          }
          .frame1920wlight-group347 {
            top: 43.742774963378906px;
            left: 503.8081970214844px;
            width: 40.38002014160156px;
            height: 22.866846084594727px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector290 {
            top: 0.00000762939453125px;
            left: 0.0000019073486328125px;
            width: 40px;
            height: 23px;
            position: absolute;
          }
          .frame1920wlight-group348 {
            top: 36.92391586303711px;
            left: 504.5370788574219px;
            width: 39.268314361572266px;
            height: 22.304981231689453px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector291 {
            top: -0.000003814697265625px;
            left: -0.00002288818359375px;
            width: 39px;
            height: 22px;
            position: absolute;
          }
          .frame1920wlight-group349 {
            top: 31.669723510742188px;
            left: 505.6293640136719px;
            width: 36.004920959472656px;
            height: 20.387723922729492px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector292 {
            top: 9.5367431640625e-7px;
            left: -0.0000019073486328125px;
            width: 36px;
            height: 20px;
            position: absolute;
          }
          .frame1920wlight-group350 {
            top: 26.111709594726562px;
            left: 507.0065002441406px;
            width: 33.80503463745117px;
            height: 19.201183319091797px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector293 {
            top: 9.5367431640625e-7px;
            left: 0.0000247955322265625px;
            width: 34px;
            height: 19px;
            position: absolute;
          }
          .frame1920wlight-group351 {
            top: 21.371854782104492px;
            left: 508.3111267089844px;
            width: 31.183795928955078px;
            height: 17.660722732543945px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector294 {
            top: -0.00001239776611328125px;
            left: 0.00001621246337890625px;
            width: 31px;
            height: 18px;
            position: absolute;
          }
          .frame1920wlight-group352 {
            top: 16.569499969482422px;
            left: 511.1530456542969px;
            width: 26.424453735351562px;
            height: 15.022846221923828px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector295 {
            top: 0.000002384185791015625px;
            left: -0.000019073486328125px;
            width: 26px;
            height: 15px;
            position: absolute;
          }
          .frame1920wlight-group353 {
            top: 11.81525993347168px;
            left: 513.0716552734375px;
            width: 21.71589469909668px;
            height: 12.347240447998047px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector296 {
            top: -0.000001430511474609375px;
            left: -0.00001621246337890625px;
            width: 22px;
            height: 12px;
            position: absolute;
          }
          .frame1920wlight-group354 {
            top: 7.844280242919922px;
            left: 515.24755859375px;
            width: 17.185199737548828px;
            height: 9.729791641235352px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector297 {
            top: 0.000014781951904296875px;
            left: -0.00001430511474609375px;
            width: 17px;
            height: 10px;
            position: absolute;
          }
          .frame1920wlight-group355 {
            top: 4.9054765701293945px;
            left: 517.1435546875px;
            width: 13.846797943115234px;
            height: 7.871883869171143px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector298 {
            top: 0.00000762939453125px;
            left: -0.000026702880859375px;
            width: 14px;
            height: 8px;
            position: absolute;
          }
          .frame1920wlight-group356 {
            top: 2.176910877227783px;
            left: 518.0595703125px;
            width: 11.772140502929688px;
            height: 6.661560535430908px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector299 {
            top: -0.0000011920928955078125px;
            left: 0.00002002716064453125px;
            width: 12px;
            height: 7px;
            position: absolute;
          }
          .frame1920wlight-group357 {
            top: -0.0000064373016357421875px;
            left: 519.4560546875px;
            width: 9.215014457702637px;
            height: 5.2425079345703125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector300 {
            top: -0.0000069141387939453125px;
            left: 0.00001811981201171875px;
            width: 9px;
            height: 5px;
            position: absolute;
          }
          .frame1920wlight-group358 {
            top: 129.13665771484375px;
            left: 34.0958366394043px;
            width: 251.81175231933594px;
            height: 425.78619384765625px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group359 {
            top: 32.0078239440918px;
            left: 221.8438720703125px;
            width: 0.34954333305358887px;
            height: 25.774581909179688px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector301 {
            top: 0px;
            left: -0.000005632638931274414px;
            width: 0px;
            height: 26px;
            position: absolute;
          }
          .frame1920wlight-group360 {
            top: 31.828330993652344px;
            left: 224.39425659179688px;
            width: 0.2955743074417114px;
            height: 27.416242599487305px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector302 {
            top: 0.000003814697265625px;
            left: 0.000004798173904418945px;
            width: 0px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group361 {
            top: 31.292415618896484px;
            left: 222.19345092773438px;
            width: 0.9777171611785889px;
            height: 27.062307357788086px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector303 {
            top: -0.000003814697265625px;
            left: 0.000012755393981933594px;
            width: 1px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group362 {
            top: 31.292423248291016px;
            left: 223.17050170898438px;
            width: 1.2237153053283691px;
            height: 27.77896499633789px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector304 {
            top: -0.0000019073486328125px;
            left: 0.000006198883056640625px;
            width: 1px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group363 {
            top: 35.39091491699219px;
            left: 227.82379150390625px;
            width: 0.22842685878276825px;
            height: 25.823532104492188px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector305 {
            top: 0.0000019073486328125px;
            left: 0.000008180737495422363px;
            width: 0px;
            height: 26px;
            position: absolute;
          }
          .frame1920wlight-group364 {
            top: 34.86315155029297px;
            left: 228.05221557617188px;
            width: 1.893934726715088px;
            height: 27.46017074584961px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector306 {
            top: -0.000003814697265625px;
            left: 4.172325134277344e-7px;
            width: 2px;
            height: 27px;
            position: absolute;
          }
          .frame1920wlight-group365 {
            top: 38.037906646728516px;
            left: 247.63168334960938px;
            width: 1.0191352367401123px;
            height: 12.697648048400879px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector307 {
            top: -0.0000019073486328125px;
            left: -0.000014841556549072266px;
            width: 1px;
            height: 13px;
            position: absolute;
          }
          .frame1920wlight-group366 {
            top: 13.151298522949219px;
            left: 204.534912109375px;
            width: 1.0191352367401123px;
            height: 12.697648048400879px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector308 {
            top: -0.0000019073486328125px;
            left: 0.0000020265579223632812px;
            width: 1px;
            height: 13px;
            position: absolute;
          }
          .frame1920wlight-group367 {
            top: 11.461947441101074px;
            left: 204.42697143554688px;
            width: 1.2350112199783325px;
            height: 0.6354875564575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector309 {
            top: -0.0000036656856536865234px;
            left: 0.000006616115570068359px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group368 {
            top: 10.764877319335938px;
            left: 204.43075561523438px;
            width: 1.2274805307388306px;
            height: 0.7163358926773071px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector310 {
            top: -0.0000015497207641601562px;
            left: -0.000004827976226806641px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group369 {
            top: 11.120562553405762px;
            left: 204.42697143554688px;
            width: 1.2350112199783325px;
            height: 0.6643834710121155px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector311 {
            top: 0.0000016093254089355469px;
            left: 0.000006616115570068359px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group370 {
            top: 25.60683822631836px;
            left: 226.114990234375px;
            width: 1.0191352367401123px;
            height: 12.697648048400879px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector312 {
            top: 9.5367431640625e-7px;
            left: -0.000013232231140136719px;
            width: 1px;
            height: 13px;
            position: absolute;
          }
          .frame1920wlight-group371 {
            top: 23.917490005493164px;
            left: 226.00704956054688px;
            width: 1.2350112199783325px;
            height: 0.6354875564575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector313 {
            top: -0.000003516674041748047px;
            left: -0.000008702278137207031px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group372 {
            top: 23.220470428466797px;
            left: 226.01080322265625px;
            width: 1.2274805307388306px;
            height: 0.7162858247756958px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector314 {
            top: 7.152557373046875e-7px;
            left: 0.00001043081283569336px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group373 {
            top: 23.57672882080078px;
            left: 226.00704956054688px;
            width: 1.2350112199783325px;
            height: 0.6643834710121155px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector315 {
            top: -0.0000014007091522216797px;
            left: -0.000008702278137207031px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group374 {
            top: 30.913375854492188px;
            left: 221.84326171875px;
            width: 2.8465499877929688px;
            height: 1.2274805307388306px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector316 {
            top: 0.000001430511474609375px;
            left: 0.000007152557373046875px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group375 {
            top: 34.117618560791016px;
            left: 228.06478881835938px;
            width: 1.2237153053283691px;
            height: 1.1785320043563843px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector317 {
            top: -0.000001430511474609375px;
            left: -0.000009655952453613281px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group376 {
            top: 33.94693374633789px;
            left: 227.82379150390625px;
            width: 2.122361660003662px;
            height: 1.6441712379455566px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector318 {
            top: -0.0000035762786865234375px;
            left: 0.000008225440979003906px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group377 {
            top: 17.944496154785156px;
            left: 199.09783935546875px;
            width: 52.713890075683594px;
            height: 30.43348503112793px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector319 {
            top: -9.5367431640625e-7px;
            left: 0.0000019073486328125px;
            width: 53px;
            height: 30px;
            position: absolute;
          }
          .frame1920wlight-group378 {
            top: 19.17574691772461px;
            left: 199.09783935546875px;
            width: 50.582740783691406px;
            height: 29.542369842529297px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector320 {
            top: -0.00000286102294921875px;
            left: 0.0000019073486328125px;
            width: 51px;
            height: 30px;
            position: absolute;
          }
          .frame1920wlight-group379 {
            top: 47.661319732666016px;
            left: 249.9761962890625px;
            width: 1.5399986505508423px;
            height: 1.7772111892700195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector321 {
            top: 0.0000023245811462402344px;
            left: -3.5762786865234375e-7px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group380 {
            top: 47.14987564086914px;
            left: 249.68124389648438px;
            width: 2.1305196285247803px;
            height: 2.2892889976501465px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector322 {
            top: 0.0000022649765014648438px;
            left: 0.0000045299530029296875px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group381 {
            top: 397.99468994140625px;
            left: 0px;
            width: 48.049964904785156px;
            height: 27.791515350341797px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector323 {
            top: 0.0000019073486328125px;
            left: 0px;
            width: 48px;
            height: 28px;
            position: absolute;
          }
          .frame1920wlight-group382 {
            top: 27.273609161376953px;
            left: 57.44999694824219px;
            width: 1.0191352367401123px;
            height: 12.697648048400879px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector324 {
            top: 0.000001430511474609375px;
            left: -0.0000010132789611816406px;
            width: 1px;
            height: 13px;
            position: absolute;
          }
          .frame1920wlight-group383 {
            top: 2.386368751525879px;
            left: 14.353240966796875px;
            width: 1.0191352367401123px;
            height: 12.697648048400879px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector325 {
            top: -4.76837158203125e-7px;
            left: 0.0000016093254089355469px;
            width: 1px;
            height: 13px;
            position: absolute;
          }
          .frame1920wlight-group384 {
            top: 0.6970103979110718px;
            left: 14.244674682617188px;
            width: 1.2362662553787231px;
            height: 0.6354875564575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector326 {
            top: 0.0000018775463104248047px;
            left: -2.384185791015625e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group385 {
            top: -0.0000017285346984863281px;
            left: 14.248443603515625px;
            width: 1.2287356853485107px;
            height: 0.7162817120552063px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector327 {
            top: -5.662441253662109e-7px;
            left: -0.0000011324882507324219px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group386 {
            top: 0.3562573790550232px;
            left: 14.244674682617188px;
            width: 1.2362662553787231px;
            height: 0.6640510559082031px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector328 {
            top: 0.0000011324882507324219px;
            left: -2.384185791015625e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group387 {
            top: 14.842535018920898px;
            left: 35.93267822265625px;
            width: 1.0191352367401123px;
            height: 12.697648048400879px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector329 {
            top: -0.000003337860107421875px;
            left: -0.000003814697265625px;
            width: 1px;
            height: 13px;
            position: absolute;
          }
          .frame1920wlight-group388 {
            top: 13.152549743652344px;
            left: 35.824729919433594px;
            width: 1.2350112199783325px;
            height: 0.6354875564575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector330 {
            top: 0.0000010728836059570312px;
            left: 0.0000035762786865234375px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group389 {
            top: 12.455533027648926px;
            left: 35.82849884033203px;
            width: 1.2274805307388306px;
            height: 0.7163358926773071px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector331 {
            top: 0.0000024437904357910156px;
            left: 0.0000026226043701171875px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group390 {
            top: 12.811800003051758px;
            left: 35.82469177246094px;
            width: 1.2350503206253052px;
            height: 0.6640510559082031px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector332 {
            top: 3.2782554626464844e-7px;
            left: 0.0000033974647521972656px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group391 {
            top: 20.52747917175293px;
            left: 28.594999313354492px;
            width: 4.394484519958496px;
            height: 20.2082462310791px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector333 {
            top: 0.00000286102294921875px;
            left: 0.000001430511474609375px;
            width: 4px;
            height: 20px;
            position: absolute;
          }
          .frame1920wlight-group392 {
            top: 21.242874145507812px;
            left: 31.660968780517578px;
            width: 0.3501708507537842px;
            height: 14.969490051269531px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector334 {
            top: 0.00000286102294921875px;
            left: 0.0000021904706954956055px;
            width: 0px;
            height: 15px;
            position: absolute;
          }
          .frame1920wlight-group393 {
            top: 20.526845932006836px;
            left: 32.988853454589844px;
            width: 4.652628421783447px;
            height: 19.501628875732422px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector335 {
            top: -9.5367431640625e-7px;
            left: 0px;
            width: 5px;
            height: 20px;
            position: absolute;
          }
          .frame1920wlight-group394 {
            top: 20.1484432220459px;
            left: 31.66159439086914px;
            width: 2.8465499877929688px;
            height: 1.2274805307388306px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector336 {
            top: -0.0000016093254089355469px;
            left: 0.000003814697265625px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group395 {
            top: 21.064035415649414px;
            left: 34.21194076538086px;
            width: 0.2962018549442291px;
            height: 15.007142066955566px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector337 {
            top: 0px;
            left: 0.0000026971101760864258px;
            width: 0px;
            height: 15px;
            position: absolute;
          }
          .frame1920wlight-group396 {
            top: 33.60680389404297px;
            left: 34.21257400512695px;
            width: 3.428913116455078px;
            height: 4.440517902374268px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector338 {
            top: -0.0000026226043701171875px;
            left: -0.000003337860107421875px;
            width: 3px;
            height: 4px;
            position: absolute;
          }
          .frame1920wlight-group397 {
            top: 23.35268783569336px;
            left: 37.88309097290039px;
            width: 1.2237153053283691px;
            height: 1.1785320043563843px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector339 {
            top: 2.980232238769531e-7px;
            left: -0.000002562999725341797px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group398 {
            top: 23.182003021240234px;
            left: 37.64210510253906px;
            width: 2.122361660003662px;
            height: 1.6441712379455566px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector340 {
            top: 0.0000029206275939941406px;
            left: 0px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group399 {
            top: 36.108192443847656px;
            left: 39.76384353637695px;
            width: 2.388441324234009px;
            height: 2.7549281120300293px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector341 {
            top: 0.0000035762786865234375px;
            left: 0.0000022649765014648438px;
            width: 2px;
            height: 3px;
            position: absolute;
          }
          .frame1920wlight-group400 {
            top: 37.485660552978516px;
            left: 39.76384353637695px;
            width: 2.388441324234009px;
            height: 1.721987009048462px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector342 {
            top: 3.5762786865234375e-7px;
            left: 0.0000022649765014648438px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group401 {
            top: 38.35416793823242px;
            left: 28.597286224365234px;
            width: 4.356426239013672px;
            height: 371.04949951171875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector343 {
            top: 0px;
            left: 0.0000011920928955078125px;
            width: 4px;
            height: 371px;
            position: absolute;
          }
          .frame1920wlight-group402 {
            top: 34.23810958862305px;
            left: 28.601051330566406px;
            width: 10.512656211853027px;
            height: 6.072514533996582px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector344 {
            top: -0.0000026226043701171875px;
            left: -4.76837158203125e-7px;
            width: 11px;
            height: 6px;
            position: absolute;
          }
          .frame1920wlight-group403 {
            top: 37.77183151245117px;
            left: 32.95371627807617px;
            width: 6.159994602203369px;
            height: 371.46221923828125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector345 {
            top: 0px;
            left: -0.000001430511474609375px;
            width: 6px;
            height: 371px;
            position: absolute;
          }
          .frame1920wlight-group404 {
            top: 39.483131408691406px;
            left: 28.174325942993164px;
            width: 5.005309104919434px;
            height: 5.020193576812744px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector346 {
            top: 0.00000286102294921875px;
            left: -2.384185791015625e-7px;
            width: 5px;
            height: 5px;
            position: absolute;
          }
          .frame1920wlight-group405 {
            top: 24.097591400146484px;
            left: 33.18088912963867px;
            width: 6.582960605621338px;
            height: 20.196949005126953px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector347 {
            top: -0.00000286102294921875px;
            left: -0.00000286102294921875px;
            width: 7px;
            height: 20px;
            position: absolute;
          }
          .frame1920wlight-group406 {
            top: 38.731964111328125px;
            left: 28.1743221282959px;
            width: 0.42296624183654785px;
            height: 1.4822643995285034px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector348 {
            top: 0.00000286102294921875px;
            left: -2.2351741790771484e-7px;
            width: 0px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group407 {
            top: 39.46180725097656px;
            left: 28.597286224365234px;
            width: 9.272624015808105px;
            height: 2.2152199745178223px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector349 {
            top: 0.0000021457672119140625px;
            left: 0.000001430511474609375px;
            width: 9px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group408 {
            top: 24.625980377197266px;
            left: 37.642120361328125px;
            width: 0.22842685878276825px;
            height: 15.036008834838867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector350 {
            top: -0.000001430511474609375px;
            left: -0.000002808868885040283px;
            width: 0px;
            height: 15px;
            position: absolute;
          }
          .frame1920wlight-group409 {
            top: 7.1795654296875px;
            left: 8.916183471679688px;
            width: 52.713890075683594px;
            height: 30.43222999572754px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector351 {
            top: 9.5367431640625e-7px;
            left: 0px;
            width: 53px;
            height: 30px;
            position: absolute;
          }
          .frame1920wlight-group410 {
            top: 8.41143798828125px;
            left: 8.915542602539062px;
            width: 50.58399963378906px;
            height: 29.542369842529297px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector352 {
            top: 0px;
            left: 0.0000019073486328125px;
            width: 51px;
            height: 30px;
            position: absolute;
          }
          .frame1920wlight-group411 {
            top: 36.89765930175781px;
            left: 59.794498443603516px;
            width: 1.5399986505508423px;
            height: 1.7759560346603394px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector353 {
            top: -0.0000032186508178710938px;
            left: 0.0000019669532775878906px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group412 {
            top: 36.38494110107422px;
            left: 59.49955368041992px;
            width: 2.129892110824585px;
            height: 2.2892889976501465px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector354 {
            top: -8.344650268554688e-7px;
            left: -8.344650268554688e-7px;
            width: 2px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group413 {
            top: 143.19602966308594px;
            left: 70.67176818847656px;
            width: 189.636962890625px;
            height: 21.531030654907227px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group414 {
            top: 0.000003814697265625px;
            left: -0.000003814697265625px;
            width: 189.636962890625px;
            height: 21.531030654907227px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector355 {
            top: -0.000003814697265625px;
            left: 0px;
            width: 190px;
            height: 22px;
            position: absolute;
          }
          .frame1920wlight-group415 {
            top: 131.18228149414062px;
            left: 48.958641052246094px;
            width: 189.636962890625px;
            height: 21.531030654907227px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group416 {
            top: -0.0000019073486328125px;
            left: 0px;
            width: 189.636962890625px;
            height: 21.531030654907227px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector356 {
            top: -0.0000019073486328125px;
            left: 0px;
            width: 190px;
            height: 22px;
            position: absolute;
          }
          .frame1920wlight-group417 {
            top: 156.76295471191406px;
            left: 281.3779296875px;
            width: 189.9507293701172px;
            height: 21.501371383666992px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group418 {
            top: 0px;
            left: 0px;
            width: 189.9507293701172px;
            height: 21.501371383666992px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector357 {
            top: -0.000003814697265625px;
            left: 0.0000152587890625px;
            width: 190px;
            height: 22px;
            position: absolute;
          }
          .frame1920wlight-group419 {
            top: 167.8140411376953px;
            left: 281.3779296875px;
            width: 103.56710052490234px;
            height: 10.450118064880371px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group420 {
            top: 0px;
            left: 0px;
            width: 103.56710052490234px;
            height: 10.450118064880371px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector358 {
            top: 9.5367431640625e-7px;
            left: 0.0000152587890625px;
            width: 104px;
            height: 10px;
            position: absolute;
          }
          .frame1920wlight-group421 {
            top: 128.99986267089844px;
            left: 46.883975982666016px;
            width: 237.42774963378906px;
            height: 39.85082244873047px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group422 {
            top: 38.27888488769531px;
            left: 233.2783966064453px;
            width: 4.148708820343018px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector359 {
            top: -0.000002682209014892578px;
            left: -0.000002384185791015625px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group423 {
            top: 38.28327560424805px;
            left: 233.27903747558594px;
            width: 4.06505823135376px;
            height: 1.449142575263977px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector360 {
            top: -0.0000020265579223632812px;
            left: -0.000011444091796875px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group424 {
            top: 38.663570404052734px;
            left: 233.34994506835938px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector361 {
            top: -0.0000019669532775878906px;
            left: 0.000013232231140136719px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group425 {
            top: 37.599239349365234px;
            left: 233.2783966064453px;
            width: 4.148708820343018px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector362 {
            top: 0.0000014901161193847656px;
            left: -0.000002384185791015625px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group426 {
            top: 37.60363006591797px;
            left: 233.27903747558594px;
            width: 4.06505823135376px;
            height: 1.4489942789077759px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector363 {
            top: 0.0000021457672119140625px;
            left: -0.000011444091796875px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group427 {
            top: 37.98329544067383px;
            left: 233.34994506835938px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector364 {
            top: 0.0000034570693969726562px;
            left: 0.000013232231140136719px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group428 {
            top: 36.06865692138672px;
            left: 233.2783966064453px;
            width: 4.149336338043213px;
            height: 2.3797576427459717px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector365 {
            top: -0.000002384185791015625px;
            left: -0.000002384185791015625px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group429 {
            top: 36.069297790527344px;
            left: 233.2783966064453px;
            width: 4.148708820343018px;
            height: 2.3792872428894043px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector366 {
            top: -0.0000036954879760742188px;
            left: -0.000002384185791015625px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group430 {
            top: 36.037818908691406px;
            left: 233.279052734375px;
            width: 4.0037455558776855px;
            height: 2.272533893585205px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector367 {
            top: 0.0000021457672119140625px;
            left: -0.000011444091796875px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group431 {
            top: 36.48472595214844px;
            left: 234.7355499267578px;
            width: 1.2350112199783325px;
            height: 0.6354875564575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector368 {
            top: -0.000002205371856689453px;
            left: 0.0000010728836059570312px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group432 {
            top: 35.787723541259766px;
            left: 234.7393341064453px;
            width: 1.2274805307388306px;
            height: 0.7162817120552063px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector369 {
            top: -0.0000036656856536865234px;
            left: -0.000010311603546142578px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group433 {
            top: 36.14397048950195px;
            left: 234.7355499267578px;
            width: 1.2350112199783325px;
            height: 0.6643834710121155px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector370 {
            top: -1.1920928955078125e-7px;
            left: 0.0000010728836059570312px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group434 {
            top: 37.21770477294922px;
            left: 233.34994506835938px;
            width: 3.254455089569092px;
            height: 0.929640531539917px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector371 {
            top: 2.384185791015625e-7px;
            left: 0.000013232231140136719px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group435 {
            top: 25.832122802734375px;
            left: 211.76173400878906px;
            width: 4.148708820343018px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector372 {
            top: 0.0000032782554626464844px;
            left: -0.000012159347534179688px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group436 {
            top: 25.83652114868164px;
            left: 211.76112365722656px;
            width: 4.065011024475098px;
            height: 1.4489942789077759px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector373 {
            top: -8.344650268554688e-7px;
            left: -0.000014781951904296875px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group437 {
            top: 26.21617889404297px;
            left: 211.8326416015625px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector374 {
            top: 4.172325134277344e-7px;
            left: 0.000012278556823730469px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group438 {
            top: 25.151870727539062px;
            left: 211.76173400878906px;
            width: 4.148708820343018px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector375 {
            top: 0.0000029802322387695312px;
            left: -0.000012159347534179688px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group439 {
            top: 25.156261444091797px;
            left: 211.76112365722656px;
            width: 4.065011024475098px;
            height: 1.449142575263977px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector376 {
            top: -0.0000011324882507324219px;
            left: -0.000014781951904296875px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group440 {
            top: 25.535924911499023px;
            left: 211.8326416015625px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector377 {
            top: 1.7881393432617188e-7px;
            left: 0.000012278556823730469px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group441 {
            top: 23.62253761291504px;
            left: 211.76109313964844px;
            width: 4.149336338043213px;
            height: 2.3791120052337646px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector378 {
            top: -0.0000025033950805664062px;
            left: -0.000003337860107421875px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group442 {
            top: 23.621904373168945px;
            left: 211.76173400878906px;
            width: 4.148708820343018px;
            height: 2.3792872428894043px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector379 {
            top: -0.0000013113021850585938px;
            left: -0.000012159347534179688px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group443 {
            top: 23.590452194213867px;
            left: 211.76174926757812px;
            width: 4.0037455558776855px;
            height: 2.272972822189331px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector380 {
            top: -0.0000010728836059570312px;
            left: -0.000012159347534179688px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group444 {
            top: 24.037973403930664px;
            left: 213.21824645996094px;
            width: 1.2350112199783325px;
            height: 0.6355413198471069px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector381 {
            top: -0.000001043081283569336px;
            left: 1.7881393432617188e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group445 {
            top: 23.34095573425293px;
            left: 213.22203063964844px;
            width: 1.2274805307388306px;
            height: 0.7163402438163757px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector382 {
            top: -0.0000016093254089355469px;
            left: -0.000011205673217773438px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group446 {
            top: 23.696592330932617px;
            left: 213.21824645996094px;
            width: 1.2350112199783325px;
            height: 0.6640510559082031px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector383 {
            top: -5.364418029785156e-7px;
            left: 1.7881393432617188e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group447 {
            top: 24.77094268798828px;
            left: 211.8326416015625px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector384 {
            top: 0.0000013709068298339844px;
            left: 0.000012278556823730469px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group448 {
            top: 13.256102561950684px;
            left: 190.1822967529297px;
            width: 4.148708820343018px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector385 {
            top: 0.0000015497207641601562px;
            left: -0.0000057220458984375px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group449 {
            top: 13.260492324829102px;
            left: 190.18167114257812px;
            width: 4.065011024475098px;
            height: 1.449142575263977px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector386 {
            top: -0.000002562999725341797px;
            left: 0.0000030994415283203125px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group450 {
            top: 13.640156745910645px;
            left: 190.2532196044922px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector387 {
            top: -0.0000013113021850585938px;
            left: 0.0000034570693969726562px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group451 {
            top: 12.57584285736084px;
            left: 190.1822967529297px;
            width: 4.148708820343018px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector388 {
            top: 0.0000013113021850585938px;
            left: -0.0000057220458984375px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group452 {
            top: 12.580232620239258px;
            left: 190.18167114257812px;
            width: 4.065011024475098px;
            height: 1.4489942789077759px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector389 {
            top: -0.0000028014183044433594px;
            left: 0.0000030994415283203125px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group453 {
            top: 12.960524559020996px;
            left: 190.2532196044922px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector390 {
            top: 5.9604644775390625e-8px;
            left: 0.0000034570693969726562px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group454 {
            top: 11.046514511108398px;
            left: 190.18165588378906px;
            width: 4.149336338043213px;
            height: 2.3791120052337646px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector391 {
            top: 5.960464477539062e-7px;
            left: 0.0000030994415283203125px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group455 {
            top: 11.045881271362305px;
            left: 190.1822967529297px;
            width: 4.148708820343018px;
            height: 2.3792872428894043px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector392 {
            top: 0.0000017881393432617188px;
            left: -0.0000057220458984375px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group456 {
            top: 11.014411926269531px;
            left: 190.18231201171875px;
            width: 4.0037455558776855px;
            height: 2.272533893585205px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector393 {
            top: 0px;
            left: -0.0000057220458984375px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group457 {
            top: 11.461938858032227px;
            left: 191.63880920410156px;
            width: 1.2350112199783325px;
            height: 0.6354875564575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector394 {
            top: 8.940696716308594e-8px;
            left: 0.000006616115570068359px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group458 {
            top: 10.764930725097656px;
            left: 191.64259338378906px;
            width: 1.2274805307388306px;
            height: 0.7163358926773071px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector395 {
            top: 0.0000014603137969970703px;
            left: -0.000004827976226806641px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group459 {
            top: 11.120562553405762px;
            left: 191.63880920410156px;
            width: 1.2350112199783325px;
            height: 0.6643834710121155px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector396 {
            top: -0.0000022649765014648438px;
            left: 0.000006616115570068359px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group460 {
            top: 12.19490909576416px;
            left: 190.2532196044922px;
            width: 3.254455089569092px;
            height: 0.929640531539917px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector397 {
            top: 0.0000025033950805664062px;
            left: 0.0000034570693969726562px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group461 {
            top: 27.51457405090332px;
            left: 43.09675216674805px;
            width: 4.148081302642822px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector398 {
            top: 6.556510925292969e-7px;
            left: -0.0000019073486328125px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group462 {
            top: 27.518972396850586px;
            left: 43.096736907958984px;
            width: 4.065521240234375px;
            height: 1.4489942789077759px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector399 {
            top: 0.0000013113021850585938px;
            left: 0.000003814697265625px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group463 {
            top: 27.898630142211914px;
            left: 43.168296813964844px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector400 {
            top: 0.0000026226043701171875px;
            left: -0.0000034570693969726562px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group464 {
            top: 26.834321975708008px;
            left: 43.09675216674805px;
            width: 4.148081302642822px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector401 {
            top: -0.0000024437904357910156px;
            left: -0.0000019073486328125px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group465 {
            top: 26.838712692260742px;
            left: 43.096736907958984px;
            width: 4.065521240234375px;
            height: 1.4491227865219116px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector402 {
            top: 0.0000010728836059570312px;
            left: 0.000003814697265625px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group466 {
            top: 27.21837043762207px;
            left: 43.168296813964844px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector403 {
            top: 0.0000023245811462402344px;
            left: -0.0000034570693969726562px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group467 {
            top: 25.304988861083984px;
            left: 43.09675598144531px;
            width: 4.149336338043213px;
            height: 2.379286527633667px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector404 {
            top: -3.5762786865234375e-7px;
            left: -0.0000019073486328125px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group468 {
            top: 25.30435562133789px;
            left: 43.09675216674805px;
            width: 4.148081302642822px;
            height: 2.3792872428894043px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector405 {
            top: 8.344650268554688e-7px;
            left: -0.0000019073486328125px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group469 {
            top: 25.27289581298828px;
            left: 43.09673309326172px;
            width: 4.005000591278076px;
            height: 2.272989511489868px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector406 {
            top: 0.0000010728836059570312px;
            left: 0.000003814697265625px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group470 {
            top: 25.72042465209961px;
            left: 44.55265426635742px;
            width: 1.2362662553787231px;
            height: 0.6354875564575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector407 {
            top: 0.0000011026859283447266px;
            left: -0.0000015497207641601562px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group471 {
            top: 25.02341079711914px;
            left: 44.55768585205078px;
            width: 1.2274805307388306px;
            height: 0.7163358926773071px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector408 {
            top: -0.000002294778823852539px;
            left: -0.0000021457672119140625px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group472 {
            top: 25.379043579101562px;
            left: 44.55265426635742px;
            width: 1.2362662553787231px;
            height: 0.6640510559082031px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector409 {
            top: 0.0000016093254089355469px;
            left: -0.0000015497207641601562px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group473 {
            top: 26.453393936157227px;
            left: 43.168296813964844px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector410 {
            top: 0.0000035762786865234375px;
            left: -0.0000034570693969726562px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group474 {
            top: 14.81116008758545px;
            left: 21.713726043701172px;
            width: 4.148081302642822px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector411 {
            top: -0.0000020265579223632812px;
            left: 0.0000030994415283203125px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group475 {
            top: 14.81555461883545px;
            left: 21.713729858398438px;
            width: 4.065521240234375px;
            height: 1.449142575263977px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector412 {
            top: -0.0000013709068298339844px;
            left: 0.0000030994415283203125px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group476 {
            top: 15.195219993591309px;
            left: 21.784643173217773px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector413 {
            top: -5.9604644775390625e-8px;
            left: 1.1920928955078125e-7px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group477 {
            top: 14.130900382995605px;
            left: 21.713726043701172px;
            width: 4.148081302642822px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector414 {
            top: -0.0000022649765014648438px;
            left: 0.0000030994415283203125px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group478 {
            top: 14.135294914245605px;
            left: 21.713729858398438px;
            width: 4.065521240234375px;
            height: 1.4489942789077759px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector415 {
            top: -0.0000016093254089355469px;
            left: 0.0000030994415283203125px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group479 {
            top: 14.515586853027344px;
            left: 21.784643173217773px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector416 {
            top: 0.0000012516975402832031px;
            left: 1.1920928955078125e-7px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group480 {
            top: 12.60093879699707px;
            left: 21.71310043334961px;
            width: 4.149336338043213px;
            height: 2.3797576427459717px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector417 {
            top: -0.0000017881393432617188px;
            left: 0.0000016689300537109375px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group481 {
            top: 12.601566314697266px;
            left: 21.713726043701172px;
            width: 4.148081302642822px;
            height: 2.3792872428894043px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector418 {
            top: -2.384185791015625e-7px;
            left: 0.0000030994415283203125px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group482 {
            top: 12.569474220275879px;
            left: 21.713727951049805px;
            width: 4.005000591278076px;
            height: 2.272533893585205px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector419 {
            top: 0.0000011920928955078125px;
            left: 0.0000030994415283203125px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group483 {
            top: 13.01700210571289px;
            left: 23.170894622802734px;
            width: 1.2350112199783325px;
            height: 0.6354875564575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector420 {
            top: 0.0000012814998626708984px;
            left: 0.0000010728836059570312px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group484 {
            top: 12.319989204406738px;
            left: 23.174663543701172px;
            width: 1.2274805307388306px;
            height: 0.7162858247756958px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector421 {
            top: -0.000002115964889526367px;
            left: 1.1920928955078125e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group485 {
            top: 12.676252365112305px;
            left: 23.170856475830078px;
            width: 1.2350503206253052px;
            height: 0.6643834710121155px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector422 {
            top: 5.364418029785156e-7px;
            left: 8.940696716308594e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group486 {
            top: 13.749972343444824px;
            left: 21.784643173217773px;
            width: 3.254455089569092px;
            height: 0.929640531539917px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector423 {
            top: 0.0000037550926208496094px;
            left: 1.1920928955078125e-7px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group487 {
            top: 2.491173505783081px;
            left: 0.0006291866302490234px;
            width: 4.148081302642822px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector424 {
            top: -5.364418029785156e-7px;
            left: -0.0000016689300537109375px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group488 {
            top: 2.495563268661499px;
            left: 4.76837158203125e-7px;
            width: 4.065470218658447px;
            height: 1.4489942789077759px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector425 {
            top: -8.344650268554688e-7px;
            left: 7.152557373046875e-7px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group489 {
            top: 2.8758554458618164px;
            left: 0.0715411901473999px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector426 {
            top: -0.0000017881393432617188px;
            left: -8.344650268554688e-7px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group490 {
            top: 1.8109135627746582px;
            left: 0.0006291866302490234px;
            width: 4.148081302642822px;
            height: 1.571934461593628px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector427 {
            top: -7.748603820800781e-7px;
            left: -0.0000016689300537109375px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group491 {
            top: 1.8153033256530762px;
            left: 4.76837158203125e-7px;
            width: 4.065470218658447px;
            height: 1.449142575263977px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector428 {
            top: -0.0000010728836059570312px;
            left: 7.152557373046875e-7px;
            width: 4px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group492 {
            top: 2.195591688156128px;
            left: 0.0715411901473999px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector429 {
            top: 0.0000017881393432617188px;
            left: -8.344650268554688e-7px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group493 {
            top: 0.2815765142440796px;
            left: 0.0000019073486328125px;
            width: 4.148081302642822px;
            height: 2.3791120052337646px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector430 {
            top: 0.0000013113021850585938px;
            left: 7.152557373046875e-7px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group494 {
            top: 0.2815791368484497px;
            left: 0.0006291866302490234px;
            width: 4.148081302642822px;
            height: 2.3792872428894043px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector431 {
            top: 0.0000013113021850585938px;
            left: -0.0000016689300537109375px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group495 {
            top: 0.24948644638061523px;
            left: -2.384185791015625e-7px;
            width: 4.005000591278076px;
            height: 2.272989511489868px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector432 {
            top: 0.0000017881393432617188px;
            left: 7.152557373046875e-7px;
            width: 4px;
            height: 2px;
            position: absolute;
          }
          .frame1920wlight-group496 {
            top: 0.6970102787017822px;
            left: 1.4571607112884521px;
            width: 1.2350112199783325px;
            height: 0.6355413198471069px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector433 {
            top: 0.000001817941665649414px;
            left: 0.0000013709068298339844px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group497 {
            top: -0.0000017881393432617188px;
            left: 1.4609296321868896px;
            width: 1.2274805307388306px;
            height: 0.7163402438163757px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector434 {
            top: -6.258487701416016e-7px;
            left: 4.172325134277344e-7px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group498 {
            top: 0.3562573194503784px;
            left: 1.457122564315796px;
            width: 1.2350503206253052px;
            height: 0.6640510559082031px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector435 {
            top: 0.0000010728836059570312px;
            left: 0.0000011920928955078125px;
            width: 1px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-group499 {
            top: 1.4299843311309814px;
            left: 0.0715411901473999px;
            width: 3.254455089569092px;
            height: 0.9295570254325867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector436 {
            top: 4.172325134277344e-7px;
            left: -8.344650268554688e-7px;
            width: 3px;
            height: 1px;
            position: absolute;
          }
          .frame1920wlight-maskgroup {
            top: 75.93310546875px;
            left: 0px;
            width: 0px;
            height: 0px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group500 {
            top: 0px;
            left: 0px;
            width: 0px;
            height: 0px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-framelottieelement211 {
            top: 0px;
            left: 0px;
            width: 0px;
            height: 0px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group501 {
            top: -252.27362060546875px;
            left: -125.50926971435547px;
            width: 1152.175048828125px;
            height: 1152.175048828125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-clippathgroup2 {
            top: 0px;
            left: 0px;
            width: 1152.175048828125px;
            height: 1152.175048828125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-framelottieelement217 {
            top: 0px;
            left: 0px;
            width: 1152.175048828125px;
            height: 1152.175048828125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group502 {
            top: -129.0863037109375px;
            left: 0px;
            width: 1152.175048828125px;
            height: 1281.2613525390625px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group503 {
            top: 584.7587280273438px;
            left: 14.96866226196289px;
            width: 1122.2376708984375px;
            height: 656.9029541015625px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group504 {
            top: 11.379852294921875px;
            left: 0.000030517578125px;
            width: 1122.2376708984375px;
            height: 645.5231323242188px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group505 {
            top: 315.26922607421875px;
            left: 1086.7803955078125px;
            width: 35.45711898803711px;
            height: 15.904282569885254px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group506 {
            top: 321.0951843261719px;
            left: 0.0000019073486328125px;
            width: 28.872650146484375px;
            height: 16.597721099853516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group507 {
            top: 0px;
            left: 0.000030517578125px;
            width: 1122.2376708984375px;
            height: 642.3226318359375px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group508 {
            top: 132.1512451171875px;
            left: 115.62936401367188px;
            width: 907.1575927734375px;
            height: 429.99169921875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group509 {
            top: 837.4605712890625px;
            left: 228.3653106689453px;
            width: 749.0545654296875px;
            height: 257.0929260253906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group510 {
            top: 0px;
            left: 0px;
            width: 749.0545654296875px;
            height: 257.0929260253906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group511 {
            top: 129.0863037109375px;
            left: 0px;
            width: 1152.175048828125px;
            height: 1152.175048828125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-rectangle3 {
            top: 0px;
            left: 0px;
            width: 1152px;
            height: 1152px;
            position: absolute;
          }
          .frame1920wlight-group512 {
            top: 298.447509765625px;
            left: 410.702392578125px;
            width: 585.737060546875px;
            height: 233.87551879882812px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group513 {
            top: 0px;
            left: 0.001129150390625px;
            width: 585.7359008789062px;
            height: 220.62872314453125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group514 {
            top: 212.90380859375px;
            left: 368.7525634765625px;
            width: 216.9844207763672px;
            height: 20.97171974182129px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group515 {
            top: 4.633232116699219px;
            left: 0px;
            width: 369.5111083984375px;
            height: 229.24229431152344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group516 {
            top: 713.5036010742188px;
            left: 276.90496826171875px;
            width: 42.01706314086914px;
            height: 144.15948486328125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group517 {
            top: 6.251579284667969px;
            left: 10.468801498413086px;
            width: 31.548259735107422px;
            height: 137.90682983398438px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group518 {
            top: 20.842620849609375px;
            left: 0.001081705093383789px;
            width: 6.268685340881348px;
            height: 123.3168716430664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group519 {
            top: 0.00001239776611328125px;
            left: 0.00109100341796875px;
            width: 42.0159797668457px;
            height: 24.35569953918457px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group520 {
            top: 24.35570526123047px;
            left: 6.084140777587891px;
            width: 4.384666442871094px;
            height: 119.802734375px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group521 {
            top: 29.21982192993164px;
            left: 20.32522201538086px;
            width: 13.333226203918457px;
            height: 17.2169246673584px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group522 {
            top: 24.356740951538086px;
            left: 12.325102806091309px;
            width: 3.1428775787353516px;
            height: 2.8996403217315674px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group523 {
            top: 77.11448669433594px;
            left: 26.146923065185547px;
            width: 1.689856767654419px;
            height: 7.456368923187256px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group524 {
            top: 112.02665710449219px;
            left: 26.146923065185547px;
            width: 1.689856767654419px;
            height: 7.457279682159424px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group525 {
            top: 46.826290130615234px;
            left: 0.000003814697265625px;
            width: 42.0159797668457px;
            height: 19.286128997802734px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group526 {
            top: 63.090118408203125px;
            left: 0.00109100341796875px;
            width: 42.0159797668457px;
            height: 19.28399658203125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group527 {
            top: 98.30821990966797px;
            left: 0.000003814697265625px;
            width: 42.0159797668457px;
            height: 19.28399658203125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group528 {
            top: 7.695253372192383px;
            left: 24.63373374938965px;
            width: 6.549118518829346px;
            height: 3.761385679244995px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group529 {
            top: 11.167430877685547px;
            left: 17.739246368408203px;
            width: 6.796356201171875px;
            height: 3.9032766819000244px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group530 {
            top: 15.07081413269043px;
            left: 10.312108039855957px;
            width: 7.603427410125732px;
            height: 4.366949558258057px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group531 {
            top: 910.3900756835938px;
            left: 373.9789123535156px;
            width: 181.92417907714844px;
            height: 81.16220092773438px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group532 {
            top: 0.0000152587890625px;
            left: 0.00000762939453125px;
            width: 181.92417907714844px;
            height: 81.16220092773438px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group533 {
            top: 618.296630859375px;
            left: 384.90753173828125px;
            width: 125.21795654296875px;
            height: 72.14322662353516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group534 {
            top: 0px;
            left: 0.00000762939453125px;
            width: 125.21795654296875px;
            height: 72.14322662353516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group535 {
            top: 483.1827392578125px;
            left: 301.6532897949219px;
            width: 473.2900390625px;
            height: 321.2306823730469px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group536 {
            top: 0px;
            left: 0.00000762939453125px;
            width: 473.2900390625px;
            height: 321.2306823730469px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group537 {
            top: 322.89385986328125px;
            left: 291.9675598144531px;
            width: 158.4582061767578px;
            height: 403.66668701171875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group538 {
            top: 0px;
            left: 0.00000762939453125px;
            width: 158.4582061767578px;
            height: 403.66668701171875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group539 {
            top: 664.6065673828125px;
            left: 232.72122192382812px;
            width: 190.7489776611328px;
            height: 295.9319152832031px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group540 {
            top: -0.0000152587890625px;
            left: 0px;
            width: 190.7489776611328px;
            height: 295.9319152832031px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group541 {
            top: 723.9136962890625px;
            left: 436.5004577636719px;
            width: 19.74913215637207px;
            height: 11.278512954711914px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group542 {
            top: 0.0000152587890625px;
            left: -0.00000762939453125px;
            width: 19.74913215637207px;
            height: 11.278512954711914px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group543 {
            top: 728.4072265625px;
            left: 436.50042724609375px;
            width: 11.66897201538086px;
            height: 16.86016082763672px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group544 {
            top: 0.0000152587890625px;
            left: 0.00000762939453125px;
            width: 11.66897201538086px;
            height: 16.86016082763672px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group545 {
            top: 730.5280151367188px;
            left: 448.1512756347656px;
            width: 8.097229957580566px;
            height: 14.73930549621582px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group546 {
            top: 0.0000152587890625px;
            left: 0.00000762939453125px;
            width: 8.097229957580566px;
            height: 14.73930549621582px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group547 {
            top: 317.0252685546875px;
            left: 437.35284423828125px;
            width: 9.874566078186035px;
            height: 23.62385368347168px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group548 {
            top: 0px;
            left: -0.00000762939453125px;
            width: 9.874566078186035px;
            height: 23.62385368347168px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group549 {
            top: 384.7688903808594px;
            left: 553.6083984375px;
            width: 167.276611328125px;
            height: 107.03919219970703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group550 {
            top: 0px;
            left: -0.00000762939453125px;
            width: 167.276611328125px;
            height: 107.03919219970703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group551 {
            top: 928.4141845703125px;
            left: 373.9789123535156px;
            width: 150.67355346679688px;
            height: 63.13812255859375px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group552 {
            top: 0.0000152587890625px;
            left: 0.00000762939453125px;
            width: 150.67355346679688px;
            height: 63.13812255859375px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group553 {
            top: 483.1827392578125px;
            left: 301.6532897949219px;
            width: 473.2900390625px;
            height: 321.2306823730469px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group554 {
            top: 0px;
            left: 0.00000762939453125px;
            width: 473.2900390625px;
            height: 321.2306823730469px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group555 {
            top: 723.9136962890625px;
            left: 436.5004577636719px;
            width: 19.74913215637207px;
            height: 11.278512954711914px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group556 {
            top: 0.0000152587890625px;
            left: -0.00000762939453125px;
            width: 19.74913215637207px;
            height: 11.278512954711914px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group557 {
            top: 728.4072265625px;
            left: 436.50042724609375px;
            width: 11.66897201538086px;
            height: 16.86016082763672px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group558 {
            top: 0.0000152587890625px;
            left: 0.00000762939453125px;
            width: 11.66897201538086px;
            height: 16.86016082763672px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group559 {
            top: 547.5018920898438px;
            left: 373.9779052734375px;
            width: 206.88795471191406px;
            height: 328.8734130859375px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group560 {
            top: 0px;
            left: -0.00000762939453125px;
            width: 206.88795471191406px;
            height: 328.8734130859375px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group561 {
            top: 322.89385986328125px;
            left: 291.9675598144531px;
            width: 158.4582061767578px;
            height: 403.66668701171875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group562 {
            top: 0px;
            left: 0.00000762939453125px;
            width: 158.4582061767578px;
            height: 403.66668701171875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group563 {
            top: 664.6065673828125px;
            left: 232.72122192382812px;
            width: 190.7489776611328px;
            height: 295.9319152832031px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group564 {
            top: -0.0000152587890625px;
            left: 0px;
            width: 190.7489776611328px;
            height: 295.9319152832031px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group565 {
            top: 706.3388061523438px;
            left: 373.9779052734375px;
            width: 109.5782470703125px;
            height: 170.0364990234375px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group566 {
            top: -0.0000152587890625px;
            left: -0.00000762939453125px;
            width: 109.5782470703125px;
            height: 170.0364990234375px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group567 {
            top: 317.0252685546875px;
            left: 437.35284423828125px;
            width: 9.874566078186035px;
            height: 23.62385368347168px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group568 {
            top: 0px;
            left: -0.00000762939453125px;
            width: 9.874566078186035px;
            height: 23.62385368347168px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group569 {
            top: 384.7688903808594px;
            left: 553.6083984375px;
            width: 167.276611328125px;
            height: 107.03919219970703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group570 {
            top: 0px;
            left: -0.00000762939453125px;
            width: 167.276611328125px;
            height: 107.03919219970703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group571 {
            top: 702.42138671875px;
            left: 472.48883056640625px;
            width: 13.335359573364258px;
            height: 13.335359573364258px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group572 {
            top: -0.0000057220458984375px;
            left: 0.0000152587890625px;
            width: 13.335359573364258px;
            height: 13.335359573364258px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group573 {
            top: 926.1215209960938px;
            left: 509.4181823730469px;
            width: 13.335359573364258px;
            height: 13.335359573364258px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group574 {
            top: 0.00001049041748046875px;
            left: 0px;
            width: 13.335359573364258px;
            height: 13.335359573364258px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group575 {
            top: 808.0053100585938px;
            left: 401.625px;
            width: 25px;
            height: 25px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group576 {
            top: 0px;
            left: 0px;
            width: 25px;
            height: 25px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group577 {
            top: 129.0863037109375px;
            left: 0px;
            width: 1152.175048828125px;
            height: 1152.175048828125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-rectangle4 {
            top: 0px;
            left: 0px;
            width: 1152px;
            height: 1152px;
            position: absolute;
          }
          .frame1920wlight-group578 {
            top: 314.0914611816406px;
            left: 482.82427978515625px;
            width: 289.5778503417969px;
            height: 89.96138763427734px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group579 {
            top: 0px;
            left: 0px;
            width: 289.5778503417969px;
            height: 89.96138763427734px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group580 {
            top: 410.19891357421875px;
            left: 650.100830078125px;
            width: 289.5799865722656px;
            height: 89.96138763427734px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group581 {
            top: 0px;
            left: 0.000030517578125px;
            width: 289.5799865722656px;
            height: 89.96138763427734px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group582 {
            top: 311.43292236328125px;
            left: 556.572998046875px;
            width: 132.6900177001953px;
            height: 41.52524185180664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group583 {
            top: 0px;
            left: 0px;
            width: 132.6900177001953px;
            height: 41.52524185180664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group584 {
            top: 309.37713623046875px;
            left: 549.462646484375px;
            width: 147.3994598388672px;
            height: 45.737083435058594px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group585 {
            top: -0.0000019073486328125px;
            left: 0px;
            width: 147.3994598388672px;
            height: 45.737083435058594px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group586 {
            top: 312.11358642578125px;
            left: 572.315185546875px;
            width: 99.15106201171875px;
            height: 40.07008743286133px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group587 {
            top: 0.0000019073486328125px;
            left: 0.0000152587890625px;
            width: 99.15106201171875px;
            height: 40.07008743286133px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group588 {
            top: 314.03704833984375px;
            left: 489.8611145019531px;
            width: 131.2946014404297px;
            height: 41.38868713378906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group589 {
            top: -0.0000019073486328125px;
            left: -0.00000762939453125px;
            width: 131.2946014404297px;
            height: 41.38868713378906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group590 {
            top: 311.98980712890625px;
            left: 482.8221435546875px;
            width: 145.85255432128906px;
            height: 45.58559036254883px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group591 {
            top: 0px;
            left: 0px;
            width: 145.85255432128906px;
            height: 45.58559036254883px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group592 {
            top: 314.7145080566406px;
            left: 505.3930358886719px;
            width: 98.09490203857422px;
            height: 39.94206619262695px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group593 {
            top: 0.0000019073486328125px;
            left: 0.00000762939453125px;
            width: 98.09490203857422px;
            height: 39.94206619262695px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group594 {
            top: 352.3852844238281px;
            left: 629.572998046875px;
            width: 135.09466552734375px;
            height: 42.24001693725586px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group595 {
            top: 0px;
            left: 0px;
            width: 135.09466552734375px;
            height: 42.24001693725586px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group596 {
            top: 350.29644775390625px;
            left: 622.3377685546875px;
            width: 150.06439208984375px;
            height: 46.5201301574707px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group597 {
            top: 0px;
            left: 0px;
            width: 150.06439208984375px;
            height: 46.5201301574707px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group598 {
            top: 353.0339050292969px;
            left: 645.6490478515625px;
            width: 100.95613861083984px;
            height: 40.85740661621094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group599 {
            top: 0px;
            left: -0.0000152587890625px;
            width: 100.95613861083984px;
            height: 40.85740661621094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group600 {
            top: 354.4261474609375px;
            left: 560.7689208984375px;
            width: 136.60101318359375px;
            height: 42.72862243652344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group601 {
            top: 0px;
            left: -0.0000152587890625px;
            width: 136.60101318359375px;
            height: 42.72862243652344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group602 {
            top: 352.9197692871094px;
            left: 553.6082763671875px;
            width: 150.09852600097656px;
            height: 46.41984939575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group603 {
            top: 0px;
            left: 0px;
            width: 150.09852600097656px;
            height: 46.41984939575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group604 {
            top: 355.70098876953125px;
            left: 576.6273193359375px;
            width: 99.8743667602539px;
            height: 40.72511672973633px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group605 {
            top: 0px;
            left: 0px;
            width: 99.8743667602539px;
            height: 40.72511672973633px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group606 {
            top: 407.5403137207031px;
            left: 723.851806640625px;
            width: 132.6900177001953px;
            height: 41.52524185180664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group607 {
            top: 0px;
            left: 0.000030517578125px;
            width: 132.6900177001953px;
            height: 41.52524185180664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group608 {
            top: 405.4845275878906px;
            left: 716.741455078125px;
            width: 147.3994598388672px;
            height: 45.737083435058594px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group609 {
            top: 0px;
            left: 0px;
            width: 147.3994598388672px;
            height: 45.737083435058594px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group610 {
            top: 408.220947265625px;
            left: 739.594970703125px;
            width: 99.1500015258789px;
            height: 40.07008743286133px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group611 {
            top: 0px;
            left: 0.000030517578125px;
            width: 99.1500015258789px;
            height: 40.07008743286133px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group612 {
            top: 410.1444091796875px;
            left: 657.1409301757812px;
            width: 131.29248046875px;
            height: 41.38868713378906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group613 {
            top: 0px;
            left: -0.0000152587890625px;
            width: 131.29248046875px;
            height: 41.38868713378906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group614 {
            top: 408.09722900390625px;
            left: 650.100830078125px;
            width: 145.85255432128906px;
            height: 45.58559036254883px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group615 {
            top: 0px;
            left: 0px;
            width: 145.85255432128906px;
            height: 45.58559036254883px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group616 {
            top: 410.8218994140625px;
            left: 672.671875px;
            width: 98.09490203857422px;
            height: 39.94206619262695px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group617 {
            top: 0px;
            left: -0.0000152587890625px;
            width: 98.09490203857422px;
            height: 39.94206619262695px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group618 {
            top: 448.49267578125px;
            left: 796.8516845703125px;
            width: 135.09466552734375px;
            height: 42.24001693725586px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group619 {
            top: 0px;
            left: 0.000030517578125px;
            width: 135.09466552734375px;
            height: 42.24001693725586px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group620 {
            top: 446.40380859375px;
            left: 789.616455078125px;
            width: 150.06439208984375px;
            height: 46.5201301574707px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group621 {
            top: 0px;
            left: -0.000030517578125px;
            width: 150.06439208984375px;
            height: 46.5201301574707px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group622 {
            top: 449.141357421875px;
            left: 812.9277954101562px;
            width: 100.95613861083984px;
            height: 40.85740661621094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group623 {
            top: 0px;
            left: 0px;
            width: 100.95613861083984px;
            height: 40.85740661621094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group624 {
            top: 450.5335388183594px;
            left: 728.0477294921875px;
            width: 136.60101318359375px;
            height: 42.72862243652344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group625 {
            top: 0px;
            left: 0px;
            width: 136.60101318359375px;
            height: 42.72862243652344px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group626 {
            top: 449.02716064453125px;
            left: 720.885986328125px;
            width: 150.09852600097656px;
            height: 46.41984939575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group627 {
            top: 0px;
            left: 0.000030517578125px;
            width: 150.09852600097656px;
            height: 46.41984939575195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group628 {
            top: 451.80841064453125px;
            left: 743.9060668945312px;
            width: 99.8743667602539px;
            height: 40.72511672973633px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group629 {
            top: 0px;
            left: 0px;
            width: 99.8743667602539px;
            height: 40.72511672973633px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group630 {
            top: 713.031005859375px;
            left: 165.52809143066406px;
            width: 925.1199951171875px;
            height: 447.970703125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group631 {
            top: 230.3365020751953px;
            left: 0px;
            width: 80.0534896850586px;
            height: 46.20808410644531px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group632 {
            top: 256.83984375px;
            left: 45.943023681640625px;
            width: 1.3193567991256714px;
            height: 1.6656081676483154px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group633 {
            top: 256.7790222167969px;
            left: 51.954463958740234px;
            width: 1.4631142616271973px;
            height: 2.028196096420288px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group634 {
            top: 241.0883026123047px;
            left: 45.67912673950195px;
            width: 8.206396102905273px;
            height: 20.491233825683594px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group635 {
            top: 258.79766845703125px;
            left: 45.938724517822266px;
            width: 1.0129657983779907px;
            height: 1.642916202545166px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group636 {
            top: 259.935791015625px;
            left: 50.29030990600586px;
            width: 0.983616054058075px;
            height: 1.462792992591858px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group637 {
            top: 259.2453308105469px;
            left: 51.99024200439453px;
            width: 1.1644901037216187px;
            height: 1.0235239267349243px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group638 {
            top: 242.58013916015625px;
            left: 27.1031494140625px;
            width: 1.3144038915634155px;
            height: 1.663994550704956px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group639 {
            top: 242.52249145507812px;
            left: 20.9359130859375px;
            width: 1.471625566482544px;
            height: 2.0272767543792725px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group640 {
            top: 226.82054138183594px;
            left: 20.478845596313477px;
            width: 8.205466270446777px;
            height: 20.49857521057129px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group641 {
            top: 244.53945922851562px;
            left: 27.417015075683594px;
            width: 0.995826005935669px;
            height: 1.632247805595398px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group642 {
            top: 245.67446899414062px;
            left: 23.087236404418945px;
            width: 0.9921507239341736px;
            height: 1.467038869857788px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group643 {
            top: 244.98556518554688px;
            left: 21.224239349365234px;
            width: 1.1486918926239014px;
            height: 1.023976445198059px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group644 {
            top: 211.5162353515625px;
            left: 1.8246612548828125px;
            width: 80.98656463623047px;
            height: 47.5179328918457px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group645 {
            top: 207.2274169921875px;
            left: 1.8221321105957031px;
            width: 80.99072265625px;
            height: 47.56670379638672px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group646 {
            top: 203.79429626464844px;
            left: 1.8239936828613281px;
            width: 80.98471069335938px;
            height: 47.57911682128906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group647 {
            top: 199.85220336914062px;
            left: 1.8217277526855469px;
            width: 80.98951721191406px;
            height: 47.5195198059082px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group648 {
            top: 195.2767333984375px;
            left: 1.8282432556152344px;
            width: 80.98178100585938px;
            height: 47.53034591674805px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group649 {
            top: 191.1561279296875px;
            left: 1.8239936828613281px;
            width: 80.9883041381836px;
            height: 47.57470703125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group650 {
            top: 187.19911193847656px;
            left: 1.8360023498535156px;
            width: 80.97510528564453px;
            height: 47.57191467285156px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group651 {
            top: 186.75840759277344px;
            left: 5.2245330810546875px;
            width: 72.84066772460938px;
            height: 42.838600158691406px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group652 {
            top: 185.98643493652344px;
            left: 8.451400756835938px;
            width: 66.38928985595703px;
            height: 38.911170959472656px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group653 {
            top: 283.4454345703125px;
            left: 91.79739379882812px;
            width: 80.0534896850586px;
            height: 46.20808410644531px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group654 {
            top: 309.9498596191406px;
            left: 137.74142456054688px;
            width: 1.317937970161438px;
            height: 1.6656081676483154px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group655 {
            top: 309.8899841308594px;
            left: 143.75189208984375px;
            width: 1.4631142616271973px;
            height: 2.0271542072296143px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group656 {
            top: 294.1993713378906px;
            left: 137.47653198242188px;
            width: 8.206396102905273px;
            height: 20.49178123474121px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group657 {
            top: 311.9065856933594px;
            left: 137.73719787597656px;
            width: 1.0109102725982666px;
            height: 1.6450499296188354px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group658 {
            top: 313.0457458496094px;
            left: 142.0876922607422px;
            width: 0.983616054058075px;
            height: 1.4638381004333496px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group659 {
            top: 312.3562316894531px;
            left: 143.78741455078125px;
            width: 1.1647084951400757px;
            height: 1.0235239267349243px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group660 {
            top: 295.6900634765625px;
            left: 118.90106201171875px;
            width: 1.3139569759368896px;
            height: 1.663994550704956px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group661 {
            top: 295.6323547363281px;
            left: 112.73332214355469px;
            width: 1.471552848815918px;
            height: 2.0272767543792725px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group662 {
            top: 279.93048095703125px;
            left: 112.27626037597656px;
            width: 8.205466270446777px;
            height: 20.499643325805664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group663 {
            top: 297.6494445800781px;
            left: 119.21539306640625px;
            width: 0.9948418736457825px;
            height: 1.632247805595398px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group664 {
            top: 298.7854309082031px;
            left: 114.88465881347656px;
            width: 0.9921507239341736px;
            height: 1.4670606851577759px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group665 {
            top: 298.0955810546875px;
            left: 113.02165222167969px;
            width: 1.1478372812271118px;
            height: 1.023976445198059px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group666 {
            top: 264.62725830078125px;
            left: 93.62205505371094px;
            width: 80.98656463623047px;
            height: 47.5179328918457px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group667 {
            top: 260.3373718261719px;
            left: 93.61956787109375px;
            width: 80.99072265625px;
            height: 47.566307067871094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group668 {
            top: 256.90411376953125px;
            left: 93.62139892578125px;
            width: 80.98471069335938px;
            height: 47.57911682128906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group669 {
            top: 252.96212768554688px;
            left: 93.61912536621094px;
            width: 80.98951721191406px;
            height: 47.5195198059082px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group670 {
            top: 248.3870849609375px;
            left: 93.62564086914062px;
            width: 80.98178100585938px;
            height: 47.52939224243164px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group671 {
            top: 244.26608276367188px;
            left: 93.62139892578125px;
            width: 80.9883041381836px;
            height: 47.57470703125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group672 {
            top: 240.3089599609375px;
            left: 93.63340759277344px;
            width: 80.97510528564453px;
            height: 47.5729866027832px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group673 {
            top: 239.86837768554688px;
            left: 97.02191162109375px;
            width: 72.84066772460938px;
            height: 42.838600158691406px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group674 {
            top: 239.09640502929688px;
            left: 100.2498779296875px;
            width: 66.38928985595703px;
            height: 38.911170959472656px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group675 {
            top: 338.4083557128906px;
            left: 188.720947265625px;
            width: 80.0534896850586px;
            height: 46.20808410644531px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group676 {
            top: 364.9117736816406px;
            left: 234.66494750976562px;
            width: 1.317937970161438px;
            height: 1.6656081676483154px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group677 {
            top: 364.85089111328125px;
            left: 240.67431640625px;
            width: 1.4631142616271973px;
            height: 2.028196096420288px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group678 {
            top: 349.1602478027344px;
            left: 234.40008544921875px;
            width: 8.206396102905273px;
            height: 20.49178123474121px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group679 {
            top: 366.8695373535156px;
            left: 234.6606903076172px;
            width: 1.0109102725982666px;
            height: 1.642916202545166px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group680 {
            top: 368.00775146484375px;
            left: 239.01124572753906px;
            width: 0.983616054058075px;
            height: 1.4638381004333496px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group681 {
            top: 367.3171691894531px;
            left: 240.70989990234375px;
            width: 1.1647084951400757px;
            height: 1.0235239267349243px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group682 {
            top: 350.6519470214844px;
            left: 215.823486328125px;
            width: 1.3139569759368896px;
            height: 1.663994550704956px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group683 {
            top: 350.59442138671875px;
            left: 209.65682983398438px;
            width: 1.471552848815918px;
            height: 2.0272767543792725px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group684 {
            top: 334.8924255371094px;
            left: 209.1997833251953px;
            width: 8.205466270446777px;
            height: 20.499784469604492px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group685 {
            top: 352.61138916015625px;
            left: 216.138916015625px;
            width: 0.9948418736457825px;
            height: 1.632247805595398px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group686 {
            top: 353.74737548828125px;
            left: 211.8081512451172px;
            width: 0.9921507239341736px;
            height: 1.4670606851577759px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group687 {
            top: 353.05743408203125px;
            left: 209.94410705566406px;
            width: 1.1478372812271118px;
            height: 1.023976445198059px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group688 {
            top: 319.5881042480469px;
            left: 190.5456085205078px;
            width: 80.98656463623047px;
            height: 47.5179328918457px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group689 {
            top: 315.2992248535156px;
            left: 190.5419921875px;
            width: 80.99072265625px;
            height: 47.566307067871094px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group690 {
            top: 311.8661193847656px;
            left: 190.54385375976562px;
            width: 80.98471069335938px;
            height: 47.57911682128906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group691 {
            top: 307.92413330078125px;
            left: 190.54322814941406px;
            width: 80.98898315429688px;
            height: 47.5195198059082px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group692 {
            top: 303.34893798828125px;
            left: 190.54920959472656px;
            width: 80.98178100585938px;
            height: 47.52939224243164px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group693 {
            top: 299.2280578613281px;
            left: 190.54385375976562px;
            width: 80.9883041381836px;
            height: 47.57470703125px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group694 {
            top: 295.27093505859375px;
            left: 190.55587768554688px;
            width: 80.97510528564453px;
            height: 47.5729866027832px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group695 {
            top: 294.82928466796875px;
            left: 193.94546508789062px;
            width: 72.84066772460938px;
            height: 42.839664459228516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group696 {
            top: 294.058349609375px;
            left: 197.1733856201172px;
            width: 66.38822174072266px;
            height: 38.91010665893555px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group697 {
            top: 365.03411865234375px;
            left: 472.1042175292969px;
            width: 66.77921295166016px;
            height: 38.55572509765625px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group698 {
            top: 377.2267150878906px;
            left: 496.1177062988281px;
            width: 3.360358476638794px;
            height: 4.249197006225586px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group699 {
            top: 377.0732727050781px;
            left: 511.03778076171875px;
            width: 3.746447801589966px;
            height: 5.178410530090332px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group700 {
            top: 313.91650390625px;
            left: 495.015625px;
            width: 20.957143783569336px;
            height: 75.39359283447266px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group701 {
            top: 382.2254638671875px;
            left: 495.6966552734375px;
            width: 2.559588670730591px;
            height: 4.177700996398926px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group702 {
            top: 385.12042236328125px;
            left: 506.7820739746094px;
            width: 2.5241167545318604px;
            height: 3.739732027053833px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group703 {
            top: 383.3711242675781px;
            left: 511.1263427734375px;
            width: 2.949738025665283px;
            height: 2.603222370147705px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group704 {
            top: 303.5860900878906px;
            left: 476.4559326171875px;
            width: 54.53276062011719px;
            height: 30.975473403930664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group705 {
            top: 289.95660400390625px;
            left: 471.5632019042969px;
            width: 64.93053436279297px;
            height: 36.76585006713867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group706 {
            top: 273.4154052734375px;
            left: 467.21099853515625px;
            width: 74.04367065429688px;
            height: 42.06171417236328px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group707 {
            top: 260.25738525390625px;
            left: 466.4965515136719px;
            width: 76.60324096679688px;
            height: 43.37912368774414px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group708 {
            top: 247.32211303710938px;
            left: 467.8798522949219px;
            width: 74.49325561523438px;
            height: 42.31252670288086px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group709 {
            top: 237.35629272460938px;
            left: 469.9515075683594px;
            width: 68.30278778076172px;
            height: 38.67600631713867px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group710 {
            top: 226.8106231689453px;
            left: 472.5641784667969px;
            width: 64.12916564941406px;
            height: 36.4244270324707px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group711 {
            top: 217.81646728515625px;
            left: 475.03961181640625px;
            width: 59.15618896484375px;
            height: 33.50348663330078px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group712 {
            top: 208.70840454101562px;
            left: 480.43072509765625px;
            width: 50.12754821777344px;
            height: 28.498939514160156px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group713 {
            top: 199.68853759765625px;
            left: 484.0685119628906px;
            width: 41.1968994140625px;
            height: 23.42418670654297px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group714 {
            top: 192.15560913085938px;
            left: 488.19873046875px;
            width: 32.60015106201172px;
            height: 18.459070205688477px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group715 {
            top: 186.58184814453125px;
            left: 491.7948913574219px;
            width: 26.26866912841797px;
            height: 14.93281078338623px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group716 {
            top: 181.40643310546875px;
            left: 493.5335998535156px;
            width: 22.331127166748047px;
            height: 12.63711929321289px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group717 {
            top: 177.27561950683594px;
            left: 496.1828918457031px;
            width: 17.480321884155273px;
            height: 9.945452690124512px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group718 {
            top: 417.4347229003906px;
            left: 437.73095703125px;
            width: 52.88723373413086px;
            height: 30.535972595214844px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group719 {
            top: 427.0928039550781px;
            left: 456.7476501464844px;
            width: 2.661508798599243px;
            height: 3.364544153213501px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group720 {
            top: 426.9708557128906px;
            left: 468.564453125px;
            width: 2.967603921890259px;
            height: 4.1009135246276855px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group721 {
            top: 376.9510498046875px;
            left: 455.876220703125px;
            width: 16.59769630432129px;
            height: 59.710453033447266px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group722 {
            top: 431.05108642578125px;
            left: 456.41497802734375px;
            width: 2.0269172191619873px;
            height: 3.3082358837127686px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group723 {
            top: 433.34320068359375px;
            left: 465.19384765625px;
            width: 1.9992369413375854px;
            height: 2.962965726852417px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group724 {
            top: 431.95794677734375px;
            left: 468.6357727050781px;
            width: 2.3350625038146973px;
            height: 2.061049461364746px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group725 {
            top: 368.769287109375px;
            left: 441.17724609375px;
            width: 43.18755340576172px;
            height: 24.532161712646484px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group726 {
            top: 357.9749755859375px;
            left: 437.3027038574219px;
            width: 51.423011779785156px;
            height: 29.118824005126953px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group727 {
            top: 344.87506103515625px;
            left: 433.8546447753906px;
            width: 58.6412467956543px;
            height: 33.311988830566406px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group728 {
            top: 334.455810546875px;
            left: 433.28887939453125px;
            width: 60.667755126953125px;
            height: 34.354549407958984px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group729 {
            top: 324.210205078125px;
            left: 434.38421630859375px;
            width: 58.997196197509766px;
            height: 33.51055145263672px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group730 {
            top: 316.3160400390625px;
            left: 436.0245056152344px;
            width: 54.094486236572266px;
            height: 30.63051986694336px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group731 {
            top: 307.9644775390625px;
            left: 438.0943298339844px;
            width: 50.78957748413086px;
            height: 28.848230361938477px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group732 {
            top: 300.84210205078125px;
            left: 440.0552673339844px;
            width: 46.8507194519043px;
            height: 26.533632278442383px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group733 {
            top: 293.6285705566406px;
            left: 444.3236999511719px;
            width: 39.701080322265625px;
            height: 22.570430755615234px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group734 {
            top: 286.485107421875px;
            left: 447.2066650390625px;
            width: 32.62621307373047px;
            height: 18.551259994506836px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group735 {
            top: 280.51995849609375px;
            left: 450.4761962890625px;
            width: 25.820186614990234px;
            height: 14.618221282958984px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group736 {
            top: 276.10528564453125px;
            left: 453.325439453125px;
            width: 20.803329467773438px;
            height: 11.826982498168945px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group737 {
            top: 272.006103515625px;
            left: 454.7012939453125px;
            width: 17.6861515045166px;
            height: 10.008187294006348px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group738 {
            top: 268.73468017578125px;
            left: 456.8012390136719px;
            width: 13.843265533447266px;
            height: 7.875941753387451px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group739 {
            top: 168.25682067871094px;
            left: 861.4989013671875px;
            width: 59.842559814453125px;
            height: 34.551517486572266px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group740 {
            top: 179.18234252929688px;
            left: 883.0176391601562px;
            width: 3.010906457901001px;
            height: 3.808027505874634px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group741 {
            top: 179.04579162597656px;
            left: 896.3881225585938px;
            width: 3.358212471008301px;
            height: 4.6407036781311035px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group742 {
            top: 122.44841003417969px;
            left: 882.0306396484375px;
            width: 18.781362533569336px;
            height: 67.56304931640625px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group743 {
            top: 183.6630096435547px;
            left: 882.6397094726562px;
            width: 2.2939743995666504px;
            height: 3.7424349784851074px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group744 {
            top: 186.25608825683594px;
            left: 892.573974609375px;
            width: 2.261676788330078px;
            height: 3.3524038791656494px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group745 {
            top: 184.6876983642578px;
            left: 896.4684448242188px;
            width: 2.643225908279419px;
            height: 2.3326597213745117px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group746 {
            top: 113.19064331054688px;
            left: 865.3978881835938px;
            width: 48.868614196777344px;
            height: 27.75946617126465px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group747 {
            top: 100.97765350341797px;
            left: 861.0149536132812px;
            width: 58.18657302856445px;
            height: 32.94660568237305px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group748 {
            top: 86.154541015625px;
            left: 857.1133422851562px;
            width: 66.35260772705078px;
            height: 37.69253921508789px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group749 {
            top: 74.36276245117188px;
            left: 856.4739990234375px;
            width: 68.64603424072266px;
            height: 38.87363815307617px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group750 {
            top: 62.77068328857422px;
            left: 857.7130737304688px;
            width: 66.75614166259766px;
            height: 37.9184684753418px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group751 {
            top: 53.838531494140625px;
            left: 859.5700073242188px;
            width: 61.208370208740234px;
            height: 34.65913009643555px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group752 {
            top: 44.38996887207031px;
            left: 861.9111938476562px;
            width: 57.468563079833984px;
            height: 32.64201354980469px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group753 {
            top: 36.33213806152344px;
            left: 864.1289672851562px;
            width: 53.012451171875px;
            height: 30.02322769165039px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group754 {
            top: 28.168163299560547px;
            left: 868.960205078125px;
            width: 44.92156982421875px;
            height: 25.53883934020996px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group755 {
            top: 20.0859317779541px;
            left: 872.2218627929688px;
            width: 36.917022705078125px;
            height: 20.99030876159668px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group756 {
            top: 13.335317611694336px;
            left: 875.9208374023438px;
            width: 29.214839935302734px;
            height: 16.540645599365234px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group757 {
            top: 8.339370727539062px;
            left: 879.1441040039062px;
            width: 23.539554595947266px;
            height: 13.382203102111816px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group758 {
            top: 3.700763702392578px;
            left: 880.7013549804688px;
            width: 20.01263999938965px;
            height: 11.324653625488281px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group759 {
            top: -0.000013828277587890625px;
            left: 883.075439453125px;
            width: 15.66552448272705px;
            height: 8.912263870239258px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group760 {
            top: 219.5323486328125px;
            left: 57.96293258666992px;
            width: 428.0799560546875px;
            height: 723.8364868164062px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group761 {
            top: 54.413299560546875px;
            left: 377.1346130371094px;
            width: 0.5942236185073853px;
            height: 43.81678771972656px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group762 {
            top: 54.10816955566406px;
            left: 381.4702453613281px;
            width: 0.5024763345718384px;
            height: 46.60761260986328px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group763 {
            top: 53.19709777832031px;
            left: 377.7288818359375px;
            width: 1.6621190309524536px;
            height: 46.00592041015625px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group764 {
            top: 53.197113037109375px;
            left: 379.389892578125px;
            width: 2.0803160667419434px;
            height: 47.224239349365234px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group765 {
            top: 60.16456604003906px;
            left: 387.3004455566406px;
            width: 0.38832566142082214px;
            height: 43.900001525878906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group766 {
            top: 59.267356872558594px;
            left: 387.68878173828125px;
            width: 3.219689130783081px;
            height: 46.682289123535156px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group767 {
            top: 64.66444396972656px;
            left: 420.97381591796875px;
            width: 1.7325297594070435px;
            height: 21.586002349853516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group768 {
            top: 22.357208251953125px;
            left: 347.7093200683594px;
            width: 1.7325297594070435px;
            height: 21.586002349853516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group769 {
            top: 19.485313415527344px;
            left: 347.52581787109375px;
            width: 2.0995190143585205px;
            height: 1.0803288221359253px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group770 {
            top: 18.300291061401367px;
            left: 347.5322570800781px;
            width: 2.086716890335083px;
            height: 1.2177709341049194px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group771 {
            top: 18.90494728088379px;
            left: 347.52581787109375px;
            width: 2.0995190143585205px;
            height: 1.129451870918274px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group772 {
            top: 43.5316276550293px;
            left: 384.3954162597656px;
            width: 1.7325297594070435px;
            height: 21.586002349853516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group773 {
            top: 40.65972137451172px;
            left: 384.2119445800781px;
            width: 2.0995190143585205px;
            height: 1.0803288221359253px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group774 {
            top: 39.474796295166016px;
            left: 384.2183532714844px;
            width: 2.086716890335083px;
            height: 1.2176859378814697px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group775 {
            top: 40.080440521240234px;
            left: 384.2119445800781px;
            width: 2.0995190143585205px;
            height: 1.129451870918274px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group776 {
            top: 52.552738189697266px;
            left: 377.1335754394531px;
            width: 4.83913516998291px;
            height: 2.086716890335083px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group777 {
            top: 57.999961853027344px;
            left: 387.7101135253906px;
            width: 2.0803160667419434px;
            height: 2.0035042762756348px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group778 {
            top: 57.709774017333984px;
            left: 387.3004455566406px;
            width: 3.6080148220062256px;
            height: 2.795091152191162px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group779 {
            top: 30.50564193725586px;
            left: 338.4663391113281px;
            width: 89.61361694335938px;
            height: 51.7369270324707px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group780 {
            top: 32.5987548828125px;
            left: 338.46636962890625px;
            width: 85.99066162109375px;
            height: 50.22202682495117px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group781 {
            top: 81.02425384521484px;
            left: 424.9595031738281px;
            width: 2.617997884750366px;
            height: 3.021259069442749px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group782 {
            top: 80.15478515625px;
            left: 424.4580993652344px;
            width: 3.6218836307525635px;
            height: 3.891791343688965px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group783 {
            top: 676.5909423828125px;
            left: 0px;
            width: 81.68494415283203px;
            height: 47.24557876586914px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group784 {
            top: 46.3651237487793px;
            left: 97.66498565673828px;
            width: 1.7325297594070435px;
            height: 21.586002349853516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group785 {
            top: 4.056824684143066px;
            left: 24.400510787963867px;
            width: 1.7325297594070435px;
            height: 21.586002349853516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group786 {
            top: 1.1849257946014404px;
            left: 24.2159481048584px;
            width: 2.1016526222229004px;
            height: 1.0803288221359253px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group787 {
            top: 1.7881393432617188e-7px;
            left: 24.222352981567383px;
            width: 2.088850498199463px;
            height: 1.2176789045333862px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group788 {
            top: 0.6056313514709473px;
            left: 24.2159481048584px;
            width: 2.1016526222229004px;
            height: 1.1288868188858032px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group789 {
            top: 25.2322998046875px;
            left: 61.08555221557617px;
            width: 1.7325297594070435px;
            height: 21.586002349853516px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group790 {
            top: 22.359336853027344px;
            left: 60.90205383300781px;
            width: 2.0995190143585205px;
            height: 1.0803288221359253px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group791 {
            top: 21.174421310424805px;
            left: 60.9084587097168px;
            width: 2.086716890335083px;
            height: 1.2177709341049194px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group792 {
            top: 21.78006362915039px;
            left: 60.90198516845703px;
            width: 2.09958553314209px;
            height: 1.1288868188858032px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group793 {
            top: 34.896728515625px;
            left: 48.61149597167969px;
            width: 7.470623970031738px;
            height: 34.35401916503906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group794 {
            top: 36.112892150878906px;
            left: 53.82365036010742px;
            width: 0.59529048204422px;
            height: 25.448131561279297px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group795 {
            top: 34.8956413269043px;
            left: 56.0810546875px;
            width: 7.909468173980713px;
            height: 33.15277099609375px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group796 {
            top: 34.25235366821289px;
            left: 53.82471466064453px;
            width: 4.83913516998291px;
            height: 2.086716890335083px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group797 {
            top: 35.80885696411133px;
            left: 58.160301208496094px;
            width: 0.5035431385040283px;
            height: 25.512142181396484px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group798 {
            top: 57.131561279296875px;
            left: 58.16136932373047px;
            width: 5.8291521072387695px;
            height: 7.548880577087402px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group799 {
            top: 39.699581146240234px;
            left: 64.40125274658203px;
            width: 2.0803160667419434px;
            height: 2.0035042762756348px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group800 {
            top: 39.40940856933594px;
            left: 63.99158477783203px;
            width: 3.6080148220062256px;
            height: 2.795091152191162px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group801 {
            top: 61.383941650390625px;
            left: 67.5985336303711px;
            width: 4.060349941253662px;
            height: 4.683378219604492px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group802 {
            top: 63.72563171386719px;
            left: 67.5985336303711px;
            width: 4.060349941253662px;
            height: 2.927377939224243px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group803 {
            top: 65.20210266113281px;
            left: 48.615386962890625px;
            width: 7.405925273895264px;
            height: 630.7841796875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group804 {
            top: 58.20478820800781px;
            left: 48.62178421020508px;
            width: 17.87151527404785px;
            height: 10.323273658752441px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group805 {
            top: 64.21211242675781px;
            left: 56.02131652832031px;
            width: 10.471991539001465px;
            height: 631.4857788085938px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group806 {
            top: 67.12133026123047px;
            left: 47.89634704589844px;
            width: 8.509025573730469px;
            height: 8.534329414367676px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group807 {
            top: 40.965904235839844px;
            left: 56.40750503540039px;
            width: 11.191033363342285px;
            height: 34.33481216430664px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group808 {
            top: 65.84434509277344px;
            left: 47.89634704589844px;
            width: 0.7190425395965576px;
            height: 2.5198493003845215px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group809 {
            top: 67.08507537841797px;
            left: 48.615386962890625px;
            width: 15.763461112976074px;
            height: 3.765873908996582px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group810 {
            top: 41.864166259765625px;
            left: 63.99159240722656px;
            width: 0.38832566142082214px;
            height: 25.561214447021484px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group811 {
            top: 12.205265045166016px;
            left: 15.157508850097656px;
            width: 89.61361694335938px;
            height: 51.73479080200195px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group812 {
            top: 14.299453735351562px;
            left: 15.156429290771484px;
            width: 85.99280548095703px;
            height: 50.22202682495117px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group813 {
            top: 62.72601318359375px;
            left: 101.65065002441406px;
            width: 2.617997884750366px;
            height: 3.01912522315979px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group814 {
            top: 61.854393005371094px;
            left: 101.14923858642578px;
            width: 3.620816707611084px;
            height: 3.891791343688965px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group815 {
            top: 243.43328857421875px;
            left: 120.14200592041016px;
            width: 322.3828430175781px;
            height: 36.602752685546875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group816 {
            top: 0px;
            left: 0px;
            width: 322.3828430175781px;
            height: 36.602752685546875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group817 {
            top: 223.00991821289062px;
            left: 83.2297134399414px;
            width: 322.3828430175781px;
            height: 36.602752685546875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group818 {
            top: -0.000003814697265625px;
            left: 0px;
            width: 322.3828430175781px;
            height: 36.602752685546875px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group819 {
            top: 266.4970703125px;
            left: 478.342529296875px;
            width: 322.9162292480469px;
            height: 36.552330017089844px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group820 {
            top: 0px;
            left: 0px;
            width: 322.9162292480469px;
            height: 36.552330017089844px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group821 {
            top: 285.2839050292969px;
            left: 478.342529296875px;
            width: 176.06407165527344px;
            height: 17.765199661254883px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group822 {
            top: 0px;
            left: 0px;
            width: 176.06407165527344px;
            height: 17.765199661254883px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group823 {
            top: 219.2998046875px;
            left: 79.70277404785156px;
            width: 403.6271667480469px;
            height: 67.74636840820312px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group824 {
            top: 65.07408142089844px;
            left: 396.57330322265625px;
            width: 7.052804470062256px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group825 {
            top: 65.08155059814453px;
            left: 396.5743713378906px;
            width: 6.910599231719971px;
            height: 2.4635424613952637px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group826 {
            top: 65.72805786132812px;
            left: 396.6949462890625px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group827 {
            top: 63.918701171875px;
            left: 396.57330322265625px;
            width: 7.052804470062256px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group828 {
            top: 63.926170349121094px;
            left: 396.5743713378906px;
            width: 6.910599231719971px;
            height: 2.463290214538574px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group829 {
            top: 64.57159423828125px;
            left: 396.6949462890625px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group830 {
            top: 61.31669998168945px;
            left: 396.57330322265625px;
            width: 7.0538716316223145px;
            height: 4.04558801651001px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group831 {
            top: 61.31778335571289px;
            left: 396.57330322265625px;
            width: 7.052804470062256px;
            height: 4.044788360595703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group832 {
            top: 61.26428985595703px;
            left: 396.5743713378906px;
            width: 6.806367874145508px;
            height: 3.8633077144622803px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group833 {
            top: 62.024024963378906px;
            left: 399.05047607421875px;
            width: 2.0995190143585205px;
            height: 1.0803288221359253px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group834 {
            top: 60.839107513427734px;
            left: 399.0569152832031px;
            width: 2.086716890335083px;
            height: 1.2176789045333862px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group835 {
            top: 61.444740295410156px;
            left: 399.05047607421875px;
            width: 2.0995190143585205px;
            height: 1.129451870918274px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group836 {
            top: 63.27008056640625px;
            left: 396.6949462890625px;
            width: 5.53257417678833px;
            height: 1.5803889036178589px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group837 {
            top: 43.914615631103516px;
            left: 359.9949645996094px;
            width: 7.052804470062256px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group838 {
            top: 43.92208480834961px;
            left: 359.9939270019531px;
            width: 6.910519123077393px;
            height: 2.463290214538574px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group839 {
            top: 44.567501068115234px;
            left: 360.1155090332031px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group840 {
            top: 42.75816345214844px;
            left: 359.9949645996094px;
            width: 7.052804470062256px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group841 {
            top: 42.76563262939453px;
            left: 359.9939270019531px;
            width: 6.910519123077393px;
            height: 2.4635424613952637px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group842 {
            top: 43.41105651855469px;
            left: 360.1155090332031px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group843 {
            top: 40.158302307128906px;
            left: 359.993896484375px;
            width: 7.0538716316223145px;
            height: 4.044490337371826px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group844 {
            top: 40.1572265625px;
            left: 359.9949645996094px;
            width: 7.052804470062256px;
            height: 4.044788360595703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group845 {
            top: 40.10375213623047px;
            left: 359.9949645996094px;
            width: 6.806367874145508px;
            height: 3.864053726196289px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group846 {
            top: 40.864540100097656px;
            left: 362.4710693359375px;
            width: 2.0995190143585205px;
            height: 1.0804202556610107px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group847 {
            top: 39.67961502075195px;
            left: 362.47747802734375px;
            width: 2.086716890335083px;
            height: 1.2177784442901611px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group848 {
            top: 40.28419494628906px;
            left: 362.4710693359375px;
            width: 2.0995190143585205px;
            height: 1.1288868188858032px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group849 {
            top: 42.11060333251953px;
            left: 360.1155090332031px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group850 {
            top: 22.535364151000977px;
            left: 323.3099365234375px;
            width: 7.052804470062256px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group851 {
            top: 22.54283905029297px;
            left: 323.3088684082031px;
            width: 6.910519123077393px;
            height: 2.4635424613952637px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group852 {
            top: 23.18824005126953px;
            left: 323.43048095703125px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group853 {
            top: 21.378917694091797px;
            left: 323.3099365234375px;
            width: 7.052804470062256px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group854 {
            top: 21.386388778686523px;
            left: 323.3088684082031px;
            width: 6.910519123077393px;
            height: 2.463290214538574px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group855 {
            top: 22.03288459777832px;
            left: 323.43048095703125px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group856 {
            top: 18.77904510498047px;
            left: 323.3088684082031px;
            width: 7.0538716316223145px;
            height: 4.044490337371826px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group857 {
            top: 18.777976989746094px;
            left: 323.3099365234375px;
            width: 7.052804470062256px;
            height: 4.044788360595703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group858 {
            top: 18.724504470825195px;
            left: 323.3099365234375px;
            width: 6.806367874145508px;
            height: 3.8633077144622803px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group859 {
            top: 19.485286712646484px;
            left: 325.7860107421875px;
            width: 2.0995190143585205px;
            height: 1.0803288221359253px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group860 {
            top: 18.300369262695312px;
            left: 325.7924499511719px;
            width: 2.086716890335083px;
            height: 1.2177709341049194px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group861 {
            top: 18.904943466186523px;
            left: 325.7860107421875px;
            width: 2.0995190143585205px;
            height: 1.129451870918274px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group862 {
            top: 20.731334686279297px;
            left: 323.43048095703125px;
            width: 5.53257417678833px;
            height: 1.5803889036178589px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group863 {
            top: 46.77477264404297px;
            left: 73.26448059082031px;
            width: 7.051738262176514px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group864 {
            top: 46.78224182128906px;
            left: 73.26446533203125px;
            width: 6.911386489868164px;
            height: 2.463290214538574px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group865 {
            top: 47.42766571044922px;
            left: 73.38609313964844px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group866 {
            top: 45.61833572387695px;
            left: 73.26448059082031px;
            width: 7.051738262176514px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group867 {
            top: 45.625789642333984px;
            left: 73.26446533203125px;
            width: 6.911386489868164px;
            height: 2.4635086059570312px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group868 {
            top: 46.271236419677734px;
            left: 73.38609313964844px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group869 {
            top: 43.018463134765625px;
            left: 73.26448059082031px;
            width: 7.0538716316223145px;
            height: 4.0447869300842285px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group870 {
            top: 43.017398834228516px;
            left: 73.26448059082031px;
            width: 7.051738262176514px;
            height: 4.044788360595703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group871 {
            top: 42.963924407958984px;
            left: 73.26446533203125px;
            width: 6.80850076675415px;
            height: 3.8640825748443604px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group872 {
            top: 43.72471237182617px;
            left: 75.739501953125px;
            width: 2.1016526222229004px;
            height: 1.0803288221359253px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group873 {
            top: 42.53977966308594px;
            left: 75.74806213378906px;
            width: 2.086716890335083px;
            height: 1.2177709341049194px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group874 {
            top: 43.144351959228516px;
            left: 75.739501953125px;
            width: 2.1016526222229004px;
            height: 1.1288868188858032px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group875 {
            top: 44.970760345458984px;
            left: 73.38609313964844px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group876 {
            top: 25.1789493560791px;
            left: 36.9133415222168px;
            width: 7.051738262176514px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group877 {
            top: 25.18643569946289px;
            left: 36.9133415222168px;
            width: 6.911386489868164px;
            height: 2.4635424613952637px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group878 {
            top: 25.831867218017578px;
            left: 37.03389358520508px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group879 {
            top: 24.022520065307617px;
            left: 36.9133415222168px;
            width: 7.051738262176514px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group880 {
            top: 24.02997589111328px;
            left: 36.9133415222168px;
            width: 6.911386489868164px;
            height: 2.463290214538574px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group881 {
            top: 24.676485061645508px;
            left: 37.03389358520508px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group882 {
            top: 21.421585083007812px;
            left: 36.91227340698242px;
            width: 7.0538716316223145px;
            height: 4.04558801651001px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group883 {
            top: 21.422657012939453px;
            left: 36.9133415222168px;
            width: 7.051738262176514px;
            height: 4.044788360595703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group884 {
            top: 21.368101119995117px;
            left: 36.9133415222168px;
            width: 6.80850076675415px;
            height: 3.8633077144622803px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group885 {
            top: 22.128896713256836px;
            left: 39.390525817871094px;
            width: 2.0995190143585205px;
            height: 1.0803288221359253px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group886 {
            top: 20.94397735595703px;
            left: 39.39693069458008px;
            width: 2.086716890335083px;
            height: 1.2176859378814697px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group887 {
            top: 21.549623489379883px;
            left: 39.39046096801758px;
            width: 2.09958553314209px;
            height: 1.129451870918274px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group888 {
            top: 23.37494659423828px;
            left: 37.03389358520508px;
            width: 5.53257417678833px;
            height: 1.5803889036178589px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group889 {
            top: 4.234980583190918px;
            left: 0.0010666847229003906px;
            width: 7.051738262176514px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group890 {
            top: 4.242450714111328px;
            left: 0px;
            width: 6.911299705505371px;
            height: 2.463290214538574px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group891 {
            top: 4.888930797576904px;
            left: 0.12162184715270996px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group892 {
            top: 3.0785303115844727px;
            left: 0.0010666847229003906px;
            width: 7.051738262176514px;
            height: 2.672288656234741px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group893 {
            top: 3.0860214233398438px;
            left: 0px;
            width: 6.911299705505371px;
            height: 2.4635424613952637px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group894 {
            top: 3.7325010299682617px;
            left: 0.12162184715270996px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group895 {
            top: 0.4786832332611084px;
            left: -9.5367431640625e-7px;
            width: 7.051738262176514px;
            height: 4.044490337371826px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group896 {
            top: 0.4786820411682129px;
            left: 0.0010666847229003906px;
            width: 7.051738262176514px;
            height: 4.044788360595703px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group897 {
            top: 0.4241158962249756px;
            left: 7.152557373046875e-7px;
            width: 6.80850076675415px;
            height: 3.8640825748443604px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group898 {
            top: 1.1849281787872314px;
            left: 2.4771790504455566px;
            width: 2.0995190143585205px;
            height: 1.0804202556610107px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group899 {
            top: 0.000002562999725341797px;
            left: 2.4835801124572754px;
            width: 2.086716890335083px;
            height: 1.2177784442901611px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group900 {
            top: 0.6056336164474487px;
            left: 2.4771103858947754px;
            width: 2.09958553314209px;
            height: 1.1288868188858032px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group901 {
            top: 2.430966854095459px;
            left: 0.12162184715270996px;
            width: 5.53257417678833px;
            height: 1.580246925354004px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group902 {
            top: 306.8363037109375px;
            left: 409.75px;
            width: 25px;
            height: 25px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group903 {
            top: 0px;
            left: 0px;
            width: 25px;
            height: 25px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group904 {
            top: 294.6730651855469px;
            left: 293.7363586425781px;
            width: 13.335359573364258px;
            height: 13.335359573364258px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group905 {
            top: 0.0000019073486328125px;
            left: 0px;
            width: 13.335359573364258px;
            height: 13.335359573364258px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group906 {
            top: 790.38671875px;
            left: 428.86517333984375px;
            width: 74.81136322021484px;
            height: 86.6798324584961px;
            display: flex;
            opacity: 0.5;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group907 {
            top: 0px;
            left: 0px;
            width: 74.81136322021484px;
            height: 86.6798324584961px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group908 {
            top: 0px;
            left: 491.80804443359375px;
            width: 273.3748474121094px;
            height: 397.9270935058594px;
            display: flex;
            opacity: 0.5;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group909 {
            top: 0px;
            left: 0px;
            width: 273.3748474121094px;
            height: 397.9270935058594px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group910 {
            top: 94.94775390625px;
            left: 658.2333374023438px;
            width: 273.3748474121094px;
            height: 397.9270935058594px;
            display: flex;
            opacity: 0.5;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group911 {
            top: 0px;
            left: 0px;
            width: 273.3748474121094px;
            height: 397.9270935058594px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group912 {
            top: 253.68310546875px;
            left: 409.75px;
            width: 25px;
            height: 25px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group913 {
            top: 0px;
            left: 0px;
            width: 25px;
            height: 25px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group914 {
            top: 173.33706665039062px;
            left: 172.78607177734375px;
            width: 7.844328880310059px;
            height: 7.844328880310059px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group915 {
            top: -9.5367431640625e-7px;
            left: 0.00000762939453125px;
            width: 7.844328880310059px;
            height: 7.844328880310059px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector437 {
            top: -4.76837158203125e-7px;
            left: -0.00000476837158203125px;
            width: 8px;
            height: 8px;
            position: absolute;
          }
          .frame1920wlight-group916 {
            top: 464.9333801269531px;
            left: 252.2736053466797px;
            width: 44.006683349609375px;
            height: 50.988136291503906px;
            display: flex;
            opacity: 0.5;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group917 {
            top: 0px;
            left: 0px;
            width: 44.006683349609375px;
            height: 50.988136291503906px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector438 {
            top: -0.000011444091796875px;
            left: 0px;
            width: 44px;
            height: 51px;
            position: absolute;
          }
          .frame1920wlight-group918 {
            top: 0px;
            left: 289.298828125px;
            width: 160.80874633789062px;
            height: 234.07476806640625px;
            display: flex;
            opacity: 0.5;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group919 {
            top: 0px;
            left: 0px;
            width: 160.80874633789062px;
            height: 234.07476806640625px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector439 {
            top: 0px;
            left: 0.0000152587890625px;
            width: 161px;
            height: 234px;
            position: absolute;
          }
          .frame1920wlight-group920 {
            top: 55.85162353515625px;
            left: 387.1960754394531px;
            width: 160.80874633789062px;
            height: 234.07476806640625px;
            display: flex;
            opacity: 0.5;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-group921 {
            top: 0px;
            left: 0px;
            width: 160.80874633789062px;
            height: 234.07476806640625px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 1;
          }
          .frame1920wlight-vector440 {
            top: 0px;
            left: -0.00000762939453125px;
            width: 161px;
            height: 234px;
            position: absolute;
          }
          .frame1920wlight-section2 {
            gap: 24px;
            top: 1219.5px;
            left: 192.57289123535156px;
            width: 1464.015625px;
            height: 1384px;
            display: flex;
            padding: 0 64px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-heading21 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text146 {
            color: rgba(29, 29, 29, 1);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 52px;
          }
          .frame1920wlight-text147 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text148 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
          }
          .frame1920wlight-container118 {
            gap: 117.08000183105469px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-container119 {
            height: 104px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text150 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 26px;
          }
          .frame1920wlight-component14 {
            display: flex;
            padding: 13px 59px 13px 33px;
            position: relative;
            align-items: center;
            border-color: rgba(81, 81, 81, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 8px;
          }
          .frame1920wlight-container120 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text158 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-background18 {
            top: 22px;
            left: 23px;
            width: 10px;
            height: 10px;
            opacity: 0;
            z-index: 1;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-background19 {
            top: 22px;
            left: 231.99998474121094px;
            width: 10px;
            height: 10px;
            z-index: 2;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-list1 {
            width: 1336.015625px;
            height: 1180px;
            display: flex;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
          }
          .frame1920wlight-component41 {
            top: 0px;
            left: 0px;
            width: 618px;
            height: 566px;
            display: flex;
            overflow: hidden;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            border-color: rgba(29, 29, 29, 1);
            border-style: solid;
            border-width: 1px;
          }
          .frame1920wlight-dots1 {
            top: 65px;
            left: 49px;
            width: 280px;
            display: flex;
            overflow: hidden;
            position: absolute;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6596dotssvgfill1 {
            width: 280px;
            height: 254px;
          }
          .frame1920wlight-margin18 {
            top: 39px;
            left: 583px;
            width: 70px;
            height: 94px;
            display: flex;
            padding: 0 0 24px;
            position: absolute;
            align-items: flex-end;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-background20 {
            width: 70px;
            height: 70px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 35px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-container121 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component311 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-imgmargin10 {
            top: 133px;
            left: 232px;
            width: 230px;
            display: flex;
            padding: 0 0 24px;
            position: absolute;
            align-items: center;
            flex-direction: column;
          }
          .frame1920wlight-frame6578a5b54fa1fa278cef668csavemoneyjpg {
            width: 230px;
            height: 230px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
            border-radius: 115px;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-imgmargin11 {
            top: 387px;
            left: 41px;
            width: 48px;
            height: 72px;
            display: flex;
            padding: 24px 0 0;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef65b0savemoneysvg {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-heading3margin2 {
            top: 459px;
            left: 41px;
            width: 296px;
            display: flex;
            padding: 24px 0 0;
            position: absolute;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text159 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 44px;
          }
          .frame1920wlight-background21 {
            top: -563px;
            left: 0.890489935874939px;
            width: 616px;
            height: 564px;
            position: absolute;
          }
          .frame1920wlight-container122 {
            top: 1px;
            left: 0.890489935874939px;
            width: 616px;
            height: 564px;
            display: flex;
            opacity: 0;
            padding: 38px 40px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: space-between;
          }
          .frame1920wlight-margin19 {
            width: 514.0800170898438px;
            display: flex;
            padding: 0 0 16px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container123 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text160 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 25px;
          }
          .frame1920wlight-margin20 {
            display: flex;
            padding: 81px 0 0;
            flex-grow: 1;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
            justify-content: flex-end;
          }
          .frame1920wlight-container124 {
            gap: 24px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-heading32 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text182 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 44px;
          }
          .frame1920wlight-component42 {
            top: 0px;
            left: 718px;
            width: 618px;
            height: 566px;
            display: flex;
            overflow: hidden;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            border-color: rgba(29, 29, 29, 1);
            border-style: solid;
            border-width: 1px;
          }
          .frame1920wlight-dots2 {
            top: 65px;
            left: 49px;
            width: 280px;
            display: flex;
            overflow: hidden;
            position: absolute;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6596dotssvgfill2 {
            width: 280px;
            height: 254px;
          }
          .frame1920wlight-margin21 {
            top: 39px;
            left: 583px;
            width: 70px;
            height: 94px;
            display: flex;
            padding: 0 0 24px;
            position: absolute;
            align-items: flex-end;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-background22 {
            width: 70px;
            height: 70px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 35px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-container125 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component312 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-imgmargin12 {
            top: 133px;
            left: 232px;
            width: 230px;
            display: flex;
            padding: 0 0 24px;
            position: absolute;
            align-items: center;
            flex-direction: column;
          }
          .frame1920wlight-frame6578a5b54fa1fa278cef668eprioritijpg {
            width: 230px;
            height: 230px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
            border-radius: 115px;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-imgmargin13 {
            top: 387px;
            left: 41px;
            width: 48px;
            height: 72px;
            display: flex;
            padding: 24px 0 0;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef65faprioritiiconsvg {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-heading3margin3 {
            top: 459px;
            left: 41px;
            width: 234px;
            display: flex;
            padding: 24px 0 0;
            position: absolute;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text183 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 44px;
          }
          .frame1920wlight-background23 {
            top: -563px;
            left: 0.890489935874939px;
            width: 616px;
            height: 564px;
            position: absolute;
          }
          .frame1920wlight-container126 {
            top: 1px;
            left: 0.890489935874939px;
            width: 616px;
            height: 564px;
            display: flex;
            opacity: 0;
            padding: 38px 40px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: space-between;
          }
          .frame1920wlight-margin22 {
            width: 514.0800170898438px;
            display: flex;
            padding: 0 0 16px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container127 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text184 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 25px;
          }
          .frame1920wlight-margin23 {
            display: flex;
            padding: 106px 0 0;
            flex-grow: 1;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
            justify-content: flex-end;
          }
          .frame1920wlight-container128 {
            gap: 24px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-heading33 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text204 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 44px;
          }
          .frame1920wlight-component43 {
            top: 590px;
            left: 0px;
            width: 618px;
            height: 566px;
            display: flex;
            overflow: hidden;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            border-color: rgba(29, 29, 29, 1);
            border-style: solid;
            border-width: 1px;
          }
          .frame1920wlight-dots3 {
            top: 65px;
            left: 49px;
            width: 280px;
            display: flex;
            overflow: hidden;
            position: absolute;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6596dotssvgfill3 {
            width: 280px;
            height: 254px;
          }
          .frame1920wlight-margin24 {
            top: 39px;
            left: 583px;
            width: 70px;
            height: 94px;
            display: flex;
            padding: 0 0 24px;
            position: absolute;
            align-items: flex-end;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-background24 {
            width: 70px;
            height: 70px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 35px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-container129 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component313 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-imgmargin14 {
            top: 133px;
            left: 232px;
            width: 230px;
            display: flex;
            padding: 0 0 24px;
            position: absolute;
            align-items: center;
            flex-direction: column;
          }
          .frame1920wlight-frame6578a5b54fa1fa278cef668dquickjpg {
            width: 230px;
            height: 230px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
            border-radius: 115px;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-imgmargin15 {
            top: 387px;
            left: 41px;
            width: 48px;
            height: 72px;
            display: flex;
            padding: 24px 0 0;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef65c8quickiconsvg {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-heading3margin4 {
            top: 459px;
            left: 41px;
            width: 452px;
            display: flex;
            padding: 24px 0 0;
            position: absolute;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text205 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 44px;
          }
          .frame1920wlight-background25 {
            top: -563px;
            left: 0.890489935874939px;
            width: 616px;
            height: 564px;
            position: absolute;
          }
          .frame1920wlight-container130 {
            top: 1px;
            left: 0.890489935874939px;
            width: 616px;
            height: 564px;
            display: flex;
            opacity: 0;
            padding: 38px 40px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: space-between;
          }
          .frame1920wlight-margin25 {
            width: 514.0800170898438px;
            display: flex;
            padding: 0 0 16px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container131 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text206 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 25px;
          }
          .frame1920wlight-margin26 {
            display: flex;
            padding: 131px 0 0;
            flex-grow: 1;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
            justify-content: flex-end;
          }
          .frame1920wlight-container132 {
            gap: 24px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-heading34 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text224 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 44px;
          }
          .frame1920wlight-component44 {
            top: 590px;
            left: 718px;
            width: 618px;
            height: 566px;
            display: flex;
            overflow: hidden;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            border-color: rgba(29, 29, 29, 1);
            border-style: solid;
            border-width: 1px;
          }
          .frame1920wlight-dots4 {
            top: 65px;
            left: 49px;
            width: 280px;
            display: flex;
            overflow: hidden;
            position: absolute;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6596dotssvgfill4 {
            width: 280px;
            height: 254px;
          }
          .frame1920wlight-margin27 {
            top: 39px;
            left: 583px;
            width: 70px;
            height: 94px;
            display: flex;
            padding: 0 0 24px;
            position: absolute;
            align-items: flex-end;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-background26 {
            width: 70px;
            height: 70px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 35px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-container133 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component314 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-imgmargin16 {
            top: 133px;
            left: 232px;
            width: 230px;
            display: flex;
            padding: 0 0 24px;
            position: absolute;
            align-items: center;
            flex-direction: column;
          }
          .frame1920wlight-frame6578a5b54fa1fa278cef668fsuitablejpg {
            width: 230px;
            height: 230px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
            border-radius: 115px;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-imgmargin17 {
            top: 387px;
            left: 41px;
            width: 48px;
            height: 72px;
            display: flex;
            padding: 24px 0 0;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6613suitableiconsvg {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-heading3margin5 {
            top: 459px;
            left: 41px;
            width: 566px;
            display: flex;
            padding: 24px 0 0;
            position: absolute;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text225 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 44px;
          }
          .frame1920wlight-background27 {
            top: -563px;
            left: 0.890489935874939px;
            width: 616px;
            height: 564px;
            position: absolute;
          }
          .frame1920wlight-container134 {
            top: 1px;
            left: 0.890489935874939px;
            width: 616px;
            height: 564px;
            display: flex;
            opacity: 0;
            padding: 38px 40px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: space-between;
          }
          .frame1920wlight-margin28 {
            width: 514.0800170898438px;
            display: flex;
            padding: 0 0 16px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container135 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text226 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 25px;
          }
          .frame1920wlight-margin29 {
            display: flex;
            padding: 106px 0 0;
            flex-grow: 1;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
            justify-content: flex-end;
          }
          .frame1920wlight-container136 {
            gap: 24px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-heading35 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text246 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 44px;
          }
          .frame1920wlight-header {
            gap: 48px;
            top: 2763.5px;
            left: 257.4396057128906px;
            width: 1431.120849609375px;
            height: 660px;
            display: flex;
            padding: 80px 58px;
            position: absolute;
            align-items: center;
            flex-shrink: 0;
            border-radius: 20px;
            justify-content: space-between;
            background-color: var(--dl-color-www.bohmenergy.nl-porcelain);
          }
          .frame1920wlight-container137 {
            width: 624px;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-heading2margin1 {
            display: flex;
            padding: 0 0 16px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-heading22 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text247 {
            color: rgba(29, 29, 29, 1);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 50px;
          }
          .frame1920wlight-text248 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text250 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-margin30 {
            display: flex;
            padding: 0 0 16px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container138 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text252 {
            color: rgba(29, 29, 29, 1);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-text253 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text255 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text256 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
          }
          .frame1920wlight-frame65a7c9b1a11c27f5d9d7012cd3a55b7c89954fba9ee1a {
            width: 167px;
            height: 73.13999938964844px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-component15 {
            display: flex;
            padding: 13px 59px 13px 33px;
            position: relative;
            align-items: center;
            border-color: rgba(81, 81, 81, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 8px;
          }
          .frame1920wlight-container139 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text259 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-background28 {
            top: 22px;
            left: 23px;
            width: 10px;
            height: 10px;
            opacity: 0;
            z-index: 1;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-background29 {
            top: 22px;
            left: 131px;
            width: 10px;
            height: 10px;
            z-index: 2;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-container140 {
            width: 624px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 20px;
            justify-content: center;
          }
          .frame1920wlight-frame68344e1e7547a210b1268d7e-jan-tafelpng {
            width: 500px;
            height: 500px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            border-radius: 20px;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-section3 {
            gap: 76px;
            top: 3583.5px;
            left: 0px;
            width: 1946px;
            height: 1061px;
            display: flex;
            position: absolute;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container141 {
            gap: 16px;
            width: 1540px;
            display: flex;
            padding: 0 64px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-heading23 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text260 {
            color: rgba(29, 29, 29, 1);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 52px;
          }
          .frame1920wlight-text261 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text262 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
          }
          .frame1920wlight-container142 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text265 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-list2 {
            display: flex;
            padding: 1px 0 0;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(0, 0, 0, 0.20000000298023224);
            border-style: solid;
            border-width: 1px 0 0;
            flex-direction: column;
          }
          .frame1920wlight-listitem10 {
            display: flex;
            padding: 48px 254px 49px;
            overflow: hidden;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(240, 245, 245, 1);
            border-style: solid;
            border-width: 0 0 1px;
            flex-direction: column;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container143 {
            display: flex;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container144 {
            display: flex;
            padding: 0 183.5469970703125px;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
            justify-content: space-between;
          }
          .frame1920wlight-imgmargin18 {
            width: 48px;
            height: 72px;
            display: flex;
            padding: 0 0 24px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6680perform1svg {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-text266 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            z-index: 1;
            text-align: left;
            line-height: 40px;
          }
          .frame1920wlight-background30 {
            width: 70px;
            height: 70px;
            display: flex;
            z-index: 2;
            align-items: center;
            flex-shrink: 0;
            border-radius: 35px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-container145 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component315 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-container146 {
            gap: -1.0658141036401503e-14px;
            width: 20.89784812927246px;
            height: 28px;
            display: flex;
            z-index: 1;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-container147 {
            height: 28px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container148 {
            height: 28px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-listitem11 {
            display: flex;
            padding: 48px 254px 49px;
            overflow: hidden;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(240, 245, 245, 1);
            border-style: solid;
            border-width: 0 0 1px;
            flex-direction: column;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container149 {
            display: flex;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container150 {
            display: flex;
            padding: 0 183.5469970703125px;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
            justify-content: space-between;
          }
          .frame1920wlight-imgmargin19 {
            width: 48px;
            height: 72px;
            display: flex;
            padding: 0 0 24px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6681perform2svg {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-text267 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            z-index: 1;
            text-align: left;
            line-height: 40px;
          }
          .frame1920wlight-background31 {
            width: 70px;
            height: 70px;
            display: flex;
            z-index: 2;
            align-items: center;
            flex-shrink: 0;
            border-radius: 35px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-container151 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component316 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-container152 {
            gap: -1.0658141036401503e-14px;
            width: 25.012237548828125px;
            height: 28px;
            display: flex;
            z-index: 1;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-container153 {
            height: 28px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container154 {
            height: 28px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-listitem12 {
            display: flex;
            padding: 48px 254px 49px;
            overflow: hidden;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(240, 245, 245, 1);
            border-style: solid;
            border-width: 0 0 1px;
            flex-direction: column;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container155 {
            display: flex;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container156 {
            display: flex;
            padding: 0 183.5469970703125px;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
            justify-content: space-between;
          }
          .frame1920wlight-imgmargin20 {
            width: 48px;
            height: 72px;
            display: flex;
            padding: 0 0 24px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6682perform3svg {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-text268 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            z-index: 1;
            text-align: left;
            line-height: 40px;
          }
          .frame1920wlight-background32 {
            width: 70px;
            height: 70px;
            display: flex;
            z-index: 2;
            align-items: center;
            flex-shrink: 0;
            border-radius: 35px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-container157 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component317 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-container158 {
            gap: -1.0658141036401503e-14px;
            width: 24.90021324157715px;
            height: 28px;
            display: flex;
            z-index: 1;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-container159 {
            height: 28px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container160 {
            height: 28px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-listitem13 {
            display: flex;
            padding: 48px 254px 49px;
            overflow: hidden;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(240, 245, 245, 1);
            border-style: solid;
            border-width: 0 0 1px;
            flex-direction: column;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container161 {
            display: flex;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container162 {
            display: flex;
            padding: 0 183.5469970703125px;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
            justify-content: space-between;
          }
          .frame1920wlight-imgmargin21 {
            width: 48px;
            height: 72px;
            display: flex;
            padding: 0 0 24px;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6683perform4svg {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-text269 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            z-index: 1;
            text-align: left;
            line-height: 40px;
          }
          .frame1920wlight-background33 {
            width: 70px;
            height: 70px;
            display: flex;
            z-index: 2;
            align-items: center;
            flex-shrink: 0;
            border-radius: 35px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-container163 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component318 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-container164 {
            gap: -1.0658141036401503e-14px;
            width: 26.17323112487793px;
            height: 28px;
            display: flex;
            z-index: 1;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-container165 {
            height: 28px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container166 {
            height: 28px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-section4 {
            top: 4804.5px;
            left: 257.4396057128906px;
            width: 1431.120849609375px;
            height: 539px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-margin31 {
            display: flex;
            padding: 0 0 48px;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-horizontal-border1 {
            gap: 223.5800018310547px;
            display: flex;
            padding: 0 0 65px;
            align-items: flex-start;
            border-color: rgba(226, 226, 226, 1);
            border-style: solid;
            border-width: 0 0 1px;
            justify-content: space-between;
          }
          .frame1920wlight-container167 {
            display: flex;
            padding: 0 0 24px;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text270 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 50px;
          }
          .frame1920wlight-container168 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-margin32 {
            display: flex;
            padding: 0 0 24px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container169 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text271 {
            color: rgba(29, 29, 29, 1);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-text272 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text274 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text276 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
          }
          .frame1920wlight-text277 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text279 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text280 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
          }
          .frame1920wlight-text281 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text283 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text284 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
          }
          .frame1920wlight-text285 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text287 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
          }
          .frame1920wlight-text288 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
          }
          .frame1920wlight-component16 {
            display: flex;
            padding: 13px 59px 13px 33px;
            position: relative;
            align-items: center;
            border-color: rgba(81, 81, 81, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 8px;
          }
          .frame1920wlight-container170 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text290 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-background34 {
            top: 22px;
            left: 23px;
            width: 10px;
            height: 10px;
            opacity: 0;
            z-index: 1;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-background35 {
            top: 22px;
            left: 131px;
            width: 10px;
            height: 10px;
            z-index: 2;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-container171 {
            gap: 48px;
            display: flex;
            align-items: flex-start;
          }
          .frame1920wlight-container172 {
            gap: 16px;
            display: flex;
            padding: 0 88.7699966430664px 0 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-icon1 {
            width: 48px;
            height: 48px;
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6589abouticon1svgfill {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-text291 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 60px;
          }
          .frame1920wlight-text292 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-container173 {
            gap: 16px;
            display: flex;
            padding: 0 75.37000274658203px 0 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-icon2 {
            width: 48px;
            height: 48px;
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6588abouticon2svgfill {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-text296 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 60px;
          }
          .frame1920wlight-text297 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-container174 {
            gap: 16px;
            display: flex;
            padding: 0 152.69000244140625px 0 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-icon3 {
            width: 48px;
            height: 48px;
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef658cabouticon3svgfill {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-text298 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 60px;
          }
          .frame1920wlight-text299 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-container175 {
            gap: 16px;
            display: flex;
            padding: 0 123.36000061035156px 0 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-icon4 {
            width: 48px;
            height: 48px;
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef658babouticon4svgfill {
            width: 48px;
            height: 48px;
          }
          .frame1920wlight-text303 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-section68b5675cfb4f82f39162bb31hero2png {
            top: 5497.18115234375px;
            left: 6.5218634605407715px;
            width: 1932.9564208984375px;
            height: 1288.6375732421875px;
            display: flex;
            overflow: hidden;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-section5 {
            top: 6781.5px;
            left: 0px;
            width: 1946px;
            height: 470px;
            display: flex;
            padding: 80px 190px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            background-color: var(--dl-color-www.bohmenergy.nl-porcelain);
          }
          .frame1920wlight-container176 {
            gap: 48px;
            display: flex;
            padding: 0 64px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-heading24 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text304 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 50px;
          }
          .frame1920wlight-container177 {
            gap: 64px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            justify-content: center;
          }
          .frame1920wlight-container178 {
            height: 212px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-margin33 {
            display: flex;
            padding: 0 0 24px;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container179 {
            gap: 4px;
            display: flex;
            align-items: flex-start;
          }
          .frame1920wlight-container180 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container181 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component319 {
            width: 20px;
            height: 19px;
            align-self: stretch;
          }
          .frame1920wlight-container182 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container183 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component320 {
            width: 20px;
            height: 19px;
            align-self: stretch;
          }
          .frame1920wlight-container184 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container185 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component321 {
            width: 20px;
            height: 19px;
            align-self: stretch;
          }
          .frame1920wlight-container186 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container187 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component322 {
            width: 20px;
            height: 19px;
            align-self: stretch;
          }
          .frame1920wlight-rectangle5 {
            width: 20px;
            height: 20px;
          }
          .frame1920wlight-container188 {
            display: flex;
            padding: 0 14.859999656677246px 0 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text305 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-margin34 {
            display: flex;
            padding: 32px 0 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container189 {
            display: flex;
            align-items: center;
          }
          .frame1920wlight-margin35 {
            display: flex;
            padding: 0 20px 0 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-img2 {
            width: 56px;
            height: 56px;
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-shrink: 0;
            border-radius: 28px;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef658ffaviconsvgfill1 {
            width: 56px;
            height: 56px;
          }
          .frame1920wlight-container190 {
            gap: 4px;
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container191 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text311 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-container192 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text312 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-container193 {
            height: 212px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-margin36 {
            display: flex;
            padding: 0 0 24px;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container194 {
            gap: 4px;
            display: flex;
            align-items: flex-start;
          }
          .frame1920wlight-container195 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container196 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component323 {
            width: 20px;
            height: 19px;
            align-self: stretch;
          }
          .frame1920wlight-container197 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container198 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component324 {
            width: 20px;
            height: 19px;
            align-self: stretch;
          }
          .frame1920wlight-container199 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container200 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component325 {
            width: 20px;
            height: 19px;
            align-self: stretch;
          }
          .frame1920wlight-container201 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container202 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component326 {
            width: 20px;
            height: 19px;
            align-self: stretch;
          }
          .frame1920wlight-container203 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container204 {
            width: 20px;
            height: 20px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component327 {
            width: 20px;
            height: 19px;
            align-self: stretch;
          }
          .frame1920wlight-container205 {
            display: flex;
            padding: 0 4.03000020980835px 0 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text313 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-margin37 {
            display: flex;
            padding: 32px 0 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container206 {
            display: flex;
            align-items: center;
          }
          .frame1920wlight-margin38 {
            display: flex;
            padding: 0 20px 0 0;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-img3 {
            width: 56px;
            height: 56px;
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-shrink: 0;
            border-radius: 28px;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef658ffaviconsvgfill2 {
            width: 56px;
            height: 56px;
          }
          .frame1920wlight-container207 {
            gap: 4px;
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container208 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text321 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-container209 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text322 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-section6 {
            gap: 80px;
            top: 7411.5px;
            left: 257.4396057128906px;
            width: 1431.120849609375px;
            height: 1169px;
            display: flex;
            padding: 100px 58px 112px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            border-radius: 20px;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-container210 {
            gap: 653px;
            height: 957px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: space-between;
          }
          .frame1920wlight-container211 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-heading2margin2 {
            display: flex;
            padding: 0 0 16px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-heading25 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text323 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 50px;
          }
          .frame1920wlight-container212 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text324 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 26px;
          }
          .frame1920wlight-container213 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-margin39 {
            display: flex;
            padding: 0 0 18px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container214 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text332 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-linkmargin11 {
            display: flex;
            padding: 6px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component212 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text336 {
            color: var(--dl-color-www.bohmenergy.nl-aeroblue);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-linkmargin12 {
            display: flex;
            padding: 6px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component213 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text337 {
            color: var(--dl-color-www.bohmenergy.nl-aeroblue);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-container215 {
            height: 957px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-list3 {
            gap: 16px;
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-listitem14 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container216 {
            gap: 52.83000183105469px;
            display: flex;
            padding: 23px 16px;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-container217 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text338 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-background36 {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 30px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container218 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component328 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-horizontal-border2 {
            width: 645.77001953125px;
            height: 17px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(255, 255, 255, 0.4000000059604645);
            border-style: solid;
            border-width: 0 0 1px;
          }
          .frame1920wlight-container219 {
            top: 16px;
            left: 16px;
            width: 614px;
            display: flex;
            padding: 0 0 72.5px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text339 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-listitem15 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container220 {
            gap: 45.58000183105469px;
            display: flex;
            padding: 23px 16px;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-container221 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text340 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-background37 {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 30px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container222 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component329 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-horizontal-border3 {
            width: 645.77001953125px;
            height: 17px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(255, 255, 255, 0.4000000059604645);
            border-style: solid;
            border-width: 0 0 1px;
          }
          .frame1920wlight-container223 {
            top: 16px;
            left: 16px;
            width: 614px;
            display: flex;
            padding: 0 0 96.5px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text341 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-listitem16 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container224 {
            gap: 137.60000610351562px;
            display: flex;
            padding: 23px 16px;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-container225 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text342 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-background38 {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 30px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container226 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component330 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-horizontal-border4 {
            width: 645.77001953125px;
            height: 17px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(255, 255, 255, 0.4000000059604645);
            border-style: solid;
            border-width: 0 0 1px;
          }
          .frame1920wlight-container227 {
            top: 16px;
            left: 16px;
            width: 614px;
            display: flex;
            padding: 0 0 72.5px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text343 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-listitem17 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container228 {
            gap: 259.9100036621094px;
            display: flex;
            padding: 23px 16px;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-container229 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text344 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-background39 {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 30px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container230 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component331 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-horizontal-border5 {
            width: 645.77001953125px;
            height: 17px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(255, 255, 255, 0.4000000059604645);
            border-style: solid;
            border-width: 0 0 1px;
          }
          .frame1920wlight-container231 {
            top: 16px;
            left: 16px;
            width: 614px;
            display: flex;
            padding: 0 0 96.5px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text345 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-listitem18 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container232 {
            gap: 96.5199966430664px;
            display: flex;
            padding: 23px 16px;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-container233 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text346 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-background40 {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 30px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container234 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component332 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-horizontal-border6 {
            width: 645.77001953125px;
            height: 17px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(255, 255, 255, 0.4000000059604645);
            border-style: solid;
            border-width: 0 0 1px;
          }
          .frame1920wlight-container235 {
            top: 16px;
            left: 16px;
            width: 614px;
            display: flex;
            padding: 0 0 24.5px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text347 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-listitem19 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container236 {
            gap: 233.49000549316406px;
            display: flex;
            padding: 23px 16px;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-container237 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text348 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-background41 {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 30px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container238 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component333 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-horizontal-border7 {
            width: 645.77001953125px;
            height: 17px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(255, 255, 255, 0.4000000059604645);
            border-style: solid;
            border-width: 0 0 1px;
          }
          .frame1920wlight-container239 {
            top: 16px;
            left: 16px;
            width: 614px;
            display: flex;
            padding: 0 0 96.5px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text349 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-listitem20 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container240 {
            gap: 290.1099853515625px;
            display: flex;
            padding: 23px 16px;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-container241 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text350 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-background42 {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 30px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container242 {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component334 {
            width: 32px;
            height: 32px;
            flex-grow: 1;
            align-self: stretch;
          }
          .frame1920wlight-horizontal-border8 {
            width: 645.77001953125px;
            height: 17px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(255, 255, 255, 0.4000000059604645);
            border-style: solid;
            border-width: 0 0 1px;
          }
          .frame1920wlight-container243 {
            top: 16px;
            left: 16px;
            width: 614px;
            display: flex;
            padding: 0 0 72.5px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text351 {
            color: var(--dl-color-www.bohmenergy.nl-white);
            height: auto;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-section7 {
            top: 8740.5px;
            left: 0px;
            width: 1946px;
            height: 674px;
            display: flex;
            padding: 0 254px;
            overflow: hidden;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container244 {
            gap: 48px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container245 {
            gap: 24px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-heading26 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text352 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 50px;
          }
          .frame1920wlight-link1 {
            gap: -1.1368683772161603e-13px;
            width: 1059px;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-text353 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-imgarrowmargin {
            display: flex;
            padding: 0 0 0 24px;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-arrow1 {
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6595arrowsvgfill {
            width: 20px;
            height: 20px;
          }
          .frame1920wlight-container246 {
            display: flex;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-list4 {
            width: 1438px;
            height: 524px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
          }
          .frame1920wlight-group16margin {
            top: 0px;
            left: 0px;
            width: 479px;
            height: 492px;
            display: flex;
            padding: 0 24px 0 0;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component51 {
            width: 454.6600036621094px;
            display: flex;
            overflow: hidden;
            flex-grow: 1;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            background-color: rgba(240, 245, 245, 1);
          }
          .frame1920wlight-link2 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-frame68b55fa3dd267b9137d47455-blog20-energyzerojpg {
            width: 454.6600036621094px;
            height: 260px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-container247 {
            gap: 15px;
            display: flex;
            padding: 22px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container248 {
            gap: 265.3599853515625px;
            display: flex;
            padding: 0 5.6843418860808015e-14px 0 0;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-border1 {
            display: flex;
            padding: 15px 21px;
            align-items: center;
            border-color: rgba(29, 29, 29, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 100px;
            justify-content: center;
          }
          .frame1920wlight-text354 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: center;
            line-height: 24px;
          }
          .frame1920wlight-background43 {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 30px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-arrow2 {
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6594arrowwhitesvgfill1 {
            width: 14px;
            height: 14px;
          }
          .frame1920wlight-heading36 {
            display: flex;
            padding: 0 0 14px;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(0, 0, 0, 0.20000000298023224);
            border-style: solid;
            border-width: 0 0 1px;
            flex-direction: column;
          }
          .frame1920wlight-text355 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-container249 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-margin40 {
            height: 20px;
            display: flex;
            padding: 0 4px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container250 {
            height: 20px;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container251 {
            height: 20px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text359 {
            color: var(--dl-color-www.bohmenergy.nl-greenpea);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-margin41 {
            display: flex;
            padding: 0 0 0 217.0780029296875px;
            flex-grow: 1;
            align-self: stretch;
            align-items: flex-end;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container252 {
            height: 20px;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text360 {
            color: var(--dl-color-www.bohmenergy.nl-greenpea);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-group26margin {
            top: 0px;
            left: 478.6600036621094px;
            width: 479px;
            height: 524px;
            display: flex;
            padding: 0 24px 0 0;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component52 {
            width: 454.6600036621094px;
            display: flex;
            overflow: hidden;
            flex-grow: 1;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            background-color: rgba(240, 245, 245, 1);
          }
          .frame1920wlight-link3 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-frame688c8042c3acc2154186af34-post5-webpng {
            width: 454.6600036621094px;
            height: 260px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-container253 {
            gap: 15px;
            display: flex;
            padding: 22px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container254 {
            gap: 272.82000732421875px;
            display: flex;
            padding: 0 0.009999999776482582px 0 0;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-border2 {
            display: flex;
            padding: 15px 21px;
            align-items: center;
            border-color: rgba(29, 29, 29, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 100px;
            justify-content: center;
          }
          .frame1920wlight-text361 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: center;
            line-height: 24px;
          }
          .frame1920wlight-background44 {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 30px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-arrow3 {
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6594arrowwhitesvgfill2 {
            width: 14px;
            height: 14px;
          }
          .frame1920wlight-heading37 {
            display: flex;
            padding: 0 0 14px;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(0, 0, 0, 0.20000000298023224);
            border-style: solid;
            border-width: 0 0 1px;
            flex-direction: column;
          }
          .frame1920wlight-text362 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-container255 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-margin42 {
            height: 20px;
            display: flex;
            padding: 0 4px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container256 {
            height: 20px;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container257 {
            height: 20px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text368 {
            color: var(--dl-color-www.bohmenergy.nl-greenpea);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-margin43 {
            display: flex;
            padding: 0 0 0 246.23399353027344px;
            flex-grow: 1;
            align-self: stretch;
            align-items: flex-end;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container258 {
            height: 20px;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text369 {
            color: var(--dl-color-www.bohmenergy.nl-greenpea);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-group36margin {
            top: 0px;
            left: 957.3099975585938px;
            width: 479px;
            height: 524px;
            display: flex;
            padding: 0 24px 0 0;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-component53 {
            width: 454.6600036621094px;
            display: flex;
            overflow: hidden;
            flex-grow: 1;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            background-color: rgba(240, 245, 245, 1);
          }
          .frame1920wlight-link4 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-frame684959d8f6912a16fea52114-blog20-onbalanshandele {
            width: 454.6600036621094px;
            height: 260px;
            display: flex;
            overflow: hidden;
            position: relative;
            align-self: stretch;
            align-items: flex-start;
            background-size: cover;
            background-image: url('https://play.teleporthq.io/static/svg/default-img.svg');
          }
          .frame1920wlight-container259 {
            gap: 15px;
            display: flex;
            padding: 22px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container260 {
            gap: 272.8299865722656px;
            display: flex;
            align-self: stretch;
            align-items: center;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-border3 {
            display: flex;
            padding: 15px 21px;
            align-items: center;
            border-color: rgba(29, 29, 29, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 100px;
            justify-content: center;
          }
          .frame1920wlight-text370 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: center;
            line-height: 24px;
          }
          .frame1920wlight-background45 {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            flex-shrink: 0;
            border-radius: 30px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-greenpea);
          }
          .frame1920wlight-arrow4 {
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6594arrowwhitesvgfill3 {
            width: 14px;
            height: 14px;
          }
          .frame1920wlight-heading38 {
            display: flex;
            padding: 0 0 14px;
            align-self: stretch;
            align-items: flex-start;
            border-color: rgba(0, 0, 0, 0.20000000298023224);
            border-style: solid;
            border-width: 0 0 1px;
            flex-direction: column;
          }
          .frame1920wlight-text371 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-container261 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-margin44 {
            height: 20px;
            display: flex;
            padding: 0 4px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container262 {
            height: 20px;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-container263 {
            height: 20px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text377 {
            color: var(--dl-color-www.bohmenergy.nl-greenpea);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-margin45 {
            display: flex;
            padding: 0 0 0 268px;
            flex-grow: 1;
            align-self: stretch;
            align-items: flex-end;
            flex-direction: column;
            justify-content: center;
          }
          .frame1920wlight-container264 {
            height: 20px;
            display: flex;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text378 {
            color: var(--dl-color-www.bohmenergy.nl-greenpea);
            height: auto;
            text-align: left;
            line-height: 20px;
          }
          .frame1920wlight-group46margin {
            top: 0px;
            left: 1435.969970703125px;
            width: 479px;
            height: 492px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-group56margin {
            top: 0px;
            left: 1914.6300048828125px;
            width: 479px;
            height: 492px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-group66margin {
            top: 0px;
            left: 2393.280029296875px;
            width: 479px;
            height: 524px;
            display: flex;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-container265 {
            width: 1438px;
            height: 70px;
            display: flex;
            z-index: 1;
            align-items: flex-start;
            flex-shrink: 0;
            justify-content: flex-end;
          }
          .frame1920wlight-button-previousslidemargin {
            width: 90px;
            height: 70px;
            display: flex;
            padding: 0 20px 0 0;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-button-previousslide {
            width: 70px;
            height: 70px;
            display: flex;
            opacity: 0.4;
            padding: 1px;
            align-items: center;
            flex-shrink: 0;
            border-color: rgba(81, 81, 81, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 35px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-white80);
          }
          .frame1920wlight-arrow5 {
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef65a3arrowrightsvgfill1 {
            width: 20px;
            height: 20px;
          }
          .frame1920wlight-button-nextslide {
            width: 70px;
            height: 70px;
            display: flex;
            padding: 1px;
            align-items: center;
            flex-shrink: 0;
            border-color: rgba(81, 81, 81, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 35px;
            justify-content: center;
            background-color: var(--dl-color-www.bohmenergy.nl-white80);
          }
          .frame1920wlight-arrow6 {
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef65a3arrowrightsvgfill2 {
            width: 20px;
            height: 20px;
          }
          .frame1920wlight-footer {
            top: 10274.5px;
            left: 0px;
            width: 1946px;
            height: 401px;
            display: flex;
            padding: 40px 190px 24px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
            background-color: var(--dl-color-www.bohmenergy.nl-white);
          }
          .frame1920wlight-container266 {
            gap: 64px;
            display: flex;
            padding: 0 64px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-horizontal-border9 {
            gap: 234.89999389648438px;
            display: flex;
            padding: 49px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            border-color: rgba(0, 0, 0, 0.20000000298023224);
            border-style: solid;
            border-width: 1px 0 0;
            justify-content: space-between;
          }
          .frame1920wlight-container267 {
            height: 206px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-linkmargin13 {
            display: flex;
            padding: 0 0 92px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-link5 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-logo2 {
            display: flex;
            overflow: hidden;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef6591footerlogosvgfill2 {
            width: 167px;
            height: 28px;
          }
          .frame1920wlight-linkmargin14 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component214 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text379 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-linkmargin15 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component215 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text380 {
            color: var(--dl-color-www.bohmenergy.nl-jade);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-container268 {
            height: 206px;
            display: flex;
            padding: 120.5px 0 5.5px;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text381 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            text-align: left;
            line-height: 40px;
          }
          .frame1920wlight-container269 {
            gap: 24px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
          }
          .frame1920wlight-container270 {
            height: 206px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-margin46 {
            display: flex;
            padding: 0 0 12px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container271 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text385 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-linkmargin16 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component216 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text386 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-linkmargin17 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component217 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text387 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-linkmargin18 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component218 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text388 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-linkmargin19 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component219 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text389 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-linkmargin20 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component220 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text390 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-container272 {
            height: 206px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-margin47 {
            display: flex;
            padding: 0 0 12px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container273 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text391 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-linkmargin21 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component221 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text392 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-linkmargin22 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component222 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text393 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-linkmargin23 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component223 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text394 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-container274 {
            height: 206px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-margin48 {
            display: flex;
            padding: 0 0 12px;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-container275 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text395 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 24px;
          }
          .frame1920wlight-linkmargin24 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component224 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text396 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-linkmargin25 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component225 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text397 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-linkmargin26 {
            display: flex;
            padding: 12px 0 0;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-component226 {
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text398 {
            color: var(--dl-color-www.bohmenergy.nl-emperor);
            height: auto;
            align-self: stretch;
            text-align: left;
            line-height: 22px;
          }
          .frame1920wlight-container276 {
            gap: 1053.1300048828125px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            justify-content: space-between;
          }
          .frame1920wlight-container277 {
            height: 18px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-text399 {
            color: var(--dl-color-www.bohmenergy.nl-gray);
            height: auto;
            text-align: left;
            line-height: 18px;
          }
          .frame1920wlight-container278 {
            gap: 4.263256414560601e-14px;
            display: flex;
            align-self: stretch;
            align-items: flex-start;
          }
          .frame1920wlight-text400 {
            color: var(--dl-color-www.bohmenergy.nl-gray);
            height: auto;
            text-align: left;
            line-height: 18px;
          }
          .frame1920wlight-component227 {
            display: flex;
            align-items: flex-start;
          }
          .frame1920wlight-text401 {
            color: var(--dl-color-www.bohmenergy.nl-gray);
            height: auto;
            text-align: left;
            line-height: 18px;
          }
          .frame1920wlight-container279 {
            top: 1044.5px;
            left: 0px;
            width: 1946px;
            height: 120px;
            display: flex;
            padding: 0 190px;
            position: absolute;
            align-items: flex-start;
            flex-shrink: 0;
            justify-content: center;
          }
          .frame1920wlight-container280 {
            height: 120px;
            display: flex;
            padding: 0 64px;
            align-self: stretch;
            align-items: flex-start;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-background-border {
            width: 1412px;
            height: 120px;
            display: flex;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
            border-color: rgba(81, 81, 81, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 12px;
            background-color: var(--dl-color-www.bohmenergy.nl-porcelain);
          }
          .frame1920wlight-container281 {
            gap: 14px;
            top: 11px;
            left: 25px;
            width: 1043px;
            display: flex;
            padding: 0 396.4700012207031px 16px 0;
            position: absolute;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text402 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 32px;
          }
          .frame1920wlight-container282 {
            width: 646.8400268554688px;
            height: 36px;
            display: flex;
            position: relative;
            align-items: flex-start;
            flex-shrink: 0;
          }
          .frame1920wlight-text403 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            width: 620px;
            height: auto;
            position: absolute;
            text-align: left;
            line-height: 18px;
          }
          .frame1920wlight-component228 {
            top: 18px;
            left: 332.0199890136719px;
            width: 89px;
            display: flex;
            position: absolute;
            align-items: flex-start;
          }
          .frame1920wlight-text407 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 18px;
          }
          .frame1920wlight-container283 {
            top: 48px;
            left: 1363px;
            width: 24px;
            height: 24px;
            display: flex;
            position: absolute;
            align-items: center;
            flex-shrink: 0;
            justify-content: center;
          }
          .frame1920wlight-svg6578a5b54fa1fa278cef65a6closecookiesvg {
            width: 24px;
            height: 24px;
          }
          .frame1920wlight-buttonmargin {
            top: 33px;
            left: 1068.3118896484375px;
            width: 295px;
            display: flex;
            padding: 0 24px 0 92.0781021118164px;
            position: absolute;
            align-items: flex-end;
            flex-shrink: 0;
            flex-direction: column;
          }
          .frame1920wlight-component17 {
            display: flex;
            padding: 13px 59px 13px 33px;
            position: relative;
            align-items: center;
            border-color: rgba(81, 81, 81, 1);
            border-style: solid;
            border-width: 1px;
            border-radius: 8px;
            background-color: rgba(255, 255, 255, 1);
          }
          .frame1920wlight-container284 {
            display: flex;
            align-items: flex-start;
            flex-direction: column;
          }
          .frame1920wlight-text408 {
            color: var(--dl-color-www.bohmenergy.nl-codgray);
            height: auto;
            text-align: left;
            line-height: 28px;
          }
          .frame1920wlight-background46 {
            top: 22px;
            left: 23px;
            width: 10px;
            height: 10px;
            opacity: 0;
            z-index: 1;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-background47 {
            top: 22px;
            left: 131px;
            width: 10px;
            height: 10px;
            z-index: 2;
            position: absolute;
            border-radius: 5px;
          }
          .frame1920wlight-link6 {
            display: contents;
          }
          .frame1920wlight-container285 {
            right: 50px;
            border: 1px solid #ffffff5c;
            bottom: 30px;
            display: flex;
            z-index: 22;
            position: fixed;
            box-shadow: 5px 5px 10px 0px rgba(31, 31, 31, 0.4);
            min-height: auto;
            align-items: center;
            padding-top: 8px;
            padding-left: 12px;
            border-radius: 8px;
            padding-right: 12px;
            padding-bottom: 8px;
            backdrop-filter: blur(6px);
            background-color: rgba(41, 41, 41, 0.41);
          }
          .frame1920wlight-icon5 {
            width: 24px;
            margin-right: 4px;
          }
          .frame1920wlight-text409 {
            color: white;
            font-size: 13px;
            font-style: normal;
            font-weight: 500;
            line-height: 24px;
          }
        `}
      </style>
    </>
  )
}

export default Frame1920wlight
